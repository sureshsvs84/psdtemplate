﻿
/*Universal Customer Dimension Integration - start*/
var masterJson;
var counter = 0;
var ucdFilterSearchByUrl = "../Filter/TatvamUniversalCustomerDimensonFilter";
var ucdFilterSearchValuesUrl = "../Filter/TatvamFilterSearchValue";

//To pass the obtained Subscription Details Global Value
function GetSelectedUniversalCustomerDimFilter() {
    var reportFilter = undefined;
    if (obtainedSubscriptionDetails && obtainedSubscriptionDetails.ReportFilter) {
        reportFilter = jQuery.parseJSON(obtainedSubscriptionDetails.ReportFilter);
    }
    return reportFilter;
}

function LoadReportSubscriptionUCDFilter() {
    clearReportFilters();
    GetSubscriptionUCDFilterSearchBy();
}

/*Function to Create the HTML contents and Place holder for the Controls - Start*/
function reportSubscriptionModalRow(counter) {
    var reportSubscriptionRowHtml = '<div class="repeatingSection reportSubscriptionRepeatSection row"> '
     + '<div class="form-group col-xs-6 col-sm-2"> '
        + '<label for="ddlreportSubscriptionSearchBy_' + counter + '">Search By</label> '
        + '<select id="ddlreportSubscriptionSearchBy_' + counter + '" class="form-control ddlreportSubscriptionSearchBy" name="ddlreportSubscriptionSearchBy_' + counter + '" onchange="onChangeSearchByReportSubscription(this)"> '
        + '</select> '
    + ' </div> '
   + '  <div class="form-group col-xs-12 col-sm-7" id="divreportSubscriptionDDLValue"> '


      + '   <button type="button" class=" chosen-toggle deselect" onclick="reportSubscriptionValueDeselect(event)">Deselect all</button> '
      + '   <button type="button" class="chosen-toggle select" onclick="reportSubscriptionValueSelect(event)">Select all</button> '
       + '  <label for="ddlreportSubscriptionValue_' + counter + '">Value</label> '
      + '   <select multiple class="form-control chosen-select ddlreportSubscriptionValue required" id="ddlreportSubscriptionValue_' + counter + '" name="ddlreportSubscriptionValue_' + counter + '"></select> '
   + '  </div> '
    + ' <div class="customBtnGroup btn-group col-xs-6 col-sm-2"> '

    + '<div class="btn-group" id="ddlreportSubscriptionCondition_' + counter + '" data-toggle="buttons" onclick="reportSubscriptionAddFilter(event,this)">'
    + '<label class="btn switchBtn btn-on btn-sm">'
    + '<input type="radio" value="AND" name="reportSubscriptionFilterCondition" checked="checked">AND</label>'
    + '<label class="btn switchBtn btn-off btn-sm ">'
    + '<input type="radio" value="OR" name="reportSubscriptionFilterCondition">OR</label>'
    + '</div>'

    + ' </div> '
    + ' <div class="form-group col-xs-6 col-sm-1"> '
     + '    <a href="#" class="buttonGray buttonRight deleteFilter customDeleteBtn" onclick="reportSubscriptionDeleteFilter(event)"><i class="fa fa-trash-o"></i></a> '
   + '  </div> '

+ ' </div> ';
    return reportSubscriptionRowHtml;
}
/*Function to Create the HTML contents and Place holder for the Controls - End*/

/*Function to Validate the Select Dropdown for Null or Empty - Start*/
function ddlValidateReportSubscription() {
    var flag = true;
    var e = $('#reportSubscriptionForm .repeatingSection').find('select') || $('#reportSubscriptionForm .repeatingSection').last().find('.chosen-choices');
    for (i = 0; i < (e.length) ; i++) {
        var optionSelIndex = e[i].selectedIndex;
        $("#" + e[i].id).removeClass("ddlreportSubscriptionError");
        if (!optionSelIndex) {
            var optionSelectedText = e[i].options[e[i].selectedIndex].value;
        }

        if (optionSelIndex < 0 || (optionSelIndex === 0 && optionSelectedText === ''))
            //if (optionSelIndex > 0)
        {
            var optionName = $("#" + e[i].id).parent().find('label')[0].textContent;
            $("#" + e[i].id).addClass("ddlreportSubscriptionError");
            bootbox.alert({
                message: "Please Select an Option in " + optionName,
                title: "Alert Box",
                size: 'small',
                backdrop: false
            });

            flag = false;
            break;
        }
    }
    return flag;
}
/*Function to Validate the Select Dropdown for Null or Empty - End*/

//Function to reset reportSubscriptionForm - Starts
function reportSubscriptionFormReset() {

    $(".reportSubscriptionRepeatSection").remove();
    SetSubscriptionUcdFilters();
}
//Function to reset reportSubscriptionForm - End

/*Function to Apply the Created Filters - Start*/


function SetAppliedSubscriptionUCDFilters() {
    var flag = ddlValidateReportSubscription();
    if (flag) {
        $("#reportSubscriptionModal").modal('toggle');
        var count = $('#reportSubscriptionForm .repeatingSection').length;
        $('#reportSubscriptionAppliedFilterCount').empty();
        $('#reportSubscriptionAppliedFilterCount').append(count);
        $('#reportSubscriptionAddFilter').hide();
        $("#reportSubscriptionFilterMessage").show();
    }
}
/*Function to Apply the Created Filters - End*/

/*Function to Select All values  - Start*/
function reportSubscriptionValueSelect(e) {
    $(e.target).parent().find('option').prop('selected', true).parent().trigger('chosen:updated');
}
/*Function to Select All values  - End*/


/*Function to Select All values  - Start*/
function reportSubscriptionValueDeselect(e) {
    $(e.target).parent().find('option').prop('selected', false).parent().trigger('chosen:updated');
}
/*Function to Clear All values  - End*/

/*Function to Delete Individual Filter - Start*/
function reportSubscriptionDeleteFilter(e) {
    e.preventDefault();
    var current_filter = $(e.target).closest('#reportSubscriptionForm .repeatingSection');
    var other_filters = current_filter.siblings('#reportSubscriptionForm .repeatingSection');
    var valueId = $(e.target).closest('#reportSubscriptionForm .repeatingSection').find('.ddlreportSubscriptionValue').attr("id");
    if (other_filters.length === 0) {
        bootbox.alert({
            message: "You should atleast have one filter",
            title: "Alert Box",
            size: 'small',
            backdrop: false
        });
        return;
    }
    current_filter.slideUp('slow', function () {
        current_filter.remove();
        // reset filter indexes
        other_filters.each(function () {
            resetAttributeNames($(this));
        })
    })
}
/*Function to Delete Individual Filter - End*/

/*Function to Create an Filter - Start*/
function reportSubscriptionAddFilter(e, curObj) {
    var isLastChild = $(curObj).parent().parent().is(":last-child");
    e.preventDefault();
    counter = generateCounter();
    var flag = ddlValidateReportSubscription();
    if (flag && isLastChild) {
        initCreateRowReportSubscription(counter);
    }
}

/*Function to Create an Filter - End*/


/*Function to bind the values on change of Search by - Start*/
function onChangeSearchByReportSubscription(selectedObj) {
    var valueId = $("#" + selectedObj.id).closest('#reportSubscriptionForm .repeatingSection').find('.ddlreportSubscriptionValue').attr("id");
    var value = document.getElementById(valueId);
    var selectedFilter = selectedObj.options[selectedObj.selectedIndex].text;
    GetUCDSearchValues(selectedFilter, value);
    $("#" + valueId).trigger("chosen:updated");
}

/*Function to bind the values on change of Search by - End*/

/*Function to bind the values to SearchBy - Start*/
function bindDataToMasterReportSubcription(searchBy, masterJson) {
    for (var i = 0; i < masterJson.SearchBy.length; i++) {
        searchBy.options[searchBy.options.length] = new Option(masterJson.SearchBy[i].DimensionDisplayName, masterJson.SearchBy[i].DimensionParameter);
        var dimParam = JSON.parse(masterJson.SearchBy[i].DimensionParameter);
        searchBy.options[i].setAttribute("key_type", dimParam.DimensionDisplayName);
    }
}
/*Function to bind the values to SearchBy - End*/

/*Function to bind the values to Operator - Start*/
function bindDataToOperator(operator, operatorJson) {
    for (var i = 0; i < operatorJson[i].LstTatvamOperators.length; i++) {
        operator.options[operator.options.length] = new Option(operatorJson[i].LstTatvamOperators[i].OperatorDisplayName, operatorJson[i].LstTatvamOperators[i].OperatorSymbol);
    }
}

/*Function to bind the values to Operator - End*/


/*Function to bind the values to Values - Start*/
function bindDataToDimensionReportSubscription(selectedFilter, value, ucdSearchValues) {
    $("#" + value.id).empty();
    if (selectedFilter != "Comment") {
        for (var i = 0; i < ucdSearchValues.length; i++) {
            value.options[value.options.length] = new Option(ucdSearchValues[i].Text, ucdSearchValues[i].Value);
        }

        $("#" + value.id).chosen('destroy');
        $("#" + value.id).chosen({
            width: "100%",
            create_option: false,
            skip_no_results: false,
            select_all_buttons: true,  //Adds "Select all" and "deselect all" buttons
            select_all_character: '*',  // Selecting all result for a specified key
            select_all_character: '/'  //Removing all result for a specified key
        });
    } else {
        $("#" + value.id).chosen('destroy');
        $("#" + value.id).chosen({
            width: "100%",
            create_option: true,
            skip_no_results: true,
            select_all_buttons: true,  //Adds "Select all" and "deselect all" buttons
            select_all_character: '*',  // Selecting all result for a specified key
            select_all_character: '/'  //Removing all result for a specified key
        });
    }
}
/*Function to bind the values to Values - End*/

/*Function to Rename the Control ID's when a filter is Deleted - Start*/
function resetAttributeNames(section) {
    var attrs = ['for', 'id', 'name'];
    var tags = section.find('input, label, select, div'), idx = section.index();
    tags.each(function () {
        var $this = $(this);
        $.each(attrs, function (i, attr) {
            var attr_val = $this.attr(attr);
            if (attr_val) {
                $this.attr(attr, attr_val.replace(/(_)(\d+)/g, '_' + (idx)));
            }
        })
    })
}

/*Function to Rename the Control ID's when a filter is Deleted - End*/

/*Function to Delete all Applied Filters - Start*/
function reportSubscriptionResetFilter(e) {
    bootbox.confirm({
        message: "Reset will remove all the Applied Filters. Are you sure you want to Reset?",
        buttons: {
            confirm: {
                label: 'Reset',
                className: 'btn-primary'
            },
            cancel: {
                label: 'Cancel',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            if (result) {
                clearReportFilters();
                obtainedSubscriptionDetails.ReportFilter = undefined;
                $(this).modal('hide');
            } else {
                $(this).modal('hide');
            }
        }
    });
}
/*Function to Delete all Applied Filters - End*/

/*Function to Initialise Method on Page Load for reportSubscription Filter - Start*/
function initCreateRowReportSubscription(counter) {
    $('#reportSubscriptionForm .formBody').last().append(reportSubscriptionModalRow(counter));
    var searchBy = document.getElementById("ddlreportSubscriptionSearchBy_" + counter);
    var value = document.getElementById("ddlreportSubscriptionValue_" + counter);

    //Function Call to Bind Data to the Search By DDL
    bindDataToMasterReportSubcription(searchBy, masterJson);

    var selectedFilter = $("#" + searchBy.id + " option:selected").text();
    GetUCDSearchValues(selectedFilter, value);
}
/*Function to Initialise Method on Page Load for reportSubscription Filter - End*/

/*Function to Initialise Method on Page Load when Filter Already Exists for reportSubscription Filter - Start*/
function initRetreivedRowReportSubscription(savedFilter) {
    for (var key in savedFilter) {
        initCreateRowReportSubscription(key);
        var dimParam = JSON.parse(savedFilter[key].SearchbyValue);
        $('#ddlreportSubscriptionSearchBy_' + key + ' option').each(function () {
            if ($(this).html() == dimParam.DimensionDisplayName) {
                $(this).attr("selected", true);                
            } else { $(this).attr("selected", false); }
        });
        if (savedFilter[key].ConditionName == "AND") {
            $("#ddlreportSubscriptionCondition_" + key + " .btn-on").addClass('active');
        } else {
            $("#ddlreportSubscriptionCondition_" + key + " .btn-off").addClass('active');
        }

        var objValue = savedFilter[key].SelectedValue;
        var objText = savedFilter[key].SelectedText;
        var value = document.getElementById("ddlreportSubscriptionValue_" + key);
        //bindDataToDimensionReportSubscription(savedFilter[key].SearchbyText, value, dimensionJson);
        GetUCDSearchValues(savedFilter[key].SearchbyText, value);
        for (var prop in objValue, objText) {
            var selectedVal = jQuery.map( objText, function( n, i ) {				
                return n.Name;
            });
            var tempValue = objValue[prop].Name;
            if(objValue[prop].Id)
            {
                tempValue = objValue[prop].Id;
            }
            $('#ddlreportSubscriptionValue_' + key + ' option[value="' + tempValue + '"]').prop('selected', true);
        }
        $('#ddlreportSubscriptionValue_' + key).trigger("chosen:updated");
    }
    var count = $('#reportSubscriptionForm .repeatingSection').length;
    $('#reportSubscriptionAppliedFilterCount').empty();
    $('#reportSubscriptionAppliedFilterCount').append(count);
    $("#reportSubscriptionFilterMessage").show();
    $('#reportSubscriptionAddFilter').hide();
}

/*Function to Initialise Method on Page Load when Filter Already Exists for reportSubscription Filter - End*/

/*Function to Store the values of the Filter into Object Model - Start*/
function retreiveSelectedSubscriptionFilters() {
    var rowData = [];
    var row = $('#reportSubscriptionForm .repeatingSection');
    for (i = 0; i < row.length; i++) {
        currentUCDFilter = {};
        $("#ddlreportSubscriptionSearchBy_" + i + " option:selected").each(function () {
            currentUCDFilter.SearchbyText = $(this).text();
            currentUCDFilter.SearchbyValue = $(this).val();
        });

        //var isActiveBtn = $("#ddlreportSubscriptionCondition_" + i + " .btn-on").hasClass("active");
        if ($("#ddlreportSubscriptionCondition_" + i + " .btn-on").hasClass("active")) {
            currentUCDFilter.ConditionName = "AND";
            currentUCDFilter.ConditionValue = "AND";
        } else {
            currentUCDFilter.ConditionName = "OR";
            currentUCDFilter.ConditionValue = "OR";
        }
        currentUCDFilter.SelectedText = FetchText(i);
        currentUCDFilter.SelectedValue = FetchText(i);
        if (currentUCDFilter.SelectedValue.length > 0) {
            rowData.push(currentUCDFilter);
        }
    }
    return rowData;
}

/*Function to Store the values of the Filter into Object Model - End*/

/*Function to Retrieve the applied Filter in Session - Start*/
function reportSubscriptionRetreivereportSubscriptionSavedFilter() {
    var sesStoredData = sessionStorage.reportSubscriptionFilter;
    if (sesStoredData != undefined)
        sesStoredData = JSON.parse(sesStoredData);
    return sesStoredData;
}
/*Function to Retrieve the applied Filter in Session - End*/

/*Function to generate the number of Filters  - Start*/
function generateCounter() {
    counter = $('#reportSubscriptionForm .repeatingSection').length;
    return counter;
}
/*Function to generate the number of Filters  - End*/

/*Function to bind Object Model into the RowData Model for Search by Text  - Start*/
function FetchText(i) {
    var data = [];
    var options = $("#ddlreportSubscriptionValue_" + i + " option:selected");
    var values = $.map(options, function (option) {  
        var id = option.value;
        var name = option.text;
        if(id === ""){
            id= name;
        }
        data.push({ "Name": name, "Id": id });
    });  

    return data;
}
/*Function to bind Object Model into the RowData Model for Search by Text  - End*/

/*Function to bind Object Model into the RowData Model for Search by Value  - Start*/
function FetchValue(i) {
    var data = [];
    var selector = $('#ddlreportSubscriptionValue_' + i).val();
    for (var j = 0; j < selector.length; j++) {
        data.push({ "Name": selector[j] });
    }
    return data;
}

/*Function to bind Object Model into the RowData Model for Search by Text  - End*/

function GetSubscriptionUCDFilterSearchBy() {
    //if UCD Filter's SearchBy (masterJson) is already exists just bind the ucd filter
    if (masterJson && masterJson.length > 0) {
        $.ajax({
            type: "POST",
            async: false,
            url: ucdFilterSearchByUrl,
            success: function (result) {
                masterJson = result;
                SetSubscriptionUcdFilters();
            },
            error: function (xhr, status, p3, p4) {
                hideLoadingCursor();
                var error = JSON.parse(xhr.responseText)
                TatvamAlert(error.ErrorMessage, "Error");
            }
        });
    } else {
        SetSubscriptionUcdFilters();
    }
}

function GetUCDSearchValues(selectedSearchBy, value) {
    var dimensionParameter = GetUCDSearchByDimensionParameter(selectedSearchBy);
    $.ajax({
        type: "POST",
        async: false,
        url: ucdFilterSearchValuesUrl,
        data: { DimensionParameter: dimensionParameter },
        success: function (result) {
            bindDataToDimensionReportSubscription(selectedSearchBy, value, result);
        },
        error: function (xhr, status, p3, p4) {
            hideLoadingCursor();
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

function GetUCDSearchByDimensionParameter(selectedSearchBy) {
    var searchBy = masterJson.SearchBy;
    var index, queryId;
    for (index = 0; index < searchBy.length; ++index) {
        if (searchBy[index].DimensionDisplayName === selectedSearchBy) {
            queryId = searchBy[index].DimensionParameter;
            break;
        }
    }
    return queryId;
}

//Method to get queryid for selected dimension(search by) in UCD control
function GetUCDSearchByQueryId(selectedSearchBy) {
    var searchBy = masterJson.SearchBy;
    var index, queryId;
    for (index = 0; index < searchBy.length; ++index) {
        if (searchBy[index].DimensionDisplayName === selectedSearchBy) {
            queryId = searchBy[index].QueryId;
            break;
        }
    }
    return queryId;
}

function SetSubscriptionUcdFilters() {
    var subscriptionReportFilter = GetSelectedUniversalCustomerDimFilter();
    if (subscriptionReportFilter && subscriptionReportFilter.length > 0) {
        initRetreivedRowReportSubscription(subscriptionReportFilter);
    } else {
        generateCounter();
        initCreateRowReportSubscription(counter);
    }
}
/*Universal Customer Dimension Integration - End*/

