﻿
function addNewSubscriber() {
    
    clearAddNewSubscriberErrors();
    if (!validateNewSubscriber()) {
        return false;
    }
    var rtnVal = isTatvamUser();
    var isTrueSet = (rtnVal.toLowerCase() === 'true');
    if (isTrueSet) {
        $("#addUser").modal('hide');
        TatvamAlert("User is a Tatvam User. Add it from the available subscriber list.", "Error");
        return false;
    }

    if (checkNonTatvamUserExistForSubscription()) {
        $("#addUser").modal('hide');
        TatvamAlert("Non Tatvam user already subscribed for the Report.", "Error");
        return false;
    }

    NewSubscriber = new Object();
    NewSubscriber.RecipientFirstName = $("#txt_FirstName").val();
    NewSubscriber.RecipientLastName = $("#txt_LastName").val();
    NewSubscriber.RecipientEmailId = $("#txt_EmailId").val();
    NewSubscriber.DirtyFlag = "Insert";
    NewSubscriber.ModifiedCount = 0;
    addRecipientRow(NewSubscriber);
    resetNewSubscriber();
    $("#addUser").modal('hide');
}

function validateNewSubscriber() {
    clearAddNewSubscriberErrors();
    var firstName = $("#txt_FirstName").val();
    if (firstName == "") {
        $("#lbl_firstname_error").text("First name cannot be blank.");
    }

    var lastName = $("#txt_LastName").val();
    if (lastName == "") {
        $("#lbl_lastname_error").text("Last name cannot be blank.");
    }

    var emailId = $("#txt_EmailId").val();
    if (emailId == "") {
        $("#lbl_emailid_error").text("EmailId cannot be blank.");
    }

    if (firstName == "" || lastName == "" || emailId == "") {
        return false;
    }

    if (!isValidEmailAddress(emailId)) {
        $("#lbl_emailid_error").text("Invalid email address.");
        return false;
    }

    return true;
}

function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
    // alert( pattern.test(emailAddress) );
    return pattern.test(emailAddress);
};

function clearAddNewSubscriberErrors() {
    $("#lbl_firstname_error").text("");
    $("#lbl_lastname_error").text("");
    $("#lbl_emailid_error").text("");
}

function isTatvamUser() {
    var inpObject = new Object();
    inpObject.strEmailId = $("#txt_EmailId").val();
    var rtnVal = TatvamAjaxCallWithReturn("GET", "../ReportSubscription/IsTatvamUser", inpObject, null, {});
    return rtnVal.responseText;
}

function checkNonTatvamUserExistForSubscription() {
    var strEmailId = $("#txt_EmailId").val();
    var recipientList = $('#tbl_RecipientDetails tr:has(td)').map(function (i, v) {
        var $td = $('td', this);
        if ($td.eq(3).text() == strEmailId) {
            return true;
        }       
    }).get();
    return recipientList[0];
}


function closeNewSubscriber() {
    resetNewSubscriber();
    clearAddNewSubscriberErrors();
}

function resetNewSubscriber() {
    
    $("#txt_FirstName").val("");
    $("#txt_LastName").val("");
    $("#txt_EmailId").val("");
    $("#btn_AddNonTatvamUser").attr("disabled", "disabled");
}

