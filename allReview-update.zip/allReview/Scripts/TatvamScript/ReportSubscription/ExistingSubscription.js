﻿/*Existing Subscriber Functions Starts*/
function bindExistingSubscriberList(inpData) {
    inpData = inpData.response;
    $('#tbl_existingSubscriber tbody').empty();
    $("#lbl_error_existingsubscription").text("");
    $("#btn_saveExistingSubscriber").css({ 'display': 'inline-block' });
    $("#btn_cancelExistingSubscriber").css({ 'display': 'inline-block' });
    if (inpData.length == 0) {
        $("#btn_saveExistingSubscriber").css({ 'display': 'none' });
        $("#btn_cancelExistingSubscriber").css({ 'display': 'none' });
        $("#lbl_error_existingsubscription").text("No subscriptions available.");
    }
    $.each(inpData, function () {
        addExistingSubscuriberRow(this);
    });
    registerSubscriberCheckbox();
    disableButtonsPostSave();
}

function registerSubscriberCheckbox() {
    $('input[name=existingSubscribe]').change(function () {
        $("#btn_saveExistingSubscriber").removeAttr('disabled');
        $("#btn_cancelExistingSubscriber").removeAttr('disabled');
        $(this).closest('td').next()[0].innerHTML = true;
    });
}

function addExistingSubscuriberRow(NewExistingSubscriber) {
    var noofRows = $('#tbl_existingSubscriber tbody tr').length;
    // Find a <table> element with id="myTable":
    var tableBody = document.getElementById("tbl_existingSubscriber_tbody");
    // Create an empty <tr> element and add it to the 1st position of the table:
    var row = tableBody.insertRow(noofRows);
    // Insert new cells (<td> elements) at the 1st and 2nd position of the "new" <tr> element:
    var cell0 = row.insertCell(0);
    cell0.innerHTML = NewExistingSubscriber.CustomerId;
    cell0.style.display = "none";   

    var rsid = NewExistingSubscriber.ReportScheduledId
    var cell1 = row.insertCell(1);
    //Made the Subscription Name clickable by adding the onclick functionality and anchor tag.
    cell1.innerHTML = "<a style=\"cursor:pointer\" onclick = \"onClickSubscriptionName("+rsid+")\">" + NewExistingSubscriber.SubscriptionName + "</a>";
    cell1.className = "rptSubDetailDefaultColumnStyle text-left";

    var cell2 = row.insertCell(2);
    cell2.innerHTML = NewExistingSubscriber.ReportCategoryName;
    cell2.className = "rptSubDetailDefaultColumnStyle text-left";

    var cell3 = row.insertCell(3);
    cell3.innerHTML = NewExistingSubscriber.Fequency;
    cell3.className = "text-left";
    
    var cell4 = row.insertCell(4);
    cell4.innerHTML = NewExistingSubscriber.RecipientFirstName + " " + NewExistingSubscriber.RecipientLastName;
    cell4.className = "rptSubDetailDefaultColumnStyle text-left";

    var cell5 = row.insertCell(5);
    cell5.innerHTML = NewExistingSubscriber.RecipientEmailId;
    cell5.className = "rptSubDetailEmailIDColumnStyle text-left";

    var cell6 = row.insertCell(6);
    cell6.innerHTML = NewExistingSubscriber.LastProcessAt;
    cell6.className = "text-center";

    var cell7 = row.insertCell(7);
    cell7.className = "text-center";
    if (NewExistingSubscriber.IsSubscribed) {
        cell7.innerHTML = " <input type='checkbox' name='existingSubscribe' id='subscribe' checked>";
    } else {
        cell7.innerHTML = " <input type='checkbox' name='existingSubscribe' id='subscribe'>";
    }

    var cell8 = row.insertCell(8);
    cell8.innerHTML = NewExistingSubscriber.IsModified;
    cell8.style.display = "none";

    var cell9 = row.insertCell(9);
    cell9.innerHTML = NewExistingSubscriber.ModifiedCount;
    cell9.style.display = "none";

    var cell10 = row.insertCell(10);
    cell10.innerHTML = NewExistingSubscriber.CreatedDate;
    cell10.style.display = "none";

    var cell10 = row.insertCell(11);
    cell10.innerHTML = NewExistingSubscriber.ReportScheduledId;
    cell10.style.display = "none";    
}

function cancelExistingSubscriber() {
    //empty Existing subscriber table
    $("#tbl_existingSubscriber  > tbody").empty();
    //bind data to Existing Subscriber table with OnLoad Data this will remove the changes happened on this.
    readExistingSubscriber();

    $("#btn_saveExistingSubscriber").removeAttr('disabled');
    $("#btn_cancelExistingSubscriber").removeAttr('disabled');

    disableButtonsPostSave();
}

function saveExistingSubscriber() {
    //Read existing subscriber information from the table
    var existingSubscriberList = getExistingSubscriber();

    //ajax call to update the Existing Subscription details
    var rtn = TatvamAjaxCallWithReturn("POST", "../ReportSubscription/UpdateExistingSubscriptionData", existingSubscriberList, null, {});
    //if update successful display success message
    if (rtn.responseText > 0) {
        //refresh available subscriptions table post successful save.
        readExistingSubscriber();
        TatvamAlert("Subscription has been successfully updated.", "Successful");

    } else {
        TatvamAlert("Unable to update subscription details. Please contact system administrator.", "Error");
    }
}

function getExistingSubscriber() {
    var existingSubscriberList = $('#tbl_existingSubscriber tr:has(td)').map(function (i, v) {
        var $td = $('td', this), isSubscribed = false;
        if ($td.eq(7).find("#subscribe:checked").length > 0) {
            isSubscribed = true;
        }
        return {
            CustomerId: $td.eq(0).text(),
            SubscriptionName: $td.eq(1).text(),
            ReportCategoryName: $td.eq(2).text(),
            Fequency: $td.eq(3).text(),            
            ReciptienFirstName: $td.eq(4).text(),
            ReciptienLastName: $td.eq(4).text(),
            RecipientEmailId: $td.eq(5).text(),
            LastProcessAt: $td.eq(6).text(),
            IsSubscribed: isSubscribed,
            IsModified: $td.eq(8).text(),
            ModifiedCount: $td.eq(9).text(),
            ReportScheduledId: $td.eq(11).text()
        }
    }).get();

    return existingSubscriberList;
}

function readExistingSubscriber() {
   TatvamAjaxCalls("GET", "../ReportSubscription/GetExistingSubscriber", null, bindExistingSubscriberList, {});
}

function disableButtonsPostSave() {
    $("#btn_saveExistingSubscriber").prop('disabled', true);
    $("#btn_cancelExistingSubscriber").prop('disabled', true);
}

//New function for edit functionality, when we click on the subscription name in the existing subscription the details will be load in the create new subscription tab
function onClickSubscriptionName(reportScheduleId)
{
    var inpObject = new Object();
    inpObject.ReportScheduledId = reportScheduleId;

    //Ajax call to get the Report subscription Details
    var rtnVal = TatvamAjaxCallWithReturn("GET", "../ReportSubscription/GetSubscriptionDetails", inpObject);
    $('[href="#createNewUser"]').tab('show');

    //parse the return value
    var jsonData = JSON.parse(rtnVal.responseText);

    //maintain state of subscription form based on the edit/create mode
    maintainUIState(jsonData, inpObject);

    //set add/edit mode
    setMode(jsonData);

    //to-do: need to move this global variable into a function parameter
    obtainedSubscriptionDetails = jsonData;

    if (jsonData.ReportScheduledId == 0) {
        //add functionality
        //during add mode, do not reset the already added recipient list
        if (jsonData.isEdit) {
            $("#tbl_RecipientDetails > tbody").empty();
        }

        jsonData.Frequency = inpObject.Frequency;
        jsonData.ReportId = inpObject.ReportId;


        //enable save for saving the subscription
        enableSaveButton();

    } else {
        //edit functionality
        $("#lbl_subscription_id").text(jsonData.ReportScheduledId);

        //enable update for saving the updated subscription
        enableUpdateButton();

        var reportname = $("#ddl_ReportList  option:selected").text();
        if (strRole !== "Admin" && strRole != "TatvamAdmin") {
            $("#txt_PeriousPeriod").attr('disabled', 'disabled');
            $("#ddl_ReportPeriodicity").attr('disabled', 'disabled');
        }
    }

    if (jsonData == undefined) {
        return;
    }

    //Bind Subscription Data to the respective controls
    bindSubscriptionData(jsonData);

    //Bind Report Recipient to the Table
    bindRecipientList(jsonData.lstReportRecipient);
    
    //Bind all the available subscribers for the report
    bindAvailableSubscriber(jsonData.lstReportUsers);
}
/*Existing Subscriber Functions Ends*/