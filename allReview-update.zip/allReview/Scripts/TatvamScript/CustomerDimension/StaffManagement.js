﻿//string constants used for this module
var staffMgmtConstants = {
    elementIDConstant: {
        treeViewID: "#treeview",
        btnSaveID: "#btn_submit",
        dialogConfirmID: "#dialog-confirm"
    },
    classConstant: {
        treeViewContextMenuClass: ".jstree-contextmenu",
        treeViewAnchorClass: '.jstree-anchor',
        treeClickClass: '.jstree-clicked',
        hideTreeNode: 'hide-tree-node-mgmt'
    },
    messages: {
        duplicateStaffNotAllowed: "already available.Duplicate Staff not allowed",
        selectKeyWordtoDelete: "Select any keyword before proceeding with the deletion.",
        noDataAvailable: "<div class=\'nodata\'>No Data Available.</div>",
        successfullySaved: "Data Saved Succesfully.",
        failedToSave: "Data not Saved",
        OnDeletion: "record ?"
    },
    scripts: {
        jstree: '../Scripts/jstree.min.js'
    },
    url: {
        saveDimension: '../CustomerDimension/SaveStaffDimensionManagementTreeview'
    },
    icons:
        {
            starIcon: '../Content/Images/star.png',
            treeIcon: '../Content/Images/tree-icon.png',
            leafIcon: '../Content/Images/leaf_icon.png',
        },
    keywords: {
        newNodeOnCreate: 'New',
        alertBox: "Alert Box",
        treeViewColumnHeader: "Departments",
        staff: "Staff",
        deletion: "Are you sure you want to delete "

    },
    jstreeConfiguration: {
            create: "Create",
            rename: "Rename",
            delete: "Delete",
            maxChildren: 1,
            maxDepth: 10,
            parentnode: "#",
            moveNode: "move_node"
    },
    nodeStatus: {
        added: 0,
        renamed: 1,
        removed: 2,
        moved: 3
    },
    levels: {
        one: 1
    },
    states: {
        opened: "opened"
    },
    treeConfig: {
        state: "state"
    }
}
//on document ready, following steps are executed
$(document).ready(function () {
    $(document).ready(function () {
        var staffListArr = [];
        //iterate the model and include this in an array.
        //TO-DO: need to check whether this step is mandatory.    
        for (var i = 0; i < staffTreeModel.length; i++) {
            //method to set  state to 'open' so that base node expands to first level. 
          setObjProp(staffTreeModel[i], staffMgmtConstants.treeConfig.state, staffMgmtConstants.states.opened, true);
            staffListArr.push(staffTreeModel[i]);
        }
        //call method to display the tree view.
        DisplayTreeView(staffListArr);
    });
});

//close the context menu on clicking any node in the tree view.
//TO-DO: May be clicking outside tree view should close the context menu.
$(staffMgmtConstants.elementIDConstant.treeViewID).click(function () {
    $(staffMgmtConstants.classConstant.treeViewContextMenuClass).css("display", "none");
});

//TO-DO: Need to verify the usage of below global variables and then use it locally or remove accoridingly.
var deleteid = "";
var retval = 1;
var Parents, Parent, Childrens, Nodeid, nodeLevel;

//Funtion for displaying the departments and staff
function DisplayTreeView(treeData) {

    /**
   *  if there is no treedata then display as "no data available"
   *  else
   * bind the treedata to treeview
   * @param {} treedata 
   * 
   */
    //check for treedata length, if no data then display no data message.
    if (treeData.length === 0) {
        $(staffMgmtConstants.elementIDConstant.treeViewID).empty();
        $(staffMgmtConstants.elementIDConstant.treeViewID).append(staffMgmtConstants.messages.noDataAvailable);
    }
    else {
        //bind treedata with the needed jstree configuration like core, types etc...
        $.getScript(staffMgmtConstants.scripts.jstree, function () {
            $(staffMgmtConstants.elementIDConstant.treeViewID)
                 .bind("select_node.jstree", function (e, data) {
                     nodeLevel = data.node.parents.length;
                 })
                .jstree({
                    "core": {
                        "multiple":false,
                        "check_callback": true, // so that create works
                        strings: {
                            //name for any any new node creation
                            'New node': staffMgmtConstants.keywords.newNodeOnCreate
                        },
                        "open_parents": true,
                        "force_text": true,
                        'data': treeData,
                        'error': function (err) {

                            var dialogMessage;

                            // check for duplicates at node
                            if (err.plugin === "unique" || err.plugin === "core" || err.plugin === "types") {
                                if ((err.id === 'unique_01' || err.id === 'unique_03')) {

                                    //setting duplicate message
                                    dialogMessage = staffMgmtConstants.keywords.staff + " '" +
                                       jQuery.parseJSON(err.data).pos.fontcolor("red") + "' " +
                                        staffMgmtConstants.messages.duplicateStaffNotAllowed;
                                }

                                if (!dialogMessage)
                                {
                                    return;
                                }                              


                                //displaying dialog for duplicate message

                                bootbox.confirm({
                                    title: dialogMessage,
                                    message: classifierMgmtConstants.keywords.alertBox,
                                    buttons: {
                                        confirm: {
                                            label: 'Ok',
                                            className: 'btn-primary'
                                        },
                                        cancel: {
                                            label: 'Cancel',
                                            className: 'btn-default'
                                        }
                                    },
                                    callback: function () {
                                        $(this).modal('hide');
                                        $(staffMgmtConstants.elementIDConstant.treeViewID).jstree("deselect_all");
                                        $(staffMgmtConstants.elementIDConstant.treeViewID).jstree('select_node', staffMgmtConstants.jstreeConfiguration.parentnode + Nodeid);
                                        $(staffMgmtConstants.elementIDConstant.treeViewID).jstree().edit(Nodeid);
                                    }
                                })

                                
                            }
                        },

                        //callback called when there is change in the hierarchy
                        'check_callback': function (operation, node, nodeParent, node_position, more) {
                            //if the operation is move node, then change the id of the current node.
                            //TO-DO: need to understand and add more details to this.
                            if (operation === staffMgmtConstants.jstreeConfiguration.moveNode) {
                                return nodeParent.id !== staffMgmtConstants.jstreeConfiguration.parentnode; 
                            }
                            return true; 
                        }

                    },
                    //used for displaying icons on creation of node
                    //TO-DO: need to add more details to this for better understanding.
                    "types": {
                        "#": {
                            "max_children": staffMgmtConstants.jstreeConfiguration.maxChildren,
                            "max_depth": staffMgmtConstants.jstreeConfiguration.maxDepth
                            //"valid_children": ["root"]
                        },
                        "root": {
                            //'icon': staffMgmtConstants.icons.starIcon
                            //"valid_children": ["default"]
                        },
                        "default": {
                            //'icon': staffMgmtConstants.icons.treeIcon
                            //"valid_children": ["default", "file"]
                        },
                        "file": {
                            //"icon": staffMgmtConstants.icons.leafIcon
                            //"valid_children": []
                        }
                    },
                    //right click nodes and shows a list of configurable actions in a menu
                    'contextmenu': {
                        "select_node": true,
                        "items": function (node) {
                            return {
                                "create": { // creation of new node upon right click of node
                                    "separator_after": true,
                                    "label": staffMgmtConstants.jstreeConfiguration.create,
                                    "action": function (data) {
                                        //call function to create a node
                                        StaffCreate();
                                    }
                                },
                                "rename": { // rename of  node upon right click of node
                                    "label": staffMgmtConstants.jstreeConfiguration.rename,
                                    "shortcut_label": 'F2',
                                    "action": function (data) {
                                        //call function to rename a node
                                        StaffRename();
                                    }
                                },
                                "Delete": {// deletion of new node upon right click of node
                                    "label": staffMgmtConstants.jstreeConfiguration.delete,
                                    "action": function (data) {
                                        //call function to remove the node
                                        StaffDelete();
                                    }
                                }

                            }
                        }
                    },
                    // drag and drop of node
                    "dnd": {
                        "is_draggable": function (node) {
                            if (node[0].parent === staffMgmtConstants.jstreeConfiguration.parentnode) {
                                return false;
                            } else {
                                return true;
                            }
                        },
                        "drag_selection": true
                    },
                    "plugins":
                        [
                        'contextmenu' //This plugin makes it possible to right click nodes and shows a list of configurable actions in a menu.
                        , "dnd"// The dnd plugin enables drag'n'drop support for jstree, also using foreign nodes and drop targets.
                        , "types"//This plugin makes it possible to add predefined types for groups of nodes, which means to easily control nesting rules and icon for each group.
                        , "unique" //Enforces that no nodes with the same name can coexist as siblings. This plugin has no options, it just prevents renaming and moving nodes to a parent, which already contains a node with the same name
                        , "sort" //automatically arranges all sibling nodes defaults to alphabetical order.
                        , "table" //For creating a table 
                        ],
                    // configure tree table
                    table: {
                        columns: [
                            {
                                width: 'auto',
                                header: staffMgmtConstants.keywords.treeViewColumnHeader,
                            }
                        ],
                        resizable: true,
                        contextmenu: true,
                        draggable: true
                    }
                }).bind('loaded.jstree', function (event, data) {
                    var jsTreeInstance = $(staffMgmtConstants.elementIDConstant.treeViewID).jstree(true);
                    //get all the nodes
                    var allNodes = jsTreeInstance.get_json(staffMgmtConstants.jstreeConfiguration.parentnode, { flat: true });

                    //iterate and then hide only the nodes which are marked as removed.
                    for (var index = 0; index < allNodes.length; index++) {
                        if (allNodes[index].data && allNodes[index].data.flag && allNodes[index].data.flag === staffMgmtConstants.nodeStatus.removed) {
                            var node = jsTreeInstance.get_node(allNodes[index].id);
                            node.li_attr.class = staffMgmtConstants.classConstant.hideTreeNode;
                            // hide the node which have nodeStatus (removed=2) on page load
                            $(staffMgmtConstants.jstreeConfiguration.parentnode +allNodes[index].id).hide();
                        }
                    }
                }).bind("move_node.jstree", function (e, data) {
                    // set moved status on hierarchy change.
                    // Don't consider setting flag value if the dimension/node is created newly or renamed.
                    var flag = (data && data.node && data.node.data && data.node.data.flag) ? data.node.data.flag : -1;
                    
                    if ((data.parent !== data.old_parent) && (flag !== staffMgmtConstants.nodeStatus.added) &&
                         (flag !== staffMgmtConstants.nodeStatus.removed)) {
                        data.node.data = { "flag": staffMgmtConstants.nodeStatus.moved };
                    }
                });
        });

    }


//this is a callback which is run on each action on the node, including the click
    function bind_node(event, data) {        
            Parents = data.node.parent;
            Childrens = data.node.children_d;        
    }

    //TO-DO: Need to check this.
    $(staffMgmtConstants.elementIDConstant.treeViewID).data().jstree
}

//Create  New node
function StaffCreate() {
    //get the instance of the jstree
    var ref = $(staffMgmtConstants.elementIDConstant.treeViewID).jstree(true);

    //get the ID of the selected node.
    var sel = ref.get_selected();

    var index = sel[0].indexOf('j');

    if (!sel.length) {
        return false;
    }

    //create a node 
    sel = sel[0];
    if (nodeLevel == staffMgmtConstants.levels.one) {
        sel = ref.create_node(sel, { "type": "default" });
    }
    else {
        sel = ref.create_node(sel, { "type": "file" });
    }
    ref.get_node(sel).data = { "flag": staffMgmtConstants.nodeStatus.added };
    ref.edit(sel);
}

//Rename  New node
function StaffRename() {
    //get tree instance
    var ref = $(staffMgmtConstants.elementIDConstant.treeViewID).jstree(true);
    //get ID of current node
    var sel = ref.get_selected();

    if (!sel.length) {
        return false;
    }
    else {
        //allow to rename when only when there is some text 
        sel = sel[0];        

        //mark the flag as renamed only for existing nodes and ignore flag change for newly added nodes.
        if (ref.get_node(sel).data && (ref.get_node(sel).data.flag === undefined || ref.get_node(sel).data.flag == staffMgmtConstants.nodeStatus.renamed)) {
            ref.get_node(sel).data = { "flag": staffMgmtConstants.nodeStatus.renamed };
        }

        ref.edit(sel);
    }
}

//Delete  Node
function StaffDelete() {    
    //get tree instance
    var ref = $(staffMgmtConstants.elementIDConstant.treeViewID).jstree(true);
    //get ID of current node
    var sel = ref.get_selected();

    if (sel.length === 0) {


        //display dialog
        bootbox.alert({
            message: staffMgmtConstants.messages.selectKeyWordtoDelete,
            title: staffMgmtConstants.keywords.alertBox,
            size: "small",
            callback: function (result) {
                $(this).modal('hide');
            }
        });
    }
    else {
        //delete the selected node
        var deletedkeywords = $(staffMgmtConstants.classConstant.treeClickClass).text().split('[');

        //set message in confirmation dialog

        bootbox.confirm({
            title: staffMgmtConstants.keywords.alertBox,
            message: staffMgmtConstants.keywords.deletion + " '  " + deletedkeywords[0].fontcolor("red") + "  ' "+ staffMgmtConstants.messages.OnDeletion,
            buttons: {
                confirm: {
                    label: 'Ok',
                    className: 'btn-primary'
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-default'
                }
            },
            callback: function () {
                deleteid = deleteid + ',' + sel;
                if (Childrens !== undefined && Childrens.length !== 0) {
                    deleteid = deleteid + ',' + Childrens;
                }
                if (!sel.length) {
                    return false;
                }

                var currNode = ref.get_node(sel);
                //check whethe flag already exists and then only set appropriate value
                if (currNode.data.flag === undefined || currNode.data.flag > 0) {
                    //set the flag only when its existing node and the newly added node.
                    currNode.data = { "flag": staffMgmtConstants.nodeStatus.removed };
                    //set class to hide tree node.
                    currNode.li_attr.class = staffMgmtConstants.classConstant.hideTreeNode;
                    //hide only when its actual element otherwise remove                        
                    AddClassToElementById(sel, staffMgmtConstants.classConstant.hideTreeNode);
                    //$("#" + sel).addClass('hide-tree-node-mgmt');
                }
                else {
                    //remove the node as its newly added.
                    ref.delete_node(sel);
                }

                $(this).modal('hide');
            }
        })


    }
}

//Save Dimension, on click of save changes
$(staffMgmtConstants.elementIDConstant.btnSaveID).click(function () {    
    //get tree view data as json with hierarcy, if flat is set to true then it will be without hierarchy
    var treeViewData = $(staffMgmtConstants.elementIDConstant.treeViewID)
                                .jstree(true).get_json(staffMgmtConstants.jstreeConfiguration.parentnode, { flat: false });
    var strData = JSON.stringify(treeViewData).replace(/,"icon":true/g, '');
    treeViewData = JSON.parse(strData);
    //call to post the obtained json
    $.ajax({
        type: 'POST',
        url: staffMgmtConstants.url.saveDimension,
        data: { dimensionFactCollection: treeViewData },
        success: function (result) {
            //on successfully saving, set the confirmation dialog message and display the dialog.         

            bootbox.alert({
                message: staffMgmtConstants.messages.successfullySaved,
                title: staffMgmtConstants.keywords.alertBox,
                size: "small",
                callback: function (result) {
                    $(this).modal('hide');
                }
            });
        },
        //show the error message when data is failed to save.
        error: function () {
            TatvamAlert(staffMgmtConstants.messages.failedToSave);
        }
    });
});








