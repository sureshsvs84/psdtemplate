﻿/**
 * @author Nithya Rani
 * @version 1.0.0
 *
 **/
(function RadarChart($) {
    "use strict";
    var convert = {
        chartData: function (data, currentSeries) {
            var chartData = [];
            data.forEach(function (oneData) {
                var n = true;
                if (currentSeries.length > 0) {
                    n = currentSeries.includes(oneData.Series);
                }
                if (n) {
                    oneData.Radius.push(oneData.Radius[0]);
                    oneData.Theta.push(oneData.Theta[0]);
                    chartData.push({
                        type: 'scatterpolar',
                        r: oneData.Radius,
                        theta: oneData.Theta,
                        name: oneData.Series
                    });
                }
            });
            return chartData;
        },
        dropdownData: function (data) {
            var dropdownData = [];
            data.forEach(function (oneData) {
                dropdownData.push({
                    text: oneData.Series,
                    value: oneData.Series
                });
            });
            return dropdownData;
        }
    };
    var delegates = {
        add: function (pluginId, idToDelegate, callback, event) {
            //delegate function for Selected Row Move Up
            $("#" + pluginId).delegate("#" + idToDelegate, event, function delegate(event) {
                $('#' + pluginId).radarChart(callback, event.currentTarget);
            });
        },
    }

    // Define a functional object to hold the api.
    function RadarChartWidgetApi($el, options) {
        this.pluginId = $el.attr("id");
        this.chartId = "chart_" + this.pluginId;
        this.dropdownId = "ddl_" + this.pluginId;
        this.caption = options.caption;
        this.data = options.data;
        this.chartData = [];
        this.dropdownData = [];
        this.chartOptions = options.layout;
        this.enableDropdown = options.enableDropdown;
        this.currentSeries = [];
        this.radarChart = "";
        this.maxComparision = options.maxComparision;
    }

    RadarChartWidgetApi.prototype = {
        init: function () {
            var $this = this,
                pluginId = $("#" + $this.pluginId);
            var height = pluginId.parent().height();
            pluginId.empty();
            var html = "";
            if (this.enableDropdown) {
                html += '<div id="dropdown_block"><select id="' + this.dropdownId + '" multiple class="form-control chosen-select"></select></div>';
            }
            html += '<div id="' + this.chartId + '" style="height: ' + (height - 100) + 'px; padding-top: 10px"></div>';
            pluginId.append(html);
            if (this.enableDropdown) {
                this.setDropdownData();
                this.bindDropdownData();
                $('#' + this.dropdownId).chosen({ no_results_text: "Oops, nothing found!", max_selected_options: this.maxComparision }).change(function (event, data) {
                    if (data.selected) {
                        $this.currentSeries.push(data.selected);
                    } else if (data.deselected) {
                        $this.currentSeries = $this.currentSeries.filter(function (value, index, arr) {
                            if (value != data.deselected) {
                                return value;
                            }
                        });
                    }
                    $this.ondropdownChange();
                });
            }

            this.setChartData();
            this.createChart();
           
            this.radarChart = document.getElementById(this.chartId);
        },
        createChart: function () {                      
            Plotly.plot(this.chartId, this.chartData, this.chartOptions, {
                modeBarButtons: [[
                 {
                     name: "Download as PNG",
                     icon: Plotly.Icons.camera,
                     click: function (gd) {
                         Plotly.downloadImage(gd, {
                             filename: reportCategory,
                             format: 'png',
                             width: gd._fullLayout.width,
                             height: gd._fullLayout.height
                         })
                     }
                 }  //-- for export or image downloading. Download plot as a png                 
                 //, 'sendDataToCloud'
                ]], displaylogo: false, displayModeBar: true
            })
        },
        setChartData: function () {
            this.chartData = convert.chartData(this.data, this.currentSeries);
        },
        setDropdownData: function () {
            this.dropdownData = convert.dropdownData(this.data, this.maxComparision);
        },
        bindDropdownData: function () {
            var dropdownId = this.dropdownId;
            var plugin = this;
            $.each(this.dropdownData, function (i, el) {
                if (i < plugin.maxComparision) {
                    plugin.currentSeries.push(el.text);
                    $("#" + dropdownId).append("<option value='" + el.value + "' selected>" + el.text + "</option>");
                } else {
                    $("#" + dropdownId).append("<option value='" + el.value + "'>" + el.text + "</option>");
                }
            });
        },
        ondropdownChange: function (data) {
            this.setChartData();
            this.radarChart.data = this.chartData;
            this.redrawChart();
        },
        updateChartData: function () {
            this.redrawChart();
        },
        redrawChart: function () {
            Plotly.redraw(this.radarChart);
        },
    };

    // Create the plugin name and defaults once
    var pluginName = 'radarChart';

    // add the plugin to the jQuery.fn object
    $.fn[pluginName] = function () {
        var option = arguments[0],
            args = arguments,
            value,
            allowedMethods = ["setData", "ondropdownChange"];

        this.each(function () {
            var $this = $(this),
                data = $this.data("radarChart"),
                options = $.extend({}, $.fn.radarChart.defaults, $this.data(), typeof option === "object" && option);

            if (typeof option === "string") {
                //Check the method available to access outside
                if ($.inArray(option, allowedMethods) < 0) {
                    throw "Method " + option + " does not exist on radarChart";
                }
                //call the allowed methods
                if (typeof args[1] !== "undefined") {
                    value = data[option](args[1]);
                } else {
                    value = data[option]();
                }
            } else {
                data = new RadarChartWidgetApi($this, options);
                $this.data("radarChart", data);
                data.init(this.id);
            }
        });
        return value === "undefined" ? this : value;
    };
    $.fn[pluginName].defaults = {
        caption: "RadarChart",
        enableDropdown: false,
        maxComparision : 3
    };
})(jQuery);
