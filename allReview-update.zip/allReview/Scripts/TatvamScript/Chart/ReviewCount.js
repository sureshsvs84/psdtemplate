﻿function CreateReviewCount(divId,iconId,  value, reportCategory, icon) {
    $("#" + divId).attr("id", reportCategory.replace(/ /g, ''));    
    $("#" + reportCategory.replace(/ /g, '')).append(value);
    $("#" + iconId).attr("class", icon);
}


function GetReviewCountData(reportId) {
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        $("#review_count_" + reportId).css('display', 'block');
        if(data.Result === null){
            $("#review_count_" + reportId).empty();
            $("#review_count_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if(data.Result === 0){
            
            $("#review_count_" + reportId).empty();
            $("#review_count_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        } else{
            $("#review_icon_" + reportId).empty();
            $("#review_" + reportId).empty();
            CreateReviewCount("review_" + reportId, "review_icon_" + reportId, data.Result, data.Report.ReportCategory, data.Report.Icon);
        }
        $('#chartloader_' + reportId).css('display', 'none');
    }).fail(function() {  
        $("#count").empty();  
        $("#review_" + reportId).empty();  
        $("#review_" + reportId).append("Something went wrong."); 
    }).always(function() { 
        $("#chartloader_" + reportId).css('display', 'none');
    });
}
