﻿function CreateEmoticon(reportName, score, reportID) {
    $('#value_' + reportID).append(score);
    var scoreclass = $("#smile_" + reportID).find('.' + Math.round(parseFloat(score)));
    scoreclass.css("opacity", "1");
    $('#value_' + reportID).parent().css("opacity", "1");
    $('#smile_' + reportID).css('display', 'block');
}

function GetEmoticonChartData(reportId) {
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {        
        var reportName = data.Report.ReportCategory.replace(/ /g, '');
        if(data.Result === null){
            $("#smile_" + reportId).css('display', 'block');
            $("#smile_" + reportId).empty();
            $("#smile_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if(data.Result.length === 0){
            $("#smile_" + reportId).css('display', 'block');
            $("#smile_" + reportId).empty();
            $("#smile_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else if ((typeof (data.Result.toFixed(2)) === "undefined") || data.Result.toFixed(2) === "0.00" || data.Result === 0)
        {
            $("#smile_" + reportId).css('display', 'block');
            $("#smile_" + reportId).empty();
            $("#smile_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else {
            $("#value_" + reportId).empty();            
            CreateEmoticon(reportName, data.Result.toFixed(2), reportId);
        }
        $("#chartloader_" + reportId).css('display', 'none');
    })
        .fail(function () { $('#smile').css('display', 'block'); $("#smile").empty(); $("#smile").append("Something went wrong."); })
        .always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}