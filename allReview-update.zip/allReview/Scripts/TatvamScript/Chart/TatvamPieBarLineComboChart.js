﻿
// Tatvam Pie Bar Line Combo chart 
(function ($) {
    var group = "All";
    var comboDataSet;
    /*
        ################ FORMATS ##################        
    */

    var bar = {
        tatvam_bar_chart_data: function (datasetBarChart, selectedGroup) {
            var ds = [];
            var i = 0;
            var x = [];
            var y = [];
            var maxValue = 0;
            for (val in datasetBarChart) {
                if (selectedGroup === "All") {
                    if (datasetBarChart[val].Group !== "All") {
                        if (maxValue < datasetBarChart[val].Measure)
                            maxValue = datasetBarChart[val].Measure;
                        x.push(datasetBarChart[val].Category);
                        y.push(parseFloat(datasetBarChart[val].Measure));
                    }
                } else {
                    if (datasetBarChart[val].Group === selectedGroup) {
                        if (maxValue < datasetBarChart[val].Measure)
                            maxValue = datasetBarChart[val].Measure;
                        x.push(datasetBarChart[val].Category);
                        y.push(parseFloat(datasetBarChart[val].Measure));
                    }
                }
            }

            ds.push({
                x: x,
                y: y,
                yaxis: 'y1',
                name: '',
                type: 'bar',
                hoverinfo: 'x+y+name+text',
                marker: {
                    color: myColors[i]
                    //symbol: shapes[i]
                },
                line: {
                    color: myColors[i]
                }, "visible": true
            });

            return [{ dataset: ds, maxValue: maxValue }];

        },
        create_tatvam_bar_chart: function (datasetBarChart, datasetLineChart, reportDetails) {
            var firstDatasetBarChart = [];

            var rotationlabel = reportDetails.RotationLabel;
            var xAxisCaption = reportDetails.XAxisCaption;
            var y0AxisCaption = reportDetails.Y0AxisCaption;
            var y1AxisCaption = reportDetails.Y1AxisCaption;
            var y0AxisFormat = reportDetails.Y0AxisFormat;
            var y1AxisFormat = reportDetails.Y1AxisFormat;
            var y0Min = reportDetails.Y0AxisMin;
            var y0Max;
            var y1Min = reportDetails.Y1AxisMin;
            var y1Max = reportDetails.Y1AxisMax;
            var bardata = bar.tatvam_bar_chart_data(datasetBarChart, group);

            firstDatasetBarChart.push(bardata[0].dataset[0]);

            var value = GetYaxisMaxValue(bardata[0].maxValue);

            if (y0AxisFormat === '%') {
                y0Max = 1.05;
            }
            else {
                y0Max = value[0].max + .9;
            }

            var dtick = value[0].dtick;

            var dataSetres = bar.tatvam_line_chart_data(datasetLineChart, group);

            firstDatasetBarChart.push(dataSetres[0].dataset[0]);

            if (y1AxisFormat === '%') {
                y1Max = 1.05;
            }
            else {
                y1Max = y1Max + .9;
            }
            var xmax = 10;
            if (firstDatasetBarChart[0].x.length < xmax)
                xmax = firstDatasetBarChart[0].x.length;

            var tickvals = dataSetres[0].tickvals;
            var ticktext = dataSetres[0].ticktext;

            var layout = {
                titlefont: { size: 11, color: "#444" },
                autosize: false,
                height: 450,
                width: 765,
                title: group + " - Sub Classification",
                showlegend: false,
                xaxis: { title: xAxisCaption, titlefont: { family: "'Roboto',sans-serif", size: 13 }, showline: true, tickangle: rotationlabel, range: [-1, xmax], tickvals: tickvals, ticktext: ticktext },
                yaxis: { title: y0AxisCaption, titlefont: { family: "'Roboto',sans-serif", size: 13 }, showline: true, showgrid: true, tickformat: y0AxisFormat, range: [y0Min, y0Max], fixedrange: true, dtick: dtick },
                yaxis2: { title: y1AxisCaption, titlefont: { family: "'Roboto',sans-serif", size: 13 }, showline: true, showgrid: false, range: [y1Min, y1Max], overlaying: 'y', side: 'right', tickformat: y1AxisFormat, dtick: 1, fixedrange: true },
                //margin: { l: 100, r: 1, b: 80, pad: 0, t: 40 },
                legend: { x: 0, y: 5, borderwidth: 0, bordercolor: "#ffffff" },
                hovermode: 'closest'
            };

            firstDatasetBarChart.forEach(function (trace) {
                trace.text = trace.y.map(function (v, i) {
                    var convertedValue = v;
                    var hoverValue = v;
                    if (trace.yaxis === 'y1') {
                        convertedValue = ConvertTatvamDataFormat(v, y0AxisFormat);
                    }
                    else if (trace.yaxis === 'y2') {
                        convertedValue = ConvertTatvamDataFormat(v, y1AxisFormat);
                    }

                    if (v !== 0)
                        hoverValue = trace.name + "<br>(" + trace.x[i] + "," + convertedValue + ")";
                    return hoverValue || null;
                });

                trace.hoverinfo = 'text';
            });


            Plotly.newPlot('barlineChart', firstDatasetBarChart, layout, {
                modeBarButtons: [[
                  {
                      name: "Download as PNG",
                      icon: Plotly.Icons.camera,
                      click: function (gd) {
                          Plotly.downloadImage(gd, {
                              filename: group + " - Sub Classification",
                              format: 'png',
                              width: gd._fullLayout.width,
                              height: gd._fullLayout.height
                          })
                      }
                  },  //-- for export or image downloading. Download plot as a png
                  'hoverClosestCartesian',//show the respective values for the selected category on hovering on the point.
                  'hoverCompareCartesian'//compare the values of all the categories on hovering on the point.
                ]], displaylogo: false, displayModeBar: true
            });
        },
        tatvam_line_chart_data: function (datasetlineChart, selectedGroup) {
            var ds = [];
            var i = 0;
            var x = [];
            var y = [];
            var tickvals = [];
            var ticktext = [];
            for (var val in datasetlineChart) {
                if (selectedGroup === "All") {
                    if (datasetlineChart[val].Group !== "All") {
                        var XAxisValues = datasetlineChart[val].Category;
                        x.push(datasetlineChart[val].Category);
                        y.push(parseFloat(datasetlineChart[val].Measure));

                        /*Check tickvals exist in array*/
                        if (tickvals.indexOf(XAxisValues) === -1) {
                            tickvals.push(XAxisValues);
                            if (XAxisValues.length > 12)
                                ticktext.push(XAxisValues.substr(0, 12) + '...');
                            else
                                ticktext.push(XAxisValues);
                        }
                    }
                } else {
                    if (datasetlineChart[val].Group === selectedGroup) {
                        var XAxisValues = datasetlineChart[val].Category;
                        x.push(datasetlineChart[val].Category);
                        y.push(parseFloat(datasetlineChart[val].Measure));

                        /*Check tickvals exist in array*/
                        if (tickvals.indexOf(XAxisValues) === -1) {
                            tickvals.push(XAxisValues);
                            if (XAxisValues.length > 12)
                                ticktext.push(XAxisValues.substr(0, 12) + '...');
                            else
                                ticktext.push(XAxisValues);
                        }
                    }
                }
            }
            ds.push({
                x: x,
                y: y,
                yaxis: 'y2',
                name: '',
                type: 'scatter',
                hoverinfo: 'x+y+name+text',
                marker: {
                    color: myColors[i + 1]
                    //symbol: shapes[i]
                },
                line: {
                    color: myColors[i + 1],
                    shape: "spline"//linear/spline/hv/vh/hvh/vhv
                }, "visible": true,
                mode: 'lines+markers'
            });
            return [{ dataset: ds, tickvals: tickvals, ticktext: ticktext }];
        }
    }


    /** Creating the Pie Chart **/

    var pie = {
        tatvam_pie_chart: function (dataset, ReportDetail) {
            //Defining the pie chart layout
            var layout = {
                //title: 'Classifiers',
                title: ReportDetail.ReportSubTitle,
                width: 500,
                // height: 500,
                margin: {
                    l: 5,
                    r: 5,
                    // b: 150,
                    pad: 0,
                    t: 25
                },
                legend: { borderwidth: 0, bordercolor: "#ffffff" },
                annotations: [{
                    font: {
                        size: 14
                    },
                    showarrow: false,
                    text: "<a>All</a>",
                    x: 0.50,
                    y: 0.5
                }]
            };

            //Get Pie Chart Data
            var pieChartData = pie.tatvam_pie_chart_data(dataset);

            var trace = pieChartData[0];
            var total = trace.values.reduce(function (a, b) {
                return a + b;
            });


            trace.text = trace.values.map(function (v) {
                return ((v / 2000) * 100).toFixed(2) + '%';
            });

            trace.hoverinfo = 'value+label';


            //Create Pie Chart
            Plotly.newPlot('pieChart', pieChartData, layout, {
                modeBarButtons: [[
                  {
                      name: "Download as PNG",
                      icon: Plotly.Icons.camera,
                      click: function (gd) {
                          Plotly.downloadImage(gd, {
                              filename: ReportDetail.ReportSubTitle,
                              format: 'png',
                              width: gd._fullLayout.width,
                              height: gd._fullLayout.height
                          })
                      }
                  },  //-- for export or image downloading. Download plot as a png
                 // 'hoverClosestCartesian',//show the respective values for the selected category on hovering on the point.
                //  'hoverCompareCartesian',//compare the values of all the categories on hovering on the point.
                ]], displaylogo: false, displayModeBar: true
            });

            //Update Bar Chart Based on Button Click
            var myPlot1 = document.getElementById('pieChart');//Getting the div ID
            myPlot1.on('plotly_click', function (sdata) {
                var selectedSegment = sdata.points[0].label;
                group = selectedSegment;
                bar.create_tatvam_bar_chart(comboDataSet.Result.BarData, comboDataSet.Result.LineData, comboDataSet.Report.ReportDetail);
            });

            myPlot1.on('plotly_relayout', function (sdata) {
                $(".annotation-text > a").on('click', function () {
                    group = "All";
                    bar.create_tatvam_bar_chart(comboDataSet.Result.BarData, comboDataSet.Result.LineData, comboDataSet.Report.ReportDetail);
                });
            });
            $(".annotation-text > a").on('click', function () {
                group = "All";
                bar.create_tatvam_bar_chart(comboDataSet.Result.BarData, comboDataSet.Result.LineData, comboDataSet.Report.ReportDetail);
            });
        },
        tatvam_pie_chart_data: function (piedata) {
            var dataset = [];
            var values = [];
            var labels = [];
            for (var i = 0; i < piedata.length; i++) {
                labels.push(piedata[i].Category);
                values.push(parseFloat(piedata[i].Measure));
            }
            dataset.push({
                values: values,
                labels: labels,
                type: 'pie',
                hole: .4,
                //name: 'All',
                marker: {
                    colors: myColors,
                    line: {
                        width: 1,
                        color: "rgb(255, 255, 255)"
                    }
                },
                textfont: {
                    color: "rgb(255, 255, 255)"
                },
                textinfo: "label" //value/percent/label/none/label+value/label+percent/value+percent
            });
            return dataset;
        }

    }


    var methods = {
        init: function (options) {
            this.TatvamPieBarLineCombo.settings = $.extend({}, this.TatvamPieBarLineCombo.defaults, options);
            return this.each(function () {
                var $element = $(this), // reference to the jQuery version of the current DOM element
                     element = this;      // reference to the actual DOM element                    
            });
        },

        // a public method. to draw the pie+bar+line combo chart!
        create_tatvamPieBarLineCombo: function (data) {
            if (data.Result.PieData.length === 0) {
                $("#pieChart").append("<div class=\'nodata\'>No Data Available.</div>");
                $("#barlineChart").append("<div class=\'nodata\'>No Data Available.</div>");

                return;
            }
            var maxValue = 0;
            for (var i = 0; i < data.Result.PieData.length; i++) {
                if (maxValue < data.Result.PieData[i].measure) {
                    maxValue = data.Result.PieData[i].measure;
                    //group = data[0].PieData[i].category;
                }
            }

            comboDataSet = data;


            if (comboDataSet === null || comboDataSet.length === 0) {
                $('#pieChart').append("<div class=\'nodata\'>No Data Available.</div>");
                return;
            }
            //Create a pie Chart
            pie.tatvam_pie_chart(data.Result.PieData, data.Report.ReportDetail);

            //Create a bar Chart
            bar.create_tatvam_bar_chart(data.Result.BarData, data.Result.LineData, data.Report.ReportDetail);
        }
    }


    $.fn.TatvamPieBarLineCombo = function (method) {
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            $.error('Method "' + method + '" does not exist in TatvamPieBarLineCombo plugin!');
        }
    }



})(jQuery);


function GetPieBarLineComboData(reportId) {
    $.getJSON("../Data/GetPieBarLineData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        $('#plotly_chart_' + reportId).css('display', 'block');
        $("#pieChart").TatvamPieBarLineCombo("create_tatvamPieBarLineCombo", data);
    }).fail(function() {  $("#plotly_chart_" + reportId).append("Something went wrong.");  }).always(function() { $("#chartloader_" + reportId).css('display', 'none'); });

}