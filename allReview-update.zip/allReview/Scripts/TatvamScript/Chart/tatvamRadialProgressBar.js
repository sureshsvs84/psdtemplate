/*
 * NPS Plugin
 * Copyright (c) 2017
 * Depends:
 *   - jQuery v3.1.0+
 *   - bootstrap
 *   - bootbox
 * @author Nithya Rani
 * @version 1.0.0
 * 
 */
(function ($) {
    'use strict';

    /**         
     * 
     * Provides the ability to Read/Set/Get the Constant Details. 
     * These methods will be used only inside the plugin. 
     * Will not be exposed to the end user.
     * 
     * @param
     * 
     * @event
     * 
     * @return
     *      The DOM elemtns based on the type of Templates
     */
    var exceptionHandling = {
            log: function (mesage) {
                console.log(mesage);
            },
            error: function (mesage) {
                console.error(mesage);
            }
        },
        createTemplate = {
            /**         
             * 
             * Provides the ability to manipulate the HTML template for each progress bar. 
             * This also bind the progress bar to the widget control
             * These methods will be used only inside the plugin. 
             * Will not be exposed to the end user.
             * 
             * @param {$pluginId}
             *      Accept the plugin id
             * @param {options}
             *      Accept the one progress bar data
             * @event
             * 
             * @return
             *      The DOM elements using the plugin id
             */
            createProgressTemplate: function ($obj, options) {
                var defaults = {
                    "inline": true,
                    "font-size": 40,
                    "font-family": "Helvetica, Arial, sans-serif",
                    "text-color": null,
                    "lines": 1,
                    "line": 0,
                    "symbol": "",
                    "margin": 0,
                    "color": "rgb(55,123,181)",
                    "background": "rgba(0,0,0,0.1)",
                    "size": $obj.outerWidth(),
                    "fill": "5px",
                    "range": [0, 100]
                };

                this.options = $.extend(defaults, options);
                this.first_rot_base = -135;
                this.second_rot_base = -315;
                this.options.size = parseInt(this.options.size, 10);
                this.options.fill = parseInt(this.options.fill, 10);
                this.options['font-size'] = parseInt(this.options['font-size'], 10);
                this.options.margin = Math.max(0, parseInt(this.options.margin, 10));
                this.options['text-color'] = this.options['text-color'] || this.options.color;


                $obj.css({
                    "position": "relative",
                    "width": this.options.size,
                    "height": this.options.size,
                    "display": this.options.inline ? "inline-block" : "block"
                });

                /**
                 * create the progress bar circle
                 */
                this.$radialBackground = $("<div>").appendTo($obj).css({
                    "box-sizing": "border-box",
                    "-moz-box-sizing": "border-box",
                    "-webkit-box-sizing": "border-box",
                    "position": "absolute",
                    "top": this.options.margin,
                    "left": this.options.margin,
                    "width": this.options.size - this.options.margin * 2,
                    "height": this.options.size - this.options.margin * 2,
                    "border": this.options.fill + "px dotted " + this.options.background,
                    //"border": this.options.fill + "px solid #ff0000",
                    "border-radius": Math.ceil(this.options.size / 2) + "px",
                });
                /**
                 * Right side of the progress bar
                 */
                this.$radialFirstHalfMask = $("<div>").appendTo($obj).css({
                    "position": "absolute",
                    "top": this.options.margin,
                    "right": this.options.margin,
                    "width": Math.round(this.options.size / 2) - this.options.margin,
                    "height": this.options.size - this.options.margin * 2,
                    "overflow": "hidden"
                });

                this.$radialFirstHalf = $("<div>").appendTo(this.$radialFirstHalfMask).css({
                    "box-sizing": "border-box",
                    "-moz-box-sizing": "border-box",
                    "-webkit-box-sizing": "border-box",
                    "position": "absolute",
                    "top": "0px",
                    "border-width": this.options.fill,
                    "border-style": "solid",
                    "border-color": this.options.color + " " + this.options.color + " transparent transparent",
                    "width": "200%",
                    "height": "100%",
                    "border-radius": "50%",
                    "left": "-100%",
                    "transform": "rotate(" + this.first_rot_base + "deg)"
                });


                /**
                 * Left side of the progress bar
                 */
                this.$radialSecondHalfMask = $("<div>").appendTo($obj).css({
                    "position": "absolute",
                    "top": this.options.margin,
                    "left": this.options.margin,
                    "width": Math.round(this.options.size / 2) - this.options.margin,
                    "height": this.options.size - this.options.margin * 2,
                    "overflow": "hidden"
                });


                this.$radialSecondHalf = $("<div>").appendTo(this.$radialSecondHalfMask).css({
                    "box-sizing": "border-box",
                    "-moz-box-sizing": "border-box",
                    "-webkit-box-sizing": "border-box",
                    "position": "absolute",
                    "top": "0px",
                    "border-width": this.options.fill,
                    "border-style": "solid",
                    "border-color": this.options.color + " " + this.options.color + " transparent transparent",
                    "width": "200%",
                    "height": "100%",
                    "border-radius": "50%",
                    "left": "0px",
                    "transform": "rotate(" + this.second_rot_base + "deg)"
                });
                if (this.options['text-color']) {
                    this.$radialLabel = $("<div id='radial_label'>").appendTo($obj).css({
                        "position": "absolute",
                        "font-size": "17px",
                        "font-family": this.options['font-family'],
                        "font-weight" : "bold",
                        "color": '#4f4c4c',
                        "left": "50%",
                        "top": "50%",
                        "transform": "translate(-50%, -50%)"
                    });
                }

                this.percentage = 0;
                this.queue = [];
                return this;
            },

        };


    function TatvamRadialProgressBar($el, options) {
        this.pluginId = $el.attr("id");
        this.data = ""; // placeholder to keep the original clean input data
        this.caption = options.caption;
        this.enableClose = options.enableClose;
        this.onClose = options.onClose !== "undefined" ? options.onClose : "";
        this.language = options.language;
        var $obj = $("#" + this.pluginId);
        this.queue = options.queue;
        //this.inline = options.inline;
        //this['font-size'] = options['font-size'];
        //this['font-family'] = options['font-family'];
        //this['text-color'] = options['text-color'];
        //this.lines = options.lines;
        //this.line = options.line;
        //this.symbol = options.symbol;
        //this.margin = options.margin;
        //this.color = options.color;
        //this.background = options.background;

        //this.size = $obj.outerWidth();
        //this.fill = options.fill;
        //this.range = options.range;
        //this.first_rot_base = options.first_rot_base;
        //this.second_rot_base = options.second_rot_base;
        this.options = $.extend(this, options);
        // this.options.size = parseInt(this.size, 10);
        // this.options.fill = parseInt(options.fill, 10);
        // this.options['font-size'] = parseInt(options['font-size'], 10);
        // this.options.margin = Math.max(0, parseInt(options.margin, 10));
        //this.percentage = 0;
        //this.options.percentage = 0;
    }

    TatvamRadialProgressBar.prototype = {
        init: function () {

        },
        /**
         * Create the Filter Gadget based on the given field name and field type
         */
        createNPSWidget: function (data) {
            if (data === "undefined") {
                exceptionHandling.error(this.filterConstant.errorMessages.inputNotProvided);
                return;
            }

            if (data === "") {
                exceptionHandling.error(this.filterConstant.errorMessages.blankInput);
                return;
            }
            this.createProgress(data);
        },
        /**
         * Set the User input
         * 
         * @param {inpModel}
         *      set the Filter Data to the Input
         */
        setData: function (inpModel) {
            this.data = inpModel;
            this.createProgress();
        },
        /**
         * Set the Caption of the widget
         * 
         * @param {caption}
         *      set the caption to the label
         */
        setCaption: function (caption) {
            if (caption === "") {
                exceptionHandling.error();
                return;
            }
            this.caption = caption;
            $("#caption_" + this.pluginId).empty();
            $("#caption_" + this.pluginId).append(this.caption);
        },
        /**
         * return the widget Caption
         */
        getCaption: function () {
            return this.caption;
        },
        /**
         * Create Progress for the input data
         */
        createProgress: function () {
            var $this = this;

            var space = $this.space || 2,
                segmentFill = Math.floor($this.fill / $this.data.length) - space,
                margin = 0;

            for (var i = 0; i < $this.data.length; i++) {
                var obj = $this.data[i];
                var tempFill = {
                    'fill': segmentFill,
                    'margin': margin,
                    'lines': $this.data.length,
                    'line': obj.index,
                    'color': obj.color
                };
                $("#" + this.pluginId).data("__multiProgress" + obj.index, new createTemplate.createProgressTemplate($("#" + this.pluginId), $.extend(this, obj, tempFill), obj.index));
                margin += segmentFill + space;

                this.progressToPercentage({
                    "index": $this.data[i].index,
                    'percentage': $this.data[i].percentage,
                    'time': $this.data[i].time
                });
            }
            var promoters = 0;
            var detractors = 0;
            $.each(this.data, function(i,obj) {
                if (obj.label === "Promoters") {
                    promoters = obj.percentage;
                }
                if (obj.label === "Detractors") {
                    detractors = obj.percentage;
                }
            });
            var overAllScore = (promoters - detractors).toFixed(0);
            if (overAllScore > 0) {
                overAllScore = "+" + overAllScore;
            }
            $("#radial_label").text(overAllScore);
        },

        progressToPercentage: function (options) {
            var self = $("#" + this.pluginId).data("__multiProgress" + options.index),
                offset = options.offset || 0,
                interval_delay = 10,
                time = options.time || 1000,
                targetPerc = Math.max(0, Math.min(100, (options.percentage - self.options.range[0]) / (self.options.range[1] - self.options.range[0]) * 100)),
                diffPerc = targetPerc - self.percentage,
                direction = diffPerc / Math.abs(diffPerc),
                step = diffPerc / (time / interval_delay);
            if (!self.animation) {
                self.animation = setInterval(function () {
                    if ((direction > 0 && self.percentage >= targetPerc) || (direction < 0 && self.percentage <= targetPerc)) {
                        window.clearInterval(self.animation);
                        self.animation = null;
                        var next = self.queue.shift();
                        if (next) {
                            self.progressToPercentage(next);
                        }
                        return;
                    }
                    self.percentage += step;
                    var first_rot = self.first_rot_base;
                    var second_rot = self.second_rot_base;
                    if (self.percentage < 50) {
                        first_rot = self.first_rot_base + (self.percentage / 50) * 180;
                        second_rot = self.second_rot_base;
                    } else {
                        first_rot = self.first_rot_base + 1 * 180;
                        second_rot = self.second_rot_base + ((self.percentage - 50) / 50) * 180;
                    }
                    self.$radialFirstHalf.css({
                        "transform": "rotate(" + first_rot + "deg)"
                    });
                    self.$radialSecondHalf.css({
                        "transform": "rotate(" + second_rot + "deg)"
                    });
                    //if (self.$radialLabel) {
                    //    var value = targetPerc ? self.percentage / targetPerc * (targetPerc - offset) : 0;
                    //    value = self.options.range[0] + value / 100 * (self.options.range[1] - self.options.range[0]);
                    //    var text = Math.round(value + self.options.symbol);
                    //    for (var ti = 0; ti < self.options.line; ti++) {
                    //        text = "&nbsp;<br>" + text;
                    //    }
                    //    for (var tj = self.options.lines - (self.options.line + 1); tj > 0; tj--) {
                    //        text = text + "<br>&nbsp;";
                    //    }
                    //    self.$radialLabel.html(text);
                    //}
                }, interval_delay);
            } else {
                this.queue.push(options);
            }
        }
    };


    // add the plugin to the jQuery.fn object
    $.fn.TatvamRadialProgressBar = function () {
        var option = arguments[0],
            args = arguments,
            value,
            allowedMethods = ["setData", "setCaption", "getCaption", "progressToPercentage"];
        this.each(function () {
            var $this = $(this),
                data = $this.data('TatvamRadialProgressBar'),
                options = $.extend({}, $.fn.TatvamRadialProgressBar.defaults, $this.data(), typeof option === "object" && option);
            if (typeof option === 'string') {
                //Check the method available to access outside
                if ($.inArray(option, allowedMethods) < 0) {
                    throw 'Method ' + option + ' does not exist on TatvamRadialProgressBar';
                }
                //call the allowed methods
                value = data[option](args[1]);
            } else {
                data = new TatvamRadialProgressBar($this, options);
                $this.data('TatvamRadialProgressBar', data);
                data.init(this.id);
            }
        });
        return typeof value !== 'undefined' ? value : this;
    };
    $.fn.TatvamRadialProgressBar.defaults = {
        // We define an empty function so that
        // we don't need to check its existence before calling it.
        caption: 'Widget Caption'    
    };
})(jQuery);
