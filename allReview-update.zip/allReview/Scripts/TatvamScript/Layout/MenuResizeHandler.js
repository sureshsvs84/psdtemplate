jQuery(document).ready(function() {
    Metronic.init();
    Layout.init();
});


$(document).ready(function() {
    var setElementHeight = function() {
        var height = $(window).height();
        $('.page-sidebar-menu').css('height', (height));
    };

    $(window).on("resize", function() {
            setElementHeight();
        })
        .resize();
});

var Metronic = function() {
    var resizeHandlers = [];
    var assetsPath = '../../assets/';
    return {
        init: function() {
        },

        addResizeHandler: function(func) {
            resizeHandlers.push(func);
        },

        destroySlimScroll: function(el) {
            $(el).each(function() {
                if ($(this).attr("data-initialized") === "1") {
                }
            });
        },
        isTouchDevice: function() {
            try {
                document.createEvent("TouchEvent");
                return true;
            } catch (e) {
                return false;
            }
        },

        // To get the correct viewport width based on  http://andylangton.co.uk/articles/javascript/get-viewport-size-javascript/
        getViewPort: function() {
            var e = window,
                a = 'inner';
            if (!('innerWidth' in window)) {
                a = 'client';
                e = document.documentElement || document.body;
            }

            return {
                width: e[a + 'Width'],
                height: e[a + 'Height']
            };
        },
        getAssetsPath: function() {
            return assetsPath;
        }
    };
}();