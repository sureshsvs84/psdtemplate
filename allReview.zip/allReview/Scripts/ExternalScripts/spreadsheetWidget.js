/**
 * @author
 * @version 1.0.0
 *
 **/
(function Spreadsheet($) {
    "use strict";
    var formatting = {
        colorPicker: function (pluginId) {
            $("#fontColorpicker" + pluginId).spectrum({
                showPaletteOnly: true,
                togglePaletteOnly: true,
                togglePaletteMoreText: 'More',
                togglePaletteLessText: 'Less',
                hideAfterPaletteSelect: true,
                color: "#000",
                chooseText: "Choose",
                cancelText: "Cancel",
                change: function (color) {
                    var barColor = color.toHexString(),
                        plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                    $('#' + plugin).spreadsheetWidget('fontColor', barColor);
                },
                palette: [
                    ["rgb(0, 0, 0)", "rgb(67, 67, 67)", "rgb(102, 102, 102)", "rgb(204, 204, 204)", "rgb(217, 217, 217)", "rgb(255, 255, 255)"],
                    ["rgb(152, 0, 0)", "rgb(255, 0, 0)", "rgb(255, 153, 0)", "rgb(255, 255, 0)", "rgb(0, 255, 0)", "rgb(0, 255, 255)", "rgb(74, 134, 232)", "rgb(0, 0, 255)", "rgb(153, 0, 255)", "rgb(255, 0, 255)"],
                    ["rgb(230, 184, 175)", "rgb(244, 204, 204)", "rgb(252, 229, 205)", "rgb(255, 242, 204)", "rgb(217, 234, 211)", "rgb(208, 224, 227)", "rgb(201, 218, 248)", "rgb(207, 226, 243)", "rgb(217, 210, 233)", "rgb(234, 209, 220)", "rgb(221, 126, 107)", "rgb(234, 153, 153)", "rgb(249, 203, 156)", "rgb(255, 229, 153)", "rgb(182, 215, 168)", "rgb(162, 196, 201)", "rgb(164, 194, 244)", "rgb(159, 197, 232)", "rgb(180, 167, 214)", "rgb(213, 166, 189)", "rgb(204, 65, 37)", "rgb(224, 102, 102)", "rgb(246, 178, 107)", "rgb(255, 217, 102)", "rgb(147, 196, 125)", "rgb(118, 165, 175)", "rgb(109, 158, 235)", "rgb(111, 168, 220)", "rgb(142, 124, 195)", "rgb(194, 123, 160)", "rgb(166, 28, 0)", "rgb(204, 0, 0)", "rgb(230, 145, 56)", "rgb(241, 194, 50)", "rgb(106, 168, 79)", "rgb(69, 129, 142)", "rgb(60, 120, 216)", "rgb(61, 133, 198)", "rgb(103, 78, 167)", "rgb(166, 77, 121)", "rgb(91, 15, 0)", "rgb(102, 0, 0)", "rgb(120, 63, 4)", "rgb(127, 96, 0)", "rgb(39, 78, 19)", "rgb(12, 52, 61)", "rgb(28, 69, 135)", "rgb(7, 55, 99)", "rgb(32, 18, 77)", "rgb(76, 17, 48)"]
                ]
            });
            $("#fillColorpicker" + pluginId).spectrum({
                showPaletteOnly: true,
                togglePaletteOnly: true,
                togglePaletteMoreText: 'More',
                togglePaletteLessText: 'Less',
                hideAfterPaletteSelect: true,
                color: "#fff",
                chooseText: "Choose",
                cancelText: "Cancel",
                change: function (color) {
                    var selColor = color.toHexString(),
                        plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                    $('#' + plugin).spreadsheetWidget('backgroundColor', selColor);
                },
                palette: [
                    ["rgb(0, 0, 0)", "rgb(67, 67, 67)", "rgb(102, 102, 102)", "rgb(204, 204, 204)", "rgb(217, 217, 217)", "rgb(255, 255, 255)"],
                    ["rgb(152, 0, 0)", "rgb(255, 0, 0)", "rgb(255, 153, 0)", "rgb(255, 255, 0)", "rgb(0, 255, 0)", "rgb(0, 255, 255)", "rgb(74, 134, 232)", "rgb(0, 0, 255)", "rgb(153, 0, 255)", "rgb(255, 0, 255)"],
                    ["rgb(230, 184, 175)", "rgb(244, 204, 204)", "rgb(252, 229, 205)", "rgb(255, 242, 204)", "rgb(217, 234, 211)", "rgb(208, 224, 227)", "rgb(201, 218, 248)", "rgb(207, 226, 243)", "rgb(217, 210, 233)", "rgb(234, 209, 220)", "rgb(221, 126, 107)", "rgb(234, 153, 153)", "rgb(249, 203, 156)", "rgb(255, 229, 153)", "rgb(182, 215, 168)", "rgb(162, 196, 201)", "rgb(164, 194, 244)", "rgb(159, 197, 232)", "rgb(180, 167, 214)", "rgb(213, 166, 189)", "rgb(204, 65, 37)", "rgb(224, 102, 102)", "rgb(246, 178, 107)", "rgb(255, 217, 102)", "rgb(147, 196, 125)", "rgb(118, 165, 175)", "rgb(109, 158, 235)", "rgb(111, 168, 220)", "rgb(142, 124, 195)", "rgb(194, 123, 160)", "rgb(166, 28, 0)", "rgb(204, 0, 0)", "rgb(230, 145, 56)", "rgb(241, 194, 50)", "rgb(106, 168, 79)", "rgb(69, 129, 142)", "rgb(60, 120, 216)", "rgb(61, 133, 198)", "rgb(103, 78, 167)", "rgb(166, 77, 121)", "rgb(91, 15, 0)", "rgb(102, 0, 0)", "rgb(120, 63, 4)", "rgb(127, 96, 0)", "rgb(39, 78, 19)", "rgb(12, 52, 61)", "rgb(28, 69, 135)", "rgb(7, 55, 99)", "rgb(32, 18, 77)", "rgb(76, 17, 48)"]
                ]
            });
            $("#byRulesColorpicker" + pluginId).spectrum({
                showPaletteOnly: true,
                togglePaletteOnly: true,
                togglePaletteMoreText: 'More',
                togglePaletteLessText: 'Less',
                hideAfterPaletteSelect: true,
                color: "#fff",
                chooseText: "Choose",
                cancelText: "Cancel",
                palette: [
                    ["rgb(0, 0, 0)", "rgb(67, 67, 67)", "rgb(102, 102, 102)", "rgb(204, 204, 204)", "rgb(217, 217, 217)", "rgb(255, 255, 255)"],
                    ["rgb(152, 0, 0)", "rgb(255, 0, 0)", "rgb(255, 153, 0)", "rgb(255, 255, 0)", "rgb(0, 255, 0)", "rgb(0, 255, 255)", "rgb(74, 134, 232)", "rgb(0, 0, 255)", "rgb(153, 0, 255)", "rgb(255, 0, 255)"],
                    ["rgb(230, 184, 175)", "rgb(244, 204, 204)", "rgb(252, 229, 205)", "rgb(255, 242, 204)", "rgb(217, 234, 211)", "rgb(208, 224, 227)", "rgb(201, 218, 248)", "rgb(207, 226, 243)", "rgb(217, 210, 233)", "rgb(234, 209, 220)", "rgb(221, 126, 107)", "rgb(234, 153, 153)", "rgb(249, 203, 156)", "rgb(255, 229, 153)", "rgb(182, 215, 168)", "rgb(162, 196, 201)", "rgb(164, 194, 244)", "rgb(159, 197, 232)", "rgb(180, 167, 214)", "rgb(213, 166, 189)", "rgb(204, 65, 37)", "rgb(224, 102, 102)", "rgb(246, 178, 107)", "rgb(255, 217, 102)", "rgb(147, 196, 125)", "rgb(118, 165, 175)", "rgb(109, 158, 235)", "rgb(111, 168, 220)", "rgb(142, 124, 195)", "rgb(194, 123, 160)", "rgb(166, 28, 0)", "rgb(204, 0, 0)", "rgb(230, 145, 56)", "rgb(241, 194, 50)", "rgb(106, 168, 79)", "rgb(69, 129, 142)", "rgb(60, 120, 216)", "rgb(61, 133, 198)", "rgb(103, 78, 167)", "rgb(166, 77, 121)", "rgb(91, 15, 0)", "rgb(102, 0, 0)", "rgb(120, 63, 4)", "rgb(127, 96, 0)", "rgb(39, 78, 19)", "rgb(12, 52, 61)", "rgb(28, 69, 135)", "rgb(7, 55, 99)", "rgb(32, 18, 77)", "rgb(76, 17, 48)"]
                ]
            });
        },
        colorByValueColorPicker: function (pluginID, colorPickerId, color, callBack) {
            $("#" + colorPickerId).spectrum({
                color: color,
                showInput: true,
                className: "full-spectrum",
                showInitial: true,
                showPalette: false,
                showSelectionPalette: false,
                maxSelectionSize: 10,
                preferredFormat: "hex",
                chooseText: "Choose",
                cancelText: "Cancel",
                change: function (color) {
                    $("#" + pluginID).spreadsheetWidget(callBack, color.toHexString());
                    var mid = $("#" + pluginID).spreadsheetWidget('getgradientMidColor');
                    var max = $("#" + pluginID).spreadsheetWidget('getgradientMaxColor');
                    var min = $("#" + pluginID).spreadsheetWidget('getgradientMinColor');
                    $("#" + pluginID + " .gradientArea").css({
                        "background": "linear-gradient(to right," + min + "," + mid + "," + max + ")"
                    });
                }
            });
        },
        gridColorPickerById: function (pluginID, ruleID) {
            $("#ColorGridColorpicker_" + ruleID).spectrum({
                showPaletteOnly: true,
                togglePaletteOnly: true,
                togglePaletteMoreText: 'More',
                togglePaletteLessText: 'Less',
                hideAfterPaletteSelect: true,
                color: "#fff",
                chooseText: "Choose",
                cancelText: "Cancel",
                change: function (color) {
                    var pointsColor = color.toHexString();
                    $("#" + pluginID).spreadsheetWidget('setGridColorByRule', {
                        pointsColor: pointsColor,
                        ruleID: ruleID
                    });
                },
                palette: [
                    ["rgb(0, 0, 0)", "rgb(67, 67, 67)", "rgb(102, 102, 102)", "rgb(204, 204, 204)", "rgb(217, 217, 217)", "rgb(255, 255, 255)"],
                    ["rgb(152, 0, 0)", "rgb(255, 0, 0)", "rgb(255, 153, 0)", "rgb(255, 255, 0)", "rgb(0, 255, 0)", "rgb(0, 255, 255)", "rgb(74, 134, 232)", "rgb(0, 0, 255)", "rgb(153, 0, 255)", "rgb(255, 0, 255)"],
                    ["rgb(230, 184, 175)", "rgb(244, 204, 204)", "rgb(252, 229, 205)", "rgb(255, 242, 204)", "rgb(217, 234, 211)", "rgb(208, 224, 227)", "rgb(201, 218, 248)", "rgb(207, 226, 243)", "rgb(217, 210, 233)", "rgb(234, 209, 220)", "rgb(221, 126, 107)", "rgb(234, 153, 153)", "rgb(249, 203, 156)", "rgb(255, 229, 153)", "rgb(182, 215, 168)", "rgb(162, 196, 201)", "rgb(164, 194, 244)", "rgb(159, 197, 232)", "rgb(180, 167, 214)", "rgb(213, 166, 189)", "rgb(204, 65, 37)", "rgb(224, 102, 102)", "rgb(246, 178, 107)", "rgb(255, 217, 102)", "rgb(147, 196, 125)", "rgb(118, 165, 175)", "rgb(109, 158, 235)", "rgb(111, 168, 220)", "rgb(142, 124, 195)", "rgb(194, 123, 160)", "rgb(166, 28, 0)", "rgb(204, 0, 0)", "rgb(230, 145, 56)", "rgb(241, 194, 50)", "rgb(106, 168, 79)", "rgb(69, 129, 142)", "rgb(60, 120, 216)", "rgb(61, 133, 198)", "rgb(103, 78, 167)", "rgb(166, 77, 121)", "rgb(91, 15, 0)", "rgb(102, 0, 0)", "rgb(120, 63, 4)", "rgb(127, 96, 0)", "rgb(39, 78, 19)", "rgb(12, 52, 61)", "rgb(28, 69, 135)", "rgb(7, 55, 99)", "rgb(32, 18, 77)", "rgb(76, 17, 48)"]
                ]
            });
        },
        /*format,setRowFormat,setCellFormat should be in one function*/
        format: function (column, property, value, mandatory, isToggle) {
            if (mandatory) {
                column.cellStyle[property] = value;
                return column;
            }
            if (typeof column.cellStyle[property] === 'undefined') {
                column.cellStyle[property] = value;
                return column;
            }
            if (isToggle) {
                delete column.cellStyle[property];
            } else {
                column.cellStyle[property] = value;
            }
            return column;
        },
        setFormat: function (row, property, value, mandatory, isToggle) {
            if (mandatory) {
                row.style[property] = value;
                return row;
            }
            if (typeof row.style[property] === 'undefined') {
                row.style[property] = value;
                return row;
            }
            if (isToggle) {
                delete row.style[property];
            } else {
                row.style[property] = value;
            }
            return row;
        },
        setRowFormat: function (row, property, value, mandatory, isToggle) {
            if (mandatory) {
                row.style[property] = value;
                return row;
            }
            if (typeof row.style[property] === 'undefined') {
                row.style[property] = value;
                return row;
            }
            if (isToggle) {
                delete row.style[property];
            } else {
                row.style[property] = value;
            }
            return row;
        },
        setColFormat: function (col, property, value, mandatory, isToggle) {
            if (mandatory) {
                col.style[property] = value;
                return col;
            }
            if (typeof col.style[property] === 'undefined') {
                col.style[property] = value;
                return col;
            }
            if (isToggle) {
                delete col.style[property];
            } else {
                col.style[property] = value;
            }
            return col;
        },
        setCellFormat: function (cell, property, value, mandatory, isToggle) {
            if (mandatory) {
                cell.style[property] = value;
                return cell;
            }
            if (typeof cell.style[property] === 'undefined') {
                cell.style[property] = value;
                return cell;
            }
            if (isToggle) {
                delete cell.style[property];
            } else {
                cell.style[property] = value;
            }
            return cell;
        },
        rowFormat: function (param) {
            var plugin = param.node.gridOptionsWrapper.gridOptions.myPluginID;
            var getSpreadsheetParam = $('#' + plugin).spreadsheetWidget('getSpreadsheetParam');
            if (getSpreadsheetParam.enableFormatting) {
                var getRowFormat = $('#' + plugin).spreadsheetWidget('getRowFormat');

                var uniqueFieldName = getSpreadsheetParam.uniqueFieldName;
                var style = getRowFormat.filter(function (obj) {
                    return obj.id === param.data[uniqueFieldName];
                })[0]; //Get align for given Data
                if (typeof style !== "undefined") {
                    return style.style;
                }
            }
            return null;
        },
        cellFormat: function (param) {
            var pluginId = param.node.gridOptionsWrapper.gridOptions.myPluginID;
            var getSpreadsheetParam = $('#' + pluginId).spreadsheetWidget('getSpreadsheetParam'),
                colorByRuleStyle = "";

            if (!getSpreadsheetParam.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return {};
            }

            var cellFormat = $("#" + pluginId).spreadsheetWidget('getCellFormat');
            var colFormat = $("#" + pluginId).spreadsheetWidget('getColFormat');

            //Get the color Based on the Condition
            colorByRuleStyle = formatting.getCellRuleColor(pluginId, param.column.colDef.headerName, param.value);


            var uniqueFieldName = getSpreadsheetParam.uniqueFieldName;
            var colFormats = JSON.parse(JSON.stringify(colFormat)); // i AM not sure why getColFormat getting override with cell style when i use directly just for tem purpose i have written this
            var cellStyle = {};
            $.each(colFormats, function (key, value) {
                if (param.column.colId === value.col) {
                    cellStyle = value.style;
                }
            });
            var format = cellFormat.filter(function (obj) {
                if (param.column.colId == obj.col && param.data[uniqueFieldName] == obj.row && param.value == obj.value) {
                    return obj;
                }
            })[0]; //Get align for given Data

            if (typeof format !== "undefined") {
                $.each(format.style, function (key, value) {
                    cellStyle[key] = value;
                });
                if (colorByRuleStyle !== "") {
                    cellStyle['background-color'] = colorByRuleStyle;
                }
                return cellStyle;
            }
            if (colorByRuleStyle !== "") {
                cellStyle['background-color'] = colorByRuleStyle;
            }

            return cellStyle;
        },
        getCellRuleColor: function (pluginId, selectedRule, cellValue) {
            var ColorByRule = $("#" + pluginId).spreadsheetWidget('getColorByRule', selectedRule);
            var ruleColor = "";
            if (ColorByRule.length > 0) {
                $.each(ColorByRule, function (i, obj) {
                    var operator = obj.operator,
                        value = obj.value,
                        condition = "";
                    if (value !== "") {
                        if (operator == '==' || operator == '!=') {
                            condition += "('" + cellValue + "' " + operator + " '";
                            condition += value.join("' || '" + cellValue + "' " + operator + " '");
                            condition += "')";
                        } else if (operator == '>' || operator == '>=' || operator == '<' || operator == '<=') {
                            condition = "" + cellValue + " " + operator + " " + value[0];
                        } else if (operator == 'Contains') {
                            //contains
                            condition += "('" + cellValue + "'.match(/" + $.trim(value[0]) + "/g))";
                        } else if (operator == 'Does not Contain') {
                            //not_contains
                            condition += "(!'" + cellValue + "'.match(/" + $.trim(value[0]) + "/g))";
                        } else if (operator == 'Start With') {
                            //starts_with
                            condition += "('" + cellValue + "'.match(/^" + $.trim(value[0]) + "/g))";
                        } else if (operator == 'Does not Start With') {
                            //not_starts_with
                            condition += "(!'" + cellValue + "'.match(/^" + $.trim(value[0]) + "/g))";
                        } else if (operator == 'End With') {
                            //ends_with
                            condition += "('" + cellValue + "'.match(/" + $.trim(value[0]) + "$/g))";
                        } else if (operator == 'Does not End With') {
                            //not_ends_with
                            condition += "(!'" + cellValue + "'.match(/" + $.trim(value[0]) + "$/g))";
                        } else if (operator == 'Between(Inclusive)') {
                            condition += "('" + cellValue + "' >= " + $.trim(value[0]);
                            condition += " && '" + cellValue + "'  <=" + $.trim(value[1]) + ")";
                        } else if (operator == 'Not Between') {
                            condition += "('" + cellValue + "' < " + $.trim(value[0]);
                            condition += " || '" + cellValue + "' > " + $.trim(value[1]) + ")";
                        } else if (operator == 'Exists' || operator == 'Does Not Exist') {

                        }

                        if (eval(condition)) {
                            ruleColor = obj.color;
                        }
                    }
                });
            }
            return ruleColor;
        }
    },
        createTemplates = {
            headerTemplate: function (name, gridOptions) {
                var headerHtml = "";
                headerHtml += '<div id="header" style="text-align: left;">'; //Column Header
                /*Column Resize*/
                headerHtml += '<div id="agResizeBar" style="width: 3px; height: 100%; float: right; cursor: col-resize;"></div>';

                /*Header Column*/
                headerHtml += '<div style="padding: 0px; overflow: hidden; text-overflow: ellipsis;">';

                /*Header Column Text*/
                headerHtml += '<span id="agHeaderCellLabel" class="agHeaderCellLabel">'; // agHeaderCellLabel

                headerHtml += '<span id="agText" title="' + name + '" class="ag-header-cell-text"></span>'; // header Label Text


                headerHtml += '<span id="agFilter" class="spreadsheetHeaderFilter ag-hidden"><svg class="s_MenuDropDown" viewBox="0 0 24 24"><path fill="#333" d="M3,2H21V2H21V4H20.92L14,10.92V22.91L10,18.91V10.91L3.09,4H3V2Z"></path></svg></span>'; // Filter

                headerHtml += '</span>';
                /*Header Column Text*/

                if (gridOptions.enableColSorting) {
                    /*Sorting*/
                    headerHtml += '<span id="agSortAsc1" class="spreadsheetHeaderAsc ag-hidden"><svg class="s_MenuDropDown" viewBox="0 0 24 24"><path fill="#404040" d="M10,11V13H18V11H10M10,5V7H14V5H10M10,17V19H22V17H10M6,7H8.5L5,3.5L1.5,7H4V20H6V7Z"></path></svg></span>'; // sort Ascending

                    headerHtml += '<span id="agSortDesc1" class="spreadsheetHeaderDesc ag-hidden"><svg class="s_MenuDropDown" viewBox="0 0 24 24"> <path fill="#404040" d="M10,13V11H18V13H10M10,19V17H14V19H10M10,7V5H22V7H10M6,17H8.5L5,20.5L1.5,17H4V4H6V17Z"></path></svg></span>'; // sort Descending

                    headerHtml += '<span id="agNoSort"></span>'; // UnSort
                }
                /*Sorting*/

                /*Header Column Menu*/
                if (gridOptions.enableFilter || gridOptions.enableColFreezing || gridOptions.enableColSorting || gridOptions.enableColHide) {
                    headerHtml += '<span id="spreadsheetMenu" title="' + name + '" class="spreadsheetHeaderMenu">'; //Menu

                    headerHtml += '<ul class="nav nav-pills">';

                    headerHtml += '<li class="dropdown">';
                    headerHtml += '<a id="menu" href="#" data-toggle="dropdown" class="dropdown-toggle"><svg class="h_Menuicon" viewBox="0 0 24 24"><path fill="#000000" d="M3,6H21V8H3V6M3,11H21V13H3V11M3,16H21V18H3V16Z" /></svg></a>'; //Menu Icon

                    headerHtml += '<ul class="dropdown-menu mainMenu" id="menu1">';

                    /*Filter Column*/
                    if (gridOptions.enableFilter) {
                        headerHtml += '<li>';
                        headerHtml += '<a id="filter" href="#"><svg class="s_MenuDropDown" viewBox="0 0 24 24"><path fill="#333" d="M3,2H21V2H21V4H20.92L14,10.92V22.91L10,18.91V10.91L3.09,4H3V2Z"></path></svg>&nbsp;&nbsp;Filter</a></span></li>';
                    }

                    if (gridOptions.enableColFreezing) {
                        /*Freeze Column*/
                        headerHtml += '<li class="dropdown mainMeu">';
                        headerHtml += '<a class="dropdown-toggle" data-toggle="dropdown" href="#"><svg class="s_MenuDropDown" viewBox="0 0 24 24">  <path fill="#404040" d="M16,12V4H17V2H7V4H8V12L6,14V16H11.2V22H12.8V16H18V14L16,12Z" /></svg>&nbsp;&nbsp;Freeze<svg class="h_menuDropDownArrow" viewBox="0 0 24 24"><path fill="#404040" d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"></path></svg></a>';

                        /*Column Freeze Sub Menu*/
                        headerHtml += '<ul class="dropdown-menu subMenu" id="subMenu">';
                        headerHtml += '<li class="pin"><a id="freeze" href="#">Pin</a></li>'; //Pin
                        headerHtml += '<li class="unpin"><a id="unfreeze" href="#">Un-Pin</a></li>'; //UnPin
                        headerHtml += '<li class="unpinall"><a id="unFreezeAllColumn" href="#">Un-PinAll</a></li>'; //UnpinAll
                        headerHtml += '</ul>';
                        /*Column Freeze Sub Menu*/

                        headerHtml += '</li>';
                    }
                    /*Freeze Column*/
                    /*Sorting*/
                    if (gridOptions.enableColSorting) {
                        headerHtml += '<li class="divider"></li>'; //Divider
                        headerHtml += '<li id="h_menuSorting" class="dropdown mainMeu">';
                        headerHtml += '<a class="dropdown-toggle" data-toggle="dropdown" href="#"><svg class="s_MenuDropDown" viewBox="0 0 24 24"><path fill="#404040" d="M9,3L5,7H8V14H10V7H13M16,17V10H14V17H11L15,21L19,17H16Z" /></svg>&nbsp;&nbsp;Sorting<svg class="h_menuDropDownArrow" viewBox="0 0 24 24"><path fill="#404040" d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"></path></svg></a>';

                        /*Column sort Sub Menu*/
                        headerHtml += '<ul class="dropdown-menu subMenu" id="subMenu">';
                        headerHtml += '<li><a id="asc" href="#"><svg class="s_MenuDropDown" viewBox="0 0 24 24"><path fill="#404040" d="M10,11V13H18V11H10M10,5V7H14V5H10M10,17V19H22V17H10M6,7H8.5L5,3.5L1.5,7H4V20H6V7Z" /></svg>&nbsp;&nbsp;Ascending</a></li>'; //Pin
                        headerHtml += '<li><a id="desc" href="#"><svg class="s_MenuDropDown" viewBox="0 0 24 24"> <path fill="#404040" d="M10,13V11H18V13H10M10,19V17H14V19H10M10,7V5H22V7H10M6,17H8.5L5,20.5L1.5,17H4V4H6V17Z" /></svg>&nbsp;&nbsp;Descending</a></li>'; //UnPin
                        headerHtml += '<li class="unsortall"><a id="unsort" href="#"><svg class="s_MenuDropDown" viewBox="0 0 24 24"><path fill="#404040" d="M9,3L5,7H8V14H10V7H13M16,17V10H14V17H11L15,21L19,17H16Z" /></svg>&nbsp;&nbsp;Un-Sort All</a></li>'; //UnpinAll
                        headerHtml += '</ul>';
                        /*Column sort Sub Menu*/

                        headerHtml += '</li>';
                    }
                    /*Sorting*/

                    /*Hide/UnHide*/
                    if (gridOptions.enableColHide) {
                        headerHtml += '<li class="divider"></li>'; //Divider
                        headerHtml += '<li class="dropdown mainMeu">';
                        headerHtml += '<a class="dropdown-toggle" data-toggle="dropdown" href="#"><svg class="s_MenuDropDown" viewBox="0 0 24 24"><path fill="#404040" d="M11.83,9L15,12.16C15,12.11 15,12.05 15,12A3,3 0 0,0 12,9C11.94,9 11.89,9 11.83,9M7.53,9.8L9.08,11.35C9.03,11.56 9,11.77 9,12A3,3 0 0,0 12,15C12.22,15 12.44,14.97 12.65,14.92L14.2,16.47C13.53,16.8 12.79,17 12,17A5,5 0 0,1 7,12C7,11.21 7.2,10.47 7.53,9.8M2,4.27L4.28,6.55L4.73,7C3.08,8.3 1.78,10 1,12C2.73,16.39 7,19.5 12,19.5C13.55,19.5 15.03,19.2 16.38,18.66L16.81,19.08L19.73,22L21,20.73L3.27,3M12,7A5,5 0 0,1 17,12C17,12.64 16.87,13.26 16.64,13.82L19.57,16.75C21.07,15.5 22.27,13.86 23,12C21.27,7.61 17,4.5 12,4.5C10.6,4.5 9.26,4.75 8,5.2L10.17,7.35C10.74,7.13 11.35,7 12,7Z" /></svg>&nbsp;&nbsp;Hide/UnHide<svg class="h_menuDropDownArrow" viewBox="0 0 24 24"><path fill="#404040" d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"></path></svg></a>';

                        /*Column sort Sub Menu*/
                        headerHtml += '<ul class="dropdown-menu subMenu" id="subMenu">';
                        headerHtml += '<li><a id="hide" href="#"><svg class="s_MenuDropDown" viewBox="0 0 24 24"><path fill="#404040" d="M11.83,9L15,12.16C15,12.11 15,12.05 15,12A3,3 0 0,0 12,9C11.94,9 11.89,9 11.83,9M7.53,9.8L9.08,11.35C9.03,11.56 9,11.77 9,12A3,3 0 0,0 12,15C12.22,15 12.44,14.97 12.65,14.92L14.2,16.47C13.53,16.8 12.79,17 12,17A5,5 0 0,1 7,12C7,11.21 7.2,10.47 7.53,9.8M2,4.27L4.28,6.55L4.73,7C3.08,8.3 1.78,10 1,12C2.73,16.39 7,19.5 12,19.5C13.55,19.5 15.03,19.2 16.38,18.66L16.81,19.08L19.73,22L21,20.73L3.27,3M12,7A5,5 0 0,1 17,12C17,12.64 16.87,13.26 16.64,13.82L19.57,16.75C21.07,15.5 22.27,13.86 23,12C21.27,7.61 17,4.5 12,4.5C10.6,4.5 9.26,4.75 8,5.2L10.17,7.35C10.74,7.13 11.35,7 12,7Z" /></svg>&nbsp;&nbsp;Hide</a></li>'; //hide
                        /*headerHtml += '<li><a id="unhide" href="#"><i class="glyphicon glyphicon-eye-open"></i>&nbsp;&nbsp;Un-Hide</a></li>';//Un hide*/
                        headerHtml += '<li class="unHideAll"><a id="unhideAll" href="#"><svg class="s_MenuDropDown" viewBox="0 0 24 24"><path fill="#404040" d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z" /></svg>&nbsp;&nbsp;Un-Hide All</a></li>'; //unHide All						
                        headerHtml += '</ul>';
                        /*Column sort Sub Menu*/

                        headerHtml += '</li>';
                    }
                    /*Hide/UnHide*/

                    headerHtml += '</ul>';

                    headerHtml += '</li>';

                    headerHtml += '</ul>';

                    headerHtml += '</span>'; // Menu
                }
                /*Header Column Menu*/

                headerHtml += '</div>';
                /*Header Column*/

                headerHtml += '</div>'; //Column Header

                return headerHtml;
            },
            actionBar: function (data) {
                var ActionBarIconsHtml = "";
                ActionBarIconsHtml += "<div class='pull-right spreadsheetIcons'>"; //Spreadsheet Icons

                if (data.enableJumpToRow || data.enableJumpToColumn) {
                    ActionBarIconsHtml += "<div class='jumpTextArea'>";

                    /*jumpToRow*/
                    if (data.enableJumpToRow) {
                        ActionBarIconsHtml += "<input id='jumpToRow' type='number' min='0' class='jumpText jumpRow' placeholder='Row' type='text' data-tooltip='tooltip' title='Jump to Row'/>";
                    }
                    /*jumpToColumn*/
                    if (data.enableJumpToColumn) {
                        ActionBarIconsHtml += "<input id='jumpToColumn' type='number' min='0' class='jumpText jumpColumn' placeholder='Col' type='text' data-tooltip='tooltip' title='Jump to Column' />";
                    }
                    ActionBarIconsHtml += "</div>";
                }

                ActionBarIconsHtml += "<div class='spreadsheetControls'>"; //Spreadsheet Default Icons

                if (data.enableRowResize) {
                    /*Spreadsheet Refresh Icon*/
                    ActionBarIconsHtml += "<span id='toggleHeight' class='w_toggleHeight' data-tooltip='tooltip' title='Toggle Row Height'>";
                    ActionBarIconsHtml += "<svg style='width:18px;height:18px' viewBox='0 0 24 24'>";
                    ActionBarIconsHtml += " <path fill='#404040' d='M3,5H15A2,2 0 0,1 17,7V17A2,2 0 0,1 15,19H3A2,2 0 0,1 1,17V7A2,2 0 0,1 3,5M3,9V12H8V9H3M10,9V12H15V9H10M3,14V17H8V14H3M10,14V17H15V14H10M23,14V7H19V9H21V12H19V14H23Z'/>";
                    ActionBarIconsHtml += "</svg></span>";
                }
                if (data.enableExportToCSV) {
                    /*Spreadsheet Export to CSV Icon*/
                    ActionBarIconsHtml += "<span id='export' class='w_export' data-tooltip='tooltip' title='Export CSV File'>";
                    ActionBarIconsHtml += "<svg style='width:25px;height:25px' viewBox='0 0 24 24'>";
                    ActionBarIconsHtml += "<path fill='#404040' d='M6,2C4.89,2 4,2.9 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M13,3.5L18.5,9H13M8.93,12.22H16V19.29L13.88,17.17L11.05,20L8.22,17.17L11.05,14.35' />";
                    ActionBarIconsHtml += "</svg> </span>";
                }

                if (data.enableColSorting) {
                    ActionBarIconsHtml += "<span id='sortAsc' class='w_sortAsc' data-tooltip='tooltip' title='Sort Ascending'>";
                    ActionBarIconsHtml += "<svg style='width:18px;height:18px' viewBox='0 0 24 24'>";
                    ActionBarIconsHtml += "<path fill='#404040' d='M10,11V13H18V11H10M10,5V7H14V5H10M10,17V19H22V17H10M6,7H8.5L5,3.5L1.5,7H4V20H6V7Z'/>";
                    ActionBarIconsHtml += "</svg> </span>"; //Spreadsheet sort Asc Icons
                    ActionBarIconsHtml += "<span id='sortDesc' class='w_sortDsc' data-tooltip='tooltip' title='Sort Descending'>";
                    ActionBarIconsHtml += "<svg style='width:18px;height:18px' viewBox='0 0 24 24'>";
                    ActionBarIconsHtml += "<path fill='#404040' d='M10,13V11H18V13H10M10,19V17H14V19H10M10,7V5H22V7H10M6,17H8.5L5,20.5L1.5,17H4V4H6V17Z'/>";
                    ActionBarIconsHtml += "</svg> </span>";
                }
                if (data.enableFormatting) {
                    /*font dropdown*/
                    ActionBarIconsHtml += "<span class='fontlist input-field' data-tooltip='tooltip' title='Font Style'>";
                    ActionBarIconsHtml += "<select id='fontType'>";
                    ActionBarIconsHtml += "</select>";
                    ActionBarIconsHtml += "</span> ";

                    /*Font Size*/
                    ActionBarIconsHtml += " <span class='fontSize input-field' data-tooltip='tooltip' title='Font Size'> ";
                    ActionBarIconsHtml += " <select id='fontSize'>";
                    ActionBarIconsHtml += " </select>";
                    ActionBarIconsHtml += " </span> ";

                    /*Bold Icon*/
                    ActionBarIconsHtml += "<span id='bold' class='w_Bold' data-tooltip='tooltip' title='Bold'>";
                    ActionBarIconsHtml += "<svg style='width:18px;height:18px' viewBox='0 0 24 24'>";
                    ActionBarIconsHtml += "<path fill='#404040' d='M13.5,15.5H10V12.5H13.5A1.5,1.5 0 0,1 15,14A1.5,1.5 0 0,1 13.5,15.5M10,6.5H13A1.5,1.5 0 0,1 14.5,8A1.5,1.5 0 0,1 13,9.5H10M15.6,10.79C16.57,10.11 17.25,9 17.25,8C17.25,5.74 15.5,4 13.25,4H7V18H14.04C16.14,18 17.75,16.3 17.75,14.21C17.75,12.69 16.89,11.39 15.6,10.79Z'/>";
                    ActionBarIconsHtml += "</svg></span> ";

                    /*Italic Icon*/
                    ActionBarIconsHtml += "<span id='italic' class='w_Italic' data-tooltip='tooltip' title='Italic'>";
                    ActionBarIconsHtml += "<svg style='width:18px;height:18px' viewBox='0 0 24 24'>";
                    ActionBarIconsHtml += "<path fill='#404040' d='M10,4V7H12.21L8.79,15H6V18H14V15H11.79L15.21,7H18V4H10Z'/>";
                    ActionBarIconsHtml += "</svg></span> ";

                    /*Underline Icon*/
                    ActionBarIconsHtml += "<span id='underline' class='w_Underline' data-tooltip='tooltip' title='Underline'>";
                    ActionBarIconsHtml += "<svg style='width:17px;height:18px' viewBox='0 0 24 24'>";
                    ActionBarIconsHtml += "<path fill='#404040' d='M5,21H19V19H5V21M12,17A6,6 0 0,0 18,11V3H15.5V11A3.5,3.5 0 0,1 12,14.5A3.5,3.5 0 0,1 8.5,11V3H6V11A6,6 0 0,0 12,17Z'/>";
                    ActionBarIconsHtml += "</svg></span> ";

                    /*Font Color*/
                    ActionBarIconsHtml += " <span class='w_fontColor' data-tooltip='tooltip' title='Font Color'>"; //Spreadsheet font color Icons
                    ActionBarIconsHtml += " <input id='fontColorpicker" + data.pluginId + "' />";
                    ActionBarIconsHtml += " </span> ";

                    /*Fill Color*/
                    ActionBarIconsHtml += " <span class='w_fillColor' data-tooltip='tooltip' title='Fill Color'>"; //Spreadsheet background color Icons
                    ActionBarIconsHtml += " <input id='fillColorpicker" + data.pluginId + "' />";
                    ActionBarIconsHtml += " </span> ";

                }

                /*Color By Value*/
                if (data.enableColorByValue) {
                    ActionBarIconsHtml += " <span id='colorByValueModelPopup' class='w_colorByVal' data-toggle = 'modal' data-target ='#colorByValPopUp' data-tooltip='tooltip' title='Color by value'>";
                    ActionBarIconsHtml += "<svg style='width:18px;height:18px' viewBox='0 0 24 24'>";
                    ActionBarIconsHtml += "<path fill='#404040' d='M3,17H21V15H3V17M3,20H21V19H3V20M3,13H21V10H3V13M3,4V8H21V4H3Z'/>";
                    ActionBarIconsHtml += "</svg></span> ";
                }

                if (data.gridOptions.enableColHide) {
                    /*Un-Hide All Columns Icon*/
                    ActionBarIconsHtml += " <span id='unhideAll' class='w_unHideAll' data-tooltip='tooltip' title='Un-Hide All'>";
                    ActionBarIconsHtml += "<svg style='width:16px;height:18px' viewBox='0 0 24 24'>";
                    ActionBarIconsHtml += "<path fill='#404040' d='M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z' />";
                    ActionBarIconsHtml += "</svg></span> ";
                }
                /*R Group Icons*/
                /*ActionBarIconsHtml += "<span class='w_R_group' data-toggle='tooltip'  data-tooltip='R Group Analysis'>";
                ActionBarIconsHtml += "<svg style='width:16px;height:18px' viewBox='0 0 24 24'>";
                ActionBarIconsHtml += "<path fill='#404040' d='M21.59,11.59L23,13L13.5,22.5L8.42,17.41L9.83,16L13.5,19.68L21.59,11.59M4,16V3H6L9,3A4,4 0 0,1 13,7C13,8.54 12.13,9.88 10.85,10.55L14,16H12L9.11,11H6V16H4M6,9H9A2,2 0 0,0 11,7A2,2 0 0,0 9,5H6V9Z' />";
                ActionBarIconsHtml += "</svg></span> ";*/

                /*dataStatistics Icons*/
                /*ActionBarIconsHtml += " <span class='w_dataStatistics' data-toggle='tooltip' data-tooltip='Data Statistics'>";
                ActionBarIconsHtml += "<svg style='width:17px;height:18px' viewBox='0 0 24 24'>";
                ActionBarIconsHtml += "<path fill='#404040' d='M5,4H18V9H17L16,6H10.06L13.65,11.13L9.54,17H16L17,15H18V20H5L10.6,12L5,4Z' />";
                ActionBarIconsHtml += "</svg></span> ";*/

                ActionBarIconsHtml += "</div>"; //Spreadsheet Default Icons

                ActionBarIconsHtml += "<span class='w_arrowDown'><svg version='1.1' width='18' height='18' viewBox='0 0 24 24'><path fill='#404040' d='M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z'/></svg>";
                ActionBarIconsHtml += "</span>";


                if (data.enableCloseButton) {
                    ActionBarIconsHtml += "<span id='closeWidget' onclick='closePresentationviewer(this)' class='w_close' data-tooltip='tooltip' title='Close'><svg version='1.1' width='18' height='18' viewBox='0 0 24 24'><path fill='#404040' d='M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z' /></svg>";
                    ActionBarIconsHtml += "</span>";
                }

                ActionBarIconsHtml += "</div>"; //Spreadsheet Icons
                return ActionBarIconsHtml;
            },
            colorByValue: function (pluginId) {
                var colorByValueHtml = "";
                //Color By Value Model Popup
                colorByValueHtml += "<div id ='colorByValPopUp' class = 'spreedsheetColorByvalPopup modal fade' role = 'dialog'>";

                //Model Popup Header
                colorByValueHtml += "<div class ='modal-header'> <button type='button' class='close' data-dismiss='modal'>&times;</button> <h4 class = 'modal-title'> Color By Value </h4> </div>";

                //Model Popup Body
                colorByValueHtml += "<div class = 'modal-body'>";

                //Model Popup Body Container
                colorByValueHtml += "<div class = 'col-sm-12  spreatsheetColorByValContent noPad'>";


                colorByValueHtml += "<div class='col-sm-12 noPad colorByDataValueFields'>";

                /*Data Field Drop Down*/
                colorByValueHtml += "<div class='col-sm-4'>";
                colorByValueHtml += "<label class='labelHeight'>Data Field(s) to color:</label>";
                colorByValueHtml += "<select id = 'ddl_colorByDataValueFields' class='col-sm-12'>";
                colorByValueHtml += "</select>";
                colorByValueHtml += "</div>";


                /*Value In Data Filed*/
                /* colorByValueHtml += "<div class='col-sm-4'>";
                colorByValueHtml += "<input class='with-gap' type='checkbox' id='usingDataField'/>";
                colorByValueHtml += "<label for='usingDataField'>Using values in data filed:</label>";
                colorByValueHtml += "<select id = 'ddl_valueInDataField' class='col-sm-12 btn-is-disabled'>";
                colorByValueHtml += "</select>";
                colorByValueHtml += "</div>";*/

                /*Saved Schemes*/
                /*colorByValueHtml += "<div class='col-sm-4'>";
                colorByValueHtml += "<label class='labelHeight'>Saved Schemes:</label>";
                colorByValueHtml += "<select id ='ddl_savedSchemes' class='col-sm-12 btn-is-disabled'>";
                colorByValueHtml += "</select>";
                colorByValueHtml += "</div>";*/

                colorByValueHtml += "</div>";

                /*Color Scheme Type*/
                colorByValueHtml += "<div class='col-sm-12'>";
                colorByValueHtml += "<label class='col-sm-3 marginTop10x noPad'>Color Scheme Type:</label>";
                colorByValueHtml += "<select id ='ddl_colorSchemeType' class='col-sm-8'>";
                colorByValueHtml += "<option value ='byRules'>By Rules</option>";
                //colorByValueHtml += "<option value ='MintoMax'>Continuous Min to Max</option>";
                colorByValueHtml += "</select>";
                colorByValueHtml += "</div>";

                /*Gradient Part*/
                colorByValueHtml += "<div class='col-sm-12 marginTop10x gradientPatten' style='display:none;'>";
                colorByValueHtml += "<div class='col-sm-12 noPad'>";
                colorByValueHtml += "<div class='col-sm-1 noPad'><input class='col-sm-2 ' id='gradientPickerMinVal'/></div>";
                colorByValueHtml += "<div class='col-sm-10 noPad gradientArea'></div>";
                colorByValueHtml += "<div class='col-sm-1 noPad textRight'><input class='col-sm-2 ' id='gradientPickerMaxVal'/></div>";
                colorByValueHtml += "</div>";
                colorByValueHtml += "<div class='col-sm-12 marginTop10x noPad'>";
                colorByValueHtml += "<div class='col-sm-4 noPad'><label class='minLabel'>Min:</label>";
                colorByValueHtml += "<input type='text' value='' class='minValInput'/>";
                colorByValueHtml += "</div>";
                colorByValueHtml += "<div class='col-sm-4 noPad'><input class='col-sm-2 ' id='gradientPickerMidVal'/>";
                colorByValueHtml += "<select id = 'gradientMidVal' class='col-sm-2 midSelect'>";
                colorByValueHtml += "<option value ='midpoint'> Middle </option>";
                colorByValueHtml += "<option value ='not_null'> Mean </option>";
                colorByValueHtml += "<option value ='not_null'> Median </option>";
                colorByValueHtml += "<option value ='not_null'> Fixed </option>";
                colorByValueHtml += "<option value ='not_null'> none </option>";
                colorByValueHtml += "</select>";
                colorByValueHtml += "<input type='text' value='' class='midValInput'/>";
                colorByValueHtml += "</div>";
                colorByValueHtml += "<div class='col-sm-4 noPad textRight'><label class='maxLabel'>Max:</label>";
                colorByValueHtml += "<input type='text' value='' class='maxValInput'/>";
                colorByValueHtml += "</div>";
                colorByValueHtml += "<div class='col-sm-12 marginTop10x noPad'><input type='checkbox' id='useMinMaxRangaval'/>";
                colorByValueHtml += "<label for='useMinMaxRangaval'>Use Min/Max Colors for out of Range Values</label></div>";
                colorByValueHtml += "<div class='col-sm-12 marginTop10x noPad'><label>Data Scaling </label><input type='radio' name='datascalling' id='linear'/>";
                colorByValueHtml += "<label for='linear'>Linear</label><input type='radio' name='datascalling' id='logarithmic'/>";
                colorByValueHtml += "<label for='logarithmic'>Logarithmic</label></div>";
                colorByValueHtml += "</div>";
                colorByValueHtml += "</div>";
                /*Gradient Part End*/

                /* Add Rule,Remove Rule,Data Uints */
                colorByValueHtml += "<div class='col-sm-12 marginTop10x byRulesPattern' style='display:none;'>";
                colorByValueHtml += "<div class='col-sm-6 noPad'>";
                colorByValueHtml += "<button type='button' class='btn waves-effect waves-green' id='btn_addRule' >Add Rule</button>";
                colorByValueHtml += "<button type = 'button' class = 'btn waves-effect waves-green btn-is-disabled' id='btn_removeRules'> Remove Rule </button>";
                colorByValueHtml += "</div>";
                /* colorByValueHtml += "<div class='col-sm-6 noPad text-right'>";
                 colorByValueHtml += "<label class='col-sm-9 marginTop10x'>Data Uints:</label>";
                 colorByValueHtml += "<select id ='ddl_dataUnit' class='col-sm-3 btn-is-disabled'>";
                 colorByValueHtml += "</select>";
                 colorByValueHtml += "</div>";*/

                colorByValueHtml += "<div class='col-sm-12 colorSchemeRules'>";
                colorByValueHtml += "<input class='col-sm-2 ' id='byRulesColorpicker" + pluginId + "'/>";
                colorByValueHtml += "<select id='ddl_operators' class='col-sm-3'>";
                colorByValueHtml += "</select>";
                colorByValueHtml += "<input id='textOperand' type='text' class='form-control textbox stringText'>";
                colorByValueHtml += "<input id='textboxbetween1' name='valueString1' type='text' class='col-sm-6 form-control textbox stringTextBetween'>";
                colorByValueHtml += "<input id='textboxbetween2' name='valueString2' type='text' class='col-sm-6 form-control textbox stringTextBetween'>";
                colorByValueHtml += "<textarea id='textareabox' type='text' class='form-control textareabox stringTextArea materialize-textarea'></textarea>";
                colorByValueHtml += "<button id='btn_newRule' type='button' class='btn waves-effect waves-green'> OK </button>";
                colorByValueHtml += "<button id='btn_cancelRule' type='button' class='btn waves-effect waves-green'> Cancel </button>";
                colorByValueHtml += "</div>";

                /* AG Grid */
                colorByValueHtml += "<div class='col-sm-12 noPad'>";
                colorByValueHtml += "<div id='grid_colorByValue' style='width:96%; height: 190px;' class='ag-fresh colorByValue'></div>";
                colorByValueHtml += "</div>";

                colorByValueHtml += "</div>";


                colorByValueHtml += "</div>";
                //Model Popup Body Container


                colorByValueHtml += "</div>";
                //Model Popup Body


                //Model Popup Footer
                colorByValueHtml += "<div class ='modal-footer'>";
                /* Save Scheme */
                colorByValueHtml += "<div class='col-sm-6 noPad left'>";
                //colorByValueHtml += "<button id='btn_saveScheme' type='button' class='btn waves-effect waves-green'> Save Schema </button>";
                //colorByValueHtml += "<button id='btn_saveSchemeAs' type='button' class='btn waves-effect waves-green'> Save Schema as </button>";
                colorByValueHtml += "</div>";
                colorByValueHtml += "<div class='col-sm-6 noPad'>";
                colorByValueHtml += "<button id='btn_colorByValueCancel' type='button' class='btn waves-effect waves-green' data-dismiss='modal'> Cancel </button>";
                colorByValueHtml += "<button id='btn_colorByValueApply' type='button' class='btn waves-effect waves-green applyRuleOnspreadSheetViewer' > Apply </button>";
                colorByValueHtml += "<button id='btn_colorByValueApplyClose' type ='button' class ='btn waves-effect waves-green applyRuleOnspreadSheetViewer' data-dismiss='modal'> Apply & Close </button>";
                colorByValueHtml += "</div>";
                colorByValueHtml += "</div>";


                colorByValueHtml += "</div>";
                //Color By Value Model Popup

                return colorByValueHtml;
            },
            columnContextMenu: function (colParam) {
                var gridOptions = colParam.api.gridOptionsWrapper.gridOptions;
                var headerHtml = createTemplates.headerTemplate(colParam.column.colDef.headerName, gridOptions);
                var eCell = document.createElement('span');
                eCell.innerHTML = headerHtml;

                var filter = eCell.querySelector('#filter'),
                    ascending = eCell.querySelector('#asc'),
                    descending = eCell.querySelector('#desc'),
                    unsort = eCell.querySelector('#unsort'),
                    freeze = eCell.querySelector('#freeze'),
                    unfreeze = eCell.querySelector('#unfreeze'),
                    unFreezeAllColumn = eCell.querySelector('#unFreezeAllColumn'),
                    header = eCell.querySelector('#agHeaderCellLabel'),
                    hide = eCell.querySelector('#hide'),
                    unhideAll = eCell.querySelector('#unhideAll'),
                    headerDrowpdown = eCell.querySelector('.dropdown-toggle');

                if (gridOptions.enableFilter) {
                    // custom button click filter
                    filter.addEventListener('click', function (event) {
                        var colID = $(this).closest('.ag-header-cell').attr('colid'),
                            plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('addFilter', {
                            colId: colID
                        });
                    });
                }

                if (gridOptions.enableColSorting) {
                    // custom button click ascending order
                    ascending.addEventListener('click', function (event) {
                        var colID = $(this).closest('.ag-header-cell').attr('colid'),
                            plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('sortColumn', [
                            {
                                colId: colID,
                                sort: 'asc'
                            }
                        ]);
                    });

                    // custom button click descending order
                    descending.addEventListener('click', function (event) {
                        var colID = $(this).closest('.ag-header-cell').attr('colid'),
                            plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('sortColumn', [
                            {
                                colId: colID,
                                sort: 'desc'
                            }
                        ]);
                    });

                    // custom button click descending order
                    unsort.addEventListener('click', function (event) {
                        var plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('unsortAllColumn');
                    });
                }

                if (gridOptions.enableColFreezing) {
                    // custom button click freeze Columns
                    freeze.addEventListener('click', function (event) {
                        var colID = $(this).closest('.ag-header-cell').attr('colid'),
                            plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('freezeColumn', [
                            {
                                colId: colID,
                                pinned: 'left'
                            }
                        ]);
                    });

                    // custom button click unfreeze Columns
                    unfreeze.addEventListener('click', function (event) {
                        var colID = $(this).closest('.ag-header-cell').attr('colid'),
                            plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('unFreezeColumn', [
                            {
                                colId: colID,
                                pinned: null
                            }
                        ]);
                    });

                    // custom button click unfreeze Columns
                    unFreezeAllColumn.addEventListener('click', function (event) {
                        var plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('unFreezeAllColumn');
                    });
                }

                // custom button click column Selection
                header.addEventListener('click', function (event) {
                    var colID = $(this).closest('.ag-header-cell').attr('colid'),
                        plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                    $('#' + plugin).spreadsheetWidget('getSelectedColumn', {
                        colID: colID,
                        event: event
                    });
                });

                if (gridOptions.enableColHide) {
                    // hide columns
                    hide.addEventListener('click', function (event) {
                        var colID = $(this).closest('.ag-header-cell').attr('colid'),
                            plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('hideColumn', [colID]);
                    });

                    // un-hide all the hidden columns
                    unhideAll.addEventListener('click', function (event) {
                        var plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('unhideAll');
                    });
                }
                if (headerDrowpdown != undefined) {
                    // Header dropdown Menu Position
                    headerDrowpdown.addEventListener('click', function (event) {
                        var menuToggle = $(this);
                        var dropdownOffset = menuToggle.offset(),
                            offsetLeft = dropdownOffset.left,
                            docWidth = $('.widgetContent').width(),
                            isDropdownVisible = ((offsetLeft-200) <= docWidth),
                            isSubDropdownVisible = (offsetLeft <= docWidth),
                            isSubDropdownVisibleMin = (offsetLeft < 160),
                            isSubDropdownVisibleMax = (offsetLeft <= (docWidth - 150));
                        if (isDropdownVisible) {
                            if (offsetLeft > 150) {
                                $('.dropdown-menu.mainMenu').addClass('pull-marginLeft');
                            } else {
                                $('.dropdown-menu.mainMenu').removeClass('pull-marginLeft');
                            }
                        }
                        if (isSubDropdownVisible) {
                            if (isSubDropdownVisibleMin) {
                                $('.dropdown-menu.subMenu').removeClass('pull-marginLeftTop');
                            } else if (isSubDropdownVisibleMax) {
                                $('.dropdown-menu.subMenu').removeClass('pull-marginLeftTop');
                            } else {
                                $('.dropdown-menu.subMenu').addClass('pull-marginLeftTop');
                            }
                        } else {
                            $('.dropdown-menu.subMenu').removeClass('pull-marginLeftTop');
                        }
                    });
                }

                return eCell;
            },
            rowContextMenu: function (pluginId, rowmenu, options) {
                var enableRowFreezing = options.enableRowFreezing;
                var enableRowMoveable = options.enableRowMoveable;
                rowmenu = $.map(rowmenu, function (val, i) {
                    if (enableRowFreezing && val.groupName === "rowfreeze") {
                        return val;
                    }
                    if (enableRowMoveable && val.groupName === "rowReordering") {
                        return val;
                    }
                });

                var rowMenuList = '<ul class="dropdown-menu">';
                $.each(rowmenu, function (index, value) {
                    if (value.submenu.length === 0) {
                        rowMenuList += '<li id="' + value.id + '" data-callback=' + value.callback + '><a href="#" data-callback=' + value.callback + '>' + value.name + '</a></li>';
                        spreadsheetEvent.addDelegate(pluginId, "#" + value.id, "click", value.callback, value.param, {});
                    } else {
                        rowMenuList += '<li class="dropdown-submenu row_context_mainMeu" id="' + value.id + '" data-callback=' + value.callback + '><a href="#" data-callback=' + value.callback + '>' + value.name + '<span class=" dropdownArrowIcon"><svg class="s_menuDropDownArrow" viewBox="0 0 24 24"><path fill="#404040" d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"/></svg></span></a><ul class="dropdown-menu cellsubMenu">';
                        $.each(value.submenu, function (subIndex, subvalue) {
                            rowMenuList += '<li id="' + subvalue.id + '"><a href="#">' + subvalue.name + '</a></li>';
                            spreadsheetEvent.addDelegate(pluginId, "#" + subvalue.id, "click", subvalue.callback, subvalue.param, {});
                        });
                        rowMenuList += '</ul></li>';
                        rowMenuList += '<li class="divider"></li>'; //Divider
                    }
                });
                rowMenuList += '</ul>';
                $("#row-context-menu").append(rowMenuList);
            },
            enableSortingIcons: function (enable) {
                if (enable) {
                    $("#sortAsc").show();
                    $("#sortDesc").show();
                } else {
                    $("#sortAsc").hide();
                    $("#sortDesc").hide();
                }
            },
            enableFreezing: function () { }
        },
        spreadsheetEvent = {
            actionBarDelegate: function (pluginId) {
                /*Delegate event for jump to row*/
                spreadsheetEvent.addDelegate(pluginId, "#jumpToRow", "input", 'jumpToRow', [], {
                    actionBar: false,
                    textBox: true
                });

                /*Delegate event for jump to col*/
                spreadsheetEvent.addDelegate(pluginId, "#jumpToColumn", "input", 'jumpToCol', [], {
                    actionBar: true,
                    textBox: true
                });

                /*Delegate event for toggle row height*/
                spreadsheetEvent.addDelegate(pluginId, "#toggleHeight", "click", 'toggleRowHeight', [], {
                    actionBar: true,
                    iconType: ".w_toggleHeight",
                    toggle: false
                });

                spreadsheetEvent.addDelegate(pluginId, "#export", "click", 'exportDatatoCSV', [], {
                    actionBar: false
                });

                spreadsheetEvent.addDelegate(pluginId, "#sortAsc", "click", 'sortColumn', [
                    {
                        colId: "",
                        sort: 'asc'
                    }
                ], {
                    actionBar: true,
                    iconType: ".w_sortAsc",
                    toggle: false
                });


                spreadsheetEvent.addDelegate(pluginId, "#sortDesc", "click", 'sortColumn', [
                    {
                        colId: "",
                        sort: 'desc'
                    }
                ], {
                    actionBar: true,
                    iconType: ".w_sortDsc",
                    toggle: false
                });


                spreadsheetEvent.addDelegate(pluginId, "#bold", "click", 'bold', [], {
                    actionBar: true,
                    iconType: ".w_Bold",
                    toggle: true
                });

                spreadsheetEvent.addDelegate(pluginId, "#italic", "click", 'italic', [], {
                    actionBar: true,
                    iconType: ".w_Italic",
                    toggle: true
                });

                spreadsheetEvent.addDelegate(pluginId, "#underline", "click", 'underline', [], {
                    actionBar: true,
                    iconType: ".w_Underline",
                    toggle: true
                });

                spreadsheetEvent.addDelegate(pluginId, "#fontSize", "change", 'fontSize', [], {
                    actionBar: false,
                    dropdown: true
                });

                spreadsheetEvent.addDelegate(pluginId, "#fontType", "change", 'fontType', [], {
                    actionBar: false,
                    dropdown: true
                });

                spreadsheetEvent.addDelegate(pluginId, "#unhideAll", "click", 'unhideAll', [], {
                    actionBar: false
                });

                spreadsheetEvent.addDelegate(pluginId, "#colorByValueModelPopup", "click", 'loadColorByValuePopup', [], {
                    actionBar: false
                });

                /* spreadsheetEvent.addDelegate(pluginId, "#closeWidget", "click", 'closeWidget', [], {
                     actionBar: false
                 });*/
            },
            colorByValueDelegates: function (pluginId) {
                formatting.colorByValueColorPicker(pluginId, "gradientPickerMinVal", "#000000", "setgradientMinColor"); //Min Range Gradient Value
                formatting.colorByValueColorPicker(pluginId, "gradientPickerMaxVal", "#a61c00", "setgradientMaxColor"); //Max Range Gradient Value
                formatting.colorByValueColorPicker(pluginId, "gradientPickerMidVal", "#00ff00", "setgradientMidColor"); //Midle Range Gradient Value


                spreadsheetEvent.addDelegate(pluginId, "select#ddl_colorByDataValueFields", "change", "onDataFieldChange", [], {});
                spreadsheetEvent.addDelegate(pluginId, "select#ddl_valueInDataField", "change", "onValueDataFieldChange", [], {});
                //spreadsheetEvent.addDelegate(pluginId, "select#ddl_savedSchemes", "change", "onSavedSchemesChange", [], {});
                spreadsheetEvent.addDelegate(pluginId, "select#ddl_colorSchemeType", "change", "onColorSchemaTypeChange", [], {
                    dropdown: true
                });
                spreadsheetEvent.addDelegate(pluginId, "select#ddl_operators", "change", "onColorByValueOperatorsChange", [], {
                    dropdown: true
                });
                //spreadsheetEvent.addDelegate(pluginId, "select#ddl_dataUnit", "change", "onDataUnitChange", [], {});
                spreadsheetEvent.addDelegate(pluginId, "input#usingDataField", "change", "onUsingDataField", [], {});


                spreadsheetEvent.addDelegate(pluginId, "#btn_addRule", "click", "onAddNewColorByValueRule", [], {});
                spreadsheetEvent.addDelegate(pluginId, "#btn_removeRules", "click", "removeNewColorByValueRule", [], {});

                spreadsheetEvent.addDelegate(pluginId, "#btn_newRule", "click", "addNewColorByValueRule", [], {});
                spreadsheetEvent.addDelegate(pluginId, "#btn_cancelRule", "click", "cancelNewColorByValueRule", [], {});


                spreadsheetEvent.addDelegate(pluginId, "#btn_saveScheme", "click", "saveSchema", [], {});
                spreadsheetEvent.addDelegate(pluginId, "#btn_saveSchemeAs", "click", "saveSchemaAs", [], {});
                spreadsheetEvent.addDelegate(pluginId, "#btn_colorByValueCancel", "click", "cancelColorByValue", [], {});
                spreadsheetEvent.addDelegate(pluginId, "#btn_colorByValueApply", "click", "applyColorByValue", [], {});
                spreadsheetEvent.addDelegate(pluginId, "#btn_colorByValueApplyClose", "click", "applyAndCloseColorByValue", [], {});
            },
            addDelegate: function (pluginId, idToDelegate, event, callback, param, otherInfo) {
                //delegate function for Selected Row Move Up
                $("#" + pluginId).delegate(idToDelegate, event, function delegate(event) {
                    if (otherInfo.dropdown) {
                        param = $(this).find('option:selected').val();
                    }
                    if (otherInfo.textBox) {
                        param = $(this).val();
                    }
                    if (event.target.checked) {
                        param = true;
                    }
                    $('#' + pluginId).spreadsheetWidget(callback, param);
                    if (otherInfo.actionBar) {
                        spreadsheetEvent.enableActionBarIcon(otherInfo.iconType, otherInfo.toggle);
                    }
                });
            },
            rowContextMenuDelegate: function (pluginId) {
                $("#" + pluginId).delegate("div.rowContextMenuAcitive", "mousedown", function delegate(event) {
                    $('div.rowContextMenuAcitive').contextmenu({
                        target: '#row-context-menu'
                    });
                });
            },
            fontActiveState: function (icontoActiveState) {
                $(icontoActiveState).addClass('iconActive');
            },
            enableActionBarIcon: function (iconType, toggle) {
                if ($(iconType).hasClass('iconActive') && toggle) {
                    $(iconType).removeClass('iconActive');
                } else {
                    $(iconType).addClass('iconActive');
                }
            },
            highlightActionBarFormatting: function (pluginId, style) {
                var bold = style["font-weight"],
                    italic = style["font-style"],
                    underline = style["text-decoration"],
                    fontColor = style["color"],
                    backgroundColor = style["background-color"],
                    fontFamily = style["font-family"],
                    fontSize = style["font-size"];
                $('.spreadsheetControls').find('.iconActive').removeClass('iconActive');
                if (bold === 'bold') {
                    spreadsheetEvent.fontActiveState('.w_Bold');
                }
                if (underline === 'underline') {
                    spreadsheetEvent.fontActiveState('.w_Underline');
                }
                if (italic === 'italic') {
                    spreadsheetEvent.fontActiveState('.w_Italic');
                }
                if (fontColor !== '' && fontColor != undefined) {
                    $('#' + pluginId).find("#fontColorpicker" + pluginId).spectrum("set", fontColor);
                } else {
                    $('#' + pluginId).find("#fontColorpicker" + pluginId).spectrum("set", "#000");
                }
                if (backgroundColor !== '' && backgroundColor != undefined) {
                    $('#' + pluginId).find("#fillColorpicker" + pluginId).spectrum("set", backgroundColor);
                } else {
                    $('#' + pluginId).find("#fillColorpicker" + pluginId).spectrum("set", "#fff");
                }
                if (fontFamily !== '' && fontFamily != undefined) {
                    $('#' + pluginId).find("#fontType").val(fontFamily);
                } else {
                    $('#' + pluginId).find("#fontType").val("Arial");
                }
                if (fontSize !== '' && fontSize != undefined) {
                    $('#' + pluginId).find("#fontSize").val(fontSize.replace("px", ""));
                } else {
                    $('#' + pluginId).find("#fontSize").val(11);
                }
            },
            editCaption: function (pluginId) {
                $('#' + pluginId).delegate('label.spreadSheetViewerName', 'dblclick', function (e) {
                    var captionName = $("#" + pluginId).find('.spreadSheetViewerName').text();
                    $("#" + pluginId).find('.spreadSheetViewerName').hide();
                    $("#" + pluginId).find(".spreadSheetHeaderTextbox").val(captionName);
                    $("#" + pluginId).find(".spreadSheetHeaderTextbox").css("display", "inline-block").focus();
                });

                $('#' + pluginId).delegate('input.spreadSheetHeaderTextbox', 'keypress focusout', function (e) {
                    if (e.which === 13 || e.type === "focusout") {
                        e.preventDefault();
                        var captionName = $("#" + pluginId).find('.spreadSheetHeaderTextbox').val();
                        $("#" + pluginId).find('.spreadSheetHeaderTextbox').hide();
                        $("#" + pluginId).find(".spreadSheetViewerName").text(captionName);
                        $("#" + pluginId).find(".spreadSheetViewerName").show();
                        $("#" + pluginId).spreadsheetWidget('setViewerName', captionName);
                    }
                });
            },
        },
        spreadsheetDataHandling = {
            getArrayIndex: function (array, property) {

            },
            createColDef: function (input) {
                var key,
                    columnModel = [],
                    dataType = 'string',
                    align = 'left';

                for (key in input) {
                    dataType = common.getDataTypeByValue(input[key]);
                    align = common.getAlignByType(dataType);
                    columnModel.push({
                        headerName: key,
                        field: key,
                        headerTooltip: key,
                        cellClass: '',
                        cellStyle: {
                            "text-align": align
                        },
                        sort: '',
                        filter: dataType,
                    });
                }
                return columnModel;
            }
        },
        common = {
            bindDropDown: function (pluginID, controlName, data, defaultSelection) {
                $.each(data, function (i, el) {
                    if (defaultSelection == el.text) {
                        $("#" + pluginID).find(controlName).append("<option selected value='" + el.value + "'>" + el.text + "</option>");
                    } else {
                        $("#" + pluginID).find(controlName).append("<option value='" + el.value + "'>" + el.text + "</option>");
                    }
                });
            },
            hideBySelector: function (selector) {
                $(selector).hide();
            },
            showBySelector: function (selector) {
                $(selector).show();
            },
            enableTooltip: function () {
                /*  $('[data-tooltip="tooltip"]').tooltip({
                      placement: "bottom"
                  });*/
            },
            getAlignByType: function (dataType) {
                var dataTypeAlignment = [{
                    dataType: "String",
                    align: "left"
                },
                    {
                        dataType: "Real",
                        align: "right"
                    },
                    {
                        dataType: "Date",
                        align: "center"
                    }];
                /*get alignmenet based on the Data Type*/
                return dataTypeAlignment.filter(function (obj) {
                    if (obj.dataType === dataType) {
                        return obj.align;
                    }
                })[0].align;
            },
            getDataTypeByValue: function (value) {
                /*get DataType based on the Value*/
                var numericRegExp = new RegExp(/^-?\d*\.?\d+$/);
                if (numericRegExp.test(value)) {
                    return "Real";
                } else {
                    return "String";
                }
            }
        };


    // Define a functional object to hold the api.
    function SpreadsheetWidgetApi($el, options) {
        this.pluginId = $el.attr("id");
        /*Action Bar Properties*/
        this.caption = options.caption;
        this.rowData = options.rowData;
        this.enableRename = options.enableRename; //one of [true, false]
        this.enableActionBar = options.enableActionBar; //one of [true, false]		
        this.enableJumpToRow = options.enableJumpToRow;
        this.enableJumpToColumn = options.enableJumpToColumn;
        this.enableExportToCSV = options.enableExportToCSV;
        this.enableFormatting = options.enableFormatting;
        this.enableCloseButton = options.enableCloseButton;
        this.enableColSorting = options.enableColSorting;
        this.enableRowResize = options.enableRowResize;
        this.enableRowFreezing = options.enableRowFreezing;
        this.enableRowMoveable = options.enableRowMoveable;
        this.uniqueFieldName = options.uniqueFieldName;
        this.fontSizes = options.fontSizes;
        this.fontTypes = options.fontTypes;
        this.onFirstLoad = options.onFirstLoad;
        this.enableAutoSizeColumns = options.enableAutoSizeColumns;
        this.enableSizeColumnsToFit = options.enableSizeColumnsToFit;
        this.defaultColWidth = options.defaultColWidth;
        this.enableRowIndexColumn = options.enableRowIndexColumn;

        /*Cell Properties*/
        this.selectedCell = options.selectedCell; // placeholder to keep current selection of cell
        this.cellFormat = options.cellFormat;

        /*Column Properties*/
        this.selectedColumns = options.selectedColumns; // placeholder to keep current selection of columns
        this.colFormat = options.colFormat;
        this.frozenColumns = options.frozenColumns; // placeholder to keep the frozen column name
        this.hiddenColumns = options.hiddenColumns; // placeholder to keep the hidden column name
        this.sortedColumns = options.sortedColumns; // placeholder to keep the sorted column name
        this.reorderedColumns = options.reorderedColumns;

        /*Row Properties*/
        this.rowContextMenu = options.rowContextMenu;
        this.selectedRows = options.selectedRows; // placeholder to keep current selection of rows
        this.rowFormat = options.rowFormat;
        this.rowNewHeight = options.rowNewHeight;
        this.defaultRowHeight = options.defaultRowHeight;
        this.toggleRowHeightMin = options.defaultRowHeight;
        this.toggleRowHeightMax = options.toggleRowHeightMax;
        this.frozenRows = options.frozenRows;

        this.customStateData = options.customStateData;
        this.rowResize = options.rowResize;

        /*Color By Value Properties*/
        this.enableColorByValue = options.enableColorByValue;
        this.selectedRule = options.selectedRule;
        this.dataFields = options.dataFields;
        this.colorByValueGridOptions = options.colorByValueGridOptions;
        this.colorByValueOperators = options.colorByValueOperators;
        this.colorByRule = options.colorByRule;
        this.gradientMinHexVal = options.gradientMinHexVal;
        this.gradientMidHexVal = options.gradientMidHexVal;
        this.gradientMaxHexVal = options.gradientMaxHexVal;
        this.enableRowSelectionOnCellClick = options.enableRowSelectionOnCellClick;
        this.enableCellDoubleClicked = options.enableCellDoubleClicked;
        this.enableCellSelection = options.enableCellSelection;
        this.enableCustomNavigation = options.enableCustomNavigation;
        this.enableExpotCustomCellRenderer  = options.enableExpotCustomCellRenderer;
        this.exportCustomCellRenderer = options.exportCustomCellRenderer !== "undefined" ? options.exportCustomCellRenderer : "";
        this.gridOptions = {
            myPluginID: this.pluginId,
            columnDefs: options.columnDefs,
            overlayNoRowsTemplate : '<span class="ag-overlay-loading-center">No Records Found</span>',
            enableFilter: options.enableFilter,
            enableColFreezing: options.enableColFreezing,
            enableColSorting: options.enableColSorting,
            suppressMovableColumns: options.enableColumnMoveable ? false : true,
            enableColHide: options.enableColHide,
            enableColResize: options.enableColResize,
            uniqueFieldName: options.uniqueFieldName,
            paginationPageSize: options.paginationPageSize,
            suppressDragLeaveHidesColumns: options.suppressDragLeaveHidesColumns,
            // turn on floating filters
            floatingFilter:  options.enableColumnfloatingFilter,
            /*Column Reordering*/
            newColIndex: null,
            onColumnResized: function (parma) {
                if (parma.finished) {
                    $("#" + this.myPluginID).spreadsheetWidget('colResize', parma);
                }
            },
            onColumnMoved: function (parma) {
                this.newColIndex = parma;
            },
            onDragStopped: function () {
                $("#" + this.myPluginID).spreadsheetWidget('colReorder');
            },

            /*Row*/
            rowSelection: options.rowSelection,
            suppressRowClickSelection: options.suppressRowClickSelection,
            rowModelType: options.rowModelType,
            rowHeight: options.defaultRowHeight,
            rowNewHeight: options.rowNewHeight,
            // no rows to float to start with
            floatingTopRowData: options.floatingTopRowData,
            floatingBottomRowData: options.floatingBottomRowData,
            getRowStyle: formatting.rowFormat,
            getRowHeight: function (params) {
                var uniqueFieldName = this.uniqueFieldName;
                var data = this.rowNewHeight.filter(function (obj) {
                    if (obj.rowId === params.data[uniqueFieldName]) {
                        return obj;
                    }
                });
                if (data.length > 0) {
                    return data[0].height;
                }
                return this.rowHeight;
            },

            /*Events*/
            onViewportChanged: function () {
                $("#" + this.myPluginID).spreadsheetWidget('selectColumns');
            },
            onVirtualColumnsChanged: function () {
                $("#" + this.myPluginID).spreadsheetWidget('enableSortIcons');
                $("#" + this.myPluginID).spreadsheetWidget('selectColumns');
            },
            /*Cell Selection*/
            suppressCellSelection: options.enableCellSelection ? false : true,
            onRowDoubleClicked: options.rowDoubleClicked,
            tabToNextCell: options.onTabToNextCell,
            onCellDoubleClicked : function (params) {
                if(options.enableCellDoubleClicked){
                    $("#" + this.myPluginID).spreadsheetWidget('spreadsheetCellDoubleClicked',params);
                }
            }
        };
        this.onSpreadsheetCellDoubleClicked = options.onSpreadsheetCellDoubleClicked !== "undefined" ? options.onSpreadsheetCellDoubleClicked : "";
        this.onSpreadsheetRowSelected = options.onSpreadsheetRowSelected !== "undefined" ? options.onSpreadsheetRowSelected : "";
        this.onFilterAdd = options.onFilterAdd !== "undefined" ? options.onFilterAdd : "";
        this.onWidgetClose = options.onWidgetClose !== "undefined" ? options.onWidgetClose : "";
        this.onSpreadsheetColumnSorting = options.onSpreadsheetColumnSorting !== "undefined" ? options.onSpreadsheetColumnSorting : "";
        this.statusCellSelected = options.statusCellSelected !== "undefined" ? options.statusCellSelected : "";
    }
    SpreadsheetWidgetApi.prototype = {
        init: function () {
            var $this = this,
                pluginId = $("#" + $this.pluginId),
                WidgetElement = "";
            
            WidgetElement += "<div id='viewer_" + $this.pluginId + "' class='widgetBlock spreadsheetWidget' data-plugin='" + $this.pluginId + "'>"; //Spreadsheet Widget
          
            if (this.enableActionBar || this.caption != "") {
                //Spreadsheet Widget Header
                WidgetElement += "<div id='viewerHeader_" + $this.pluginId + "' class='widgetHeader'>";
                WidgetElement += "<label id='viewerName_" + $this.pluginId + "' class='w_title spreadSheetViewerName'>" + this.caption + "</label>"; //Title		
                WidgetElement += " <input class='w_title spreadSheetHeaderTextbox' type='text' style='display:none'/>";

                if (this.enableActionBar) {
                    WidgetElement += createTemplates.actionBar(this);
                }

                WidgetElement += "</div>";
            }
            //Spreadsheet Widget Header

            WidgetElement += "<div id='viewerContainer_" + $this.pluginId + "' class='widgetContent ag-fresh spreadsheetContent'></div>"; //Spreadsheet Widget Content

            WidgetElement += "</div>"; //Spreadsheet Widget

            /*Color By Value HTML*/
            if (this.enableColorByValue) {
                WidgetElement += createTemplates.colorByValue($this.pluginId);
            }

            //Row Context Menu	
            WidgetElement += "<div id='row-context-menu' class='row-context-menu'></div>";
            pluginId.append(WidgetElement);

            if (this.enableRename) {
                spreadsheetEvent.editCaption($this.pluginId);
            }

            if (this.enableActionBar) {
                spreadsheetEvent.actionBarDelegate($this.pluginId);
                createTemplates.enableSortingIcons(false);
                if (this.enableFormatting) {
                    formatting.colorPicker($this.pluginId);
                    common.bindDropDown($this.pluginId, "select#fontSize", this.fontSizes);
                    common.bindDropDown($this.pluginId, "select#fontType", this.fontTypes);
                }
                this.enableDisableIcons();
            }

            /*Color By Value Delegates and Data Binding*/
            if (this.enableColorByValue) {
                spreadsheetEvent.colorByValueDelegates($this.pluginId);
                $("#" + this.pluginId).find(".colorSchemeRules").hide();
                this.bindDataField();
                this.bindValueDataField();
                this.bindColorByValueOperators();
                this.setGridOption();
                this.initColorByValueGrid();
            }

            createTemplates.rowContextMenu($this.pluginId, this.rowContextMenu, {
                enableRowFreezing: this.enableRowFreezing,
                enableRowMoveable: this.enableRowMoveable
            });
            spreadsheetEvent.rowContextMenuDelegate($this.pluginId);

            this.createSpreadsheet();
            common.enableTooltip();
        },
        createSpreadsheet: function () {
            // grid creation.            
            var gridDiv = document.querySelector("#viewerContainer_" + this.pluginId);
            new agGrid.Grid(gridDiv, this.gridOptions);
            if (this.gridOptions.columnDefs != null) {
                if (this.gridOptions.columnDefs.length > 0) {
                    //set the spreadsheet Column Definitions
                    this.setColumnDefs(this.gridOptions.columnDefs);
                }
            }
            if (this.rowData == null) {
                this.gridOptions.api.showNoRowsOverlay();
                return;
            }
           
            if (this.rowData.length > 0) {
                if (this.gridOptions.columnDefs != null) {
                    if (this.gridOptions.columnDefs.length === 0) {
                        //set the spreadsheet Column Definitions
                        this.setColumnDefs(this.rowData[0]);
                    }
                }
                this.setRowData(this.rowData);
            }
        },
        getViewerName: function () {
            return this.caption;
        },
        setViewerName: function (name) {
            if (!this.enableRename) {
                console.error('spreadsheet: Rename is not enabled.');
                return;
            }
            this.caption = name;
            $("#" + this.pluginId).find(".spreadSheetViewerName").text(this.caption);
        },
        setRowData: function (inpModel) {
            //Assign the value to the input data is an actual data
            this.inpData = inpModel;
            //Assign the value to the input data is an actual data if use do some operation on spreadsheet then the data will get updated
            this.curData = inpModel;
            if (this.gridOptions.columnDefs != null) {
                if (this.gridOptions.columnDefs.length === 0) {
                    //set the spreadsheet Column Definitions
                    this.setColumnDefs(inpModel[0]);
                }
            }
            //if there is not column definition setted create the default column definition based on data            
            if (this.enablePagination) {
                this.createNewDatasource();
            } else {
                //assign the value to the ag-grid
                this.gridOptions.api.setRowData(inpModel);
            }
            this.gridOptions.api.hideOverlay();
            this.applyState();  
            
            this.gridOptions.api.sizeColumnsToFit();


        },
        setNoRecords:function(message){
            if(message == "undefined" || message == ""){
                console.error('spreadsheet: please pass the message to set.');
                return;
            }
            this.gridOptions.overlayNoRowsTemplate = '<span class="ag-overlay-loading-center">'+message+'</span>';
            this.gridOptions.api.showNoRowsOverlay();
        },
        getData: function () {
            return this.curData;
        },
        getTotalRecordsCount: function () {
            return this.gridOptions.api.getModel().getRowCount();
        },
        closeWidget: function () {
            if (!this.enableCloseButton) {
                console.error('spreadsheet: closeWidget is not enabled.');
                return;
            }
            $("#" + this.pluginId).remove();
            if (typeof this.onWidgetClose === "function") {
                this.onWidgetClose();
            }
        },
        setCustomState: function (input) {
            var customStateData = this.customStateData,
                uniqueFieldName = this.uniqueFieldName;
            if (this.customStateData.length === 0) {
                customStateData.push(input);
            } else {
                var customeState = customStateData.filter(function (obj) {
                    if (obj.rowID === input.rowID) {
                        obj.newValue = input.newValue;
                        return obj;
                    }
                });
                if (customeState.length === 0) {
                    customStateData.push(input);
                }
            }
            this.customStateData = customStateData;

            this.gridOptions.api.forEachNode(function (node) {
                if (node.data[uniqueFieldName] === input.rowID) {
                    node.data["Marked"] = input.newValue;
                }
            });
        },
        getCustomState: function () {
            return this.customStateData;
        },
        sizeToFit: function () {
            if (!this.enableSizeColumnsToFit) {
                console.error('spreadsheet: Size Columns To Fit is not enabled.');
                return;
            }
            this.gridOptions.api.sizeColumnsToFit();
        },
        autoSizeAllColumns: function () {
            if (!this.enableAutoSizeColumns) {
                console.error('spreadsheet: Auto Size All Columns is not enabled.');
                return;
            }
            var allColumnIds = [];
            this.gridOptions.columnDefs.forEach(function (columnDef) {
                if (columnDef.field != "#Sl") {
                    allColumnIds.push(columnDef.field);
                }
            });
            this.gridOptions.columnApi.autoSizeColumns(allColumnIds);
        },
        setColumnDefs: function (inpModel) {
            var columnModel = [],
                pluginId = this.pluginId,
                uniqueFieldName = this.uniqueFieldName,
                gridOptions = this.gridOptions,
                $this = this;

            //row number col definition
            if (this.onFirstLoad) {
                //Create DOM for Row Index Columns
                function getRowIndex(params) {
                    var value, eValue;

                    //Check for the frozen row count
                    var count = $('#' + pluginId).spreadsheetWidget('getFrozenRowsCount');
                    //Update the rowIndex based on that 
                    if (params.node.floating != undefined || count === 0) {
                        value = parseInt(params.rowIndex) + 1;
                    } else {
                        value = count + parseInt(params.rowIndex) + 1;
                    }

                    eValue = document.createElement('div');
                    eValue.className = 'rowContextMenuAcitive';
                    eValue.innerHTML = "<span>" + value + "</span><div id='spreadsheetRowResizer" + value + "' class='spreadsheetRowResizer' data-rowid = " + params.data[uniqueFieldName] + "></div>";
                    var spreadsheetRowResizer = eValue.querySelector('#spreadsheetRowResizer' + value);
                    spreadsheetRowResizer.addEventListener('mousedown', function (event) {
                        var plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('rowResizes', event);

                    }, false);

                    spreadsheetRowResizer.addEventListener('mousemove', function (event) {
                        var plugin = $(this).closest('.spreadsheetWidget').data('plugin');
                        $('#' + plugin).spreadsheetWidget('onRowResizing', event);
                    }, false);

                    return eValue;
                }

                this.onFirstLoad = false;

                //Setting the Property for Row Index Column
                if (this.enableRowIndexColumn) {
                    columnModel.push({
                        headerName: '#', // header Name will be displayed to the user
                        field: '#Sl', // unique name to identify the column
                        width: 30, // width for the index column
                        suppressSorting: true,
                        pinned: true,
                        cellRenderer: getRowIndex,
                        suppressMovable: true,
                        suppressMenu: true,
                        suppressFilter: true,
                        suppressResize: true,
                        headerTooltip: '#',
                        cellStyle: {
                            "text-align": 'center',
                            'padding': '0px'
                        },
                        onCellClicked: function(params) {
                            $('.spreadsheetControls').find('.iconActive').removeClass('iconActive');
                            $("#" + pluginId).spreadsheetWidget('selectRow', params);
                            $("#" + pluginId).spreadsheetWidget('spreadsheetRowSelected', params);
                        },
                        onCellContextMenu: function(params) {
                            $("#" + pluginId).spreadsheetWidget('selectRow', params);
                        },
                        pluginId: this.pluginId,
                        headerCellTemplate: function(params) {
                            var eCell = document.createElement('span');
                            eCell.setAttribute('data-pluginId', pluginId);
                            eCell.innerText = "#";

                            eCell.addEventListener('click', function(event) {
                                var pluginid = $(this).data('pluginid');
                                $('#' + pluginid).spreadsheetWidget('selectAllRows');
                            });
                            return eCell;
                        }
                    });
                }
            }

            //If the user Defined Column Definition is null the create the column definition by default 
            if (gridOptions.columnDefs.length <= 0) {
                this.gridOptions.columnDefs = spreadsheetDataHandling.createColDef(inpModel);
            }

            $.each(gridOptions.columnDefs, function (key, value) {
                if (value.field !== "#") {

                    if (value.width == undefined) {

                        value.width = $this.defaultColWidth;
                    }
                    value.pluginId = this.pluginId;
                    value.minWidth = 40;
                    value.headerTooltip = value.field;
                    value.enableColFreezing = $this.enableColFreezing;
                    value.onCellClicked = function (params) {
                        if ($this.enableRowSelectionOnCellClick) {
                            $('.spreadsheetControls').find('.iconActive').removeClass('iconActive');
                            $("#" + pluginId).spreadsheetWidget('selectRow', params);
                            $("#" + pluginId).spreadsheetWidget('spreadsheetRowSelected', params);
                        }
                        if ($this.enableCellSelection) {
                            $("#" + pluginId).spreadsheetWidget('selectCell', params);
                        }
                    };
                    if (typeof value.isHeaderMenu === 'undefined') {
                        value.isHeaderMenu = true;
                    }
                    if (value.isHeaderMenu) {
                        value.headerCellTemplate = createTemplates.columnContextMenu;
                    }
                    value.unSortIcon = false;
                    if ($this.enableFormatting) {
                        value.cellStyle = formatting.cellFormat;
                    }
                }
                columnModel.push(value);
            });

            if (columnModel) {
                gridOptions.columnDefs = columnModel;
                gridOptions.api.setColumnDefs(columnModel);
                if(this.enableSizeColumnsToFit){
                    this.sizeToFit();
                }
                
            } else {
                return null;
            }
        },
        ResetColumnDefinition : function(colDef){
            if(colDef == null)
            {
                console.error('spreadsheet: column definition cannot be blank.');
            }
            this.gridOptions.columnDefs = colDef;
            this.gridOptions.api.setColumnDefs(colDef);
        },
        getSpreadsheetParam: function (retParam) {
            //Get all the Spreadsheet Properties
            if (typeof retParam === "string") {
                if (this[retParam] === undefined) {
                    throw "spreadsheet: Parameter " + retParam + " does not exist";
                }
                return this[retParam];
            }
            return this;
        },
        /*Row Functions*/
        spreadsheetRowSelected: function () {
            var selectedRows = this.getSelectedRowData();
            //Raised immediately after row was clicked.
            if (typeof this.onSpreadsheetRowSelected === "function") {
                this.onSpreadsheetRowSelected(this.pluginId, selectedRows);
            }
        },
        spreadsheetColumnSorting: function () {
            var sortedData = [];
            this.gridOptions.api.forEachNodeAfterFilterAndSort(function (rowNode) {
                sortedData.push(rowNode.data);
            });
            if (typeof this.onSpreadsheetColumnSorting === "function") {
                this.onSpreadsheetColumnSorting(sortedData);
            }
        },
        selectRow: function (inputParam) {
            var selected = this.selectedRows.selected,
                rowFormat = this.rowFormat,
                uniqueFieldName = this.uniqueFieldName;

            //Removing all the Cell Selection
            this.deSelectAllCell();
            //Removing all the Column Selection
            this.deSelectAllColumn();
            if (inputParam.event.shiftKey) {
                var startValue, endValue;
                selected = [];
                //Get the Start and end value to loop through all the rows
                startValue = Number(this.selectedRows.currentSelected);
                endValue = Number(inputParam.rowIndex);
                if (startValue > endValue) {
                    //swapping 2 variable
                    startValue = startValue + endValue;
                    endValue = startValue - endValue;
                    startValue = startValue - endValue;
                }
                //Deselect all the selected rows
                this.deSelectAllRows();
                this.gridOptions.api.forEachNodeAfterFilterAndSort(function (node) {
                    if (node.childIndex >= startValue && node.childIndex <= endValue) {
                        node.setSelected(true); //Select the row
                        //Maintain Currently Selected Rows						
                        selected.push({
                            rowIndex: node.childIndex,
                            node: node,
                            data: node.data
                        });
                    }
                    if (node.childIndex > endValue) {
                        return false;
                    }
                });
                //update the selected Records				
                this.updateSelectedRows(inputParam.rowIndex, selected);
            } else if (inputParam.event.ctrlKey) {
                if (!inputParam.node.selected) {
                    //select the current row
                    inputParam.node.setSelected(true);
                    //update the selected Records
                    selected.push({
                        rowIndex: inputParam.rowIndex,
                        node: inputParam.node,
                        data: inputParam.data
                    });
                    this.updateSelectedRows(inputParam.rowIndex, selected);
                } else {
                    inputParam.node.setSelected(false);
                }
            } else {
                //Deselect all the selected rows
                this.deSelectAllRows();
                //select the current row
                inputParam.node.setSelected(true);
                //update the selected Records
                this.updateSelectedRows(inputParam.rowIndex, [{
                    rowIndex: inputParam.rowIndex,
                    node: inputParam.node,
                    data: inputParam.data
                }]);
                if (this.enableFormatting) {
                    /*Highlighting the Row Format in the Action BAr*/
                    var style = rowFormat.filter(function (obj) {
                        if (obj.id === inputParam.data[uniqueFieldName]) {
                            return obj;
                        }
                    });
                    if (style.length > 0) {
                        spreadsheetEvent.highlightActionBarFormatting(this.pluginId, style[0].style);
                    } else {
                        spreadsheetEvent.highlightActionBarFormatting(this.pluginId, {});
                    }
                }
            }
        },
        setRowSelected: function (input) {
            var uniqueField = this.uniqueFieldName;
            var uniqueFieldData = $.map(input.data, function (k, v) {
                return k[uniqueField];
            });
            var selected = [],
                currIndex;
            this.deSelectAllRows();
            this.gridOptions.api.forEachNode(function (node) {
                var dataExist = $.inArray(node.data[uniqueField], uniqueFieldData);
                if (dataExist != -1) {
                    node.setSelected(true);
                    selected.push({
                        rowIndex: node.childIndex,
                        node: node,
                        data: node.data
                    });
                    currIndex = node.childIndex;
                }
            });
            //update the selected Records
            this.updateSelectedRows(currIndex, selected);
        },
        selectRowByIndex: function (index) {
            var model = this.gridOptions.api.getModel();
            model.getRow(index).setSelected(true);
        },
        spreadsheetCellDoubleClicked : function(params){
            //check cell double click is enabled
            if (!this.enableCellDoubleClicked) {
                console.error('spreadsheet: cell double click is not enabled.');
                return;
            }
            //Function to return cell double click
            if (typeof this.onSpreadsheetCellDoubleClicked === "function") {
                this.onSpreadsheetCellDoubleClicked(params);
            }
        },
        updateSelectedRows: function (currIndex, data) {
            //Update the last selected Index
            this.selectedRows.lastSelected = this.selectedRows.currentSelected;
            //Update the currently selected index
            this.selectedRows.currentSelected = currIndex;
            //Maintain Currently Selected Rows
            this.selectedRows.selected = data;
        },
        selectAllRows: function () {
            this.gridOptions.api.selectAll();
            var selectedRows = this.gridOptions.api.getSelectedRows();
            this.selectedRows.selected = [];
            this.selectedRows.selected = jQuery.map(selectedRows, function (value) {
                return {
                    data: value
                };
            });
        },
        deSelectAllRows: function () {
            this.gridOptions.api.deselectAll();
            this.selectedRows.selected = [];
        },
        getSelectedRowData: function () {
            //Get all Selected Row Data of the Spreadsheet
            return this.gridOptions.api.getSelectedRows();
        },
        getSelectedRowNodes: function () {
            //Get all Selected Row Nodes of the Spreadsheet
            return this.gridOptions.api.getSelectedNodes();
        },
        /*Column Selection*/
        getSelectedColumn: function (inputParam) {
            if ($.inArray(inputParam.colID, this.selectedColumns.selected) >= 0) {
                return false;
            }
            var newColumnDefs = this.gridOptions.columnApi.getAllDisplayedColumns(),
                selCol = this.selectedColumns.selected,
                selectContinuous = "",
                lastSelected = this.selectedColumns.lastSelected,
                colFormat = this.colFormat,
                pluginId = this.pluginId,
                colId = inputParam.colID,
                colIdEvent = inputParam.event;

            //Get the object of the column to be deSelected
            var deSelectColumnObj = this.selectedColumns.selected.filter(function (obj) {
                if (obj.Name === colId && colIdEvent.ctrlKey) {
                    return obj;
                }
            });

            //removing all the Column Selection
            this.deSelectAllColumn();
            //Removing all the Cell Selection
            this.deSelectAllCell();
            //Removing all the Row Selection
            this.deSelectAllRows();
            this.updateSelectedColumn(inputParam.colID, this.selectedColumns.selected);
            /*get all the selected columns*/
            $.each(newColumnDefs, function (i) {
                if (inputParam.event.shiftKey) {
                    if (newColumnDefs[i].colId === lastSelected || newColumnDefs[i].colId === inputParam.colID) {
                        if (selectContinuous === "") {
                            selCol = [];
                            selectContinuous = "Start";
                        } else if (selectContinuous === "Start") {
                            selectContinuous = "End";
                        }
                    }
                    if (selectContinuous === "Start" || selectContinuous === "End") {
                        selCol.push({
                            colIndex: i,
                            Name: newColumnDefs[i].colId
                        });
                        if (selectContinuous === "End") {
                            selectContinuous = "";
                        }
                    }
                } else if (inputParam.event.ctrlKey) {
                    if (newColumnDefs[i].colId === inputParam.colID && deSelectColumnObj.length === 0) {
                        selCol.push({
                            colIndex: i,
                            Name: newColumnDefs[i].colId
                        });
                    } else if (newColumnDefs[i].colId === inputParam.colID && newColumnDefs[i].colId !== deSelectColumnObj[0].Name) {
                        selCol.push({
                            colIndex: i,
                            Name: newColumnDefs[i].colId
                        });

                    } else if (deSelectColumnObj.length > 0) {
                        if (newColumnDefs[i].colId === deSelectColumnObj[0].Name) {
                            var deSelectIndex;
                            selCol.filter(function (obj, index) {
                                if (obj.colIndex === i) {
                                    deSelectIndex = index;
                                    deSelectIndex = index;
                                }
                            });
                            selCol.splice(deSelectIndex, 1);
                        }
                    }
                } else {
                    if (newColumnDefs[i].colId === inputParam.colID) {
                        selCol = [];
                        selCol.push({
                            colIndex: i,
                            Name: newColumnDefs[i].colId
                        });
                    }
                    if (this.enableFormatting) {
                        var style = colFormat.filter(function (obj) {
                            if (obj.col === inputParam.colID) {
                                return obj;
                            }
                        })[0].style;
                        if (style != undefined) {
                            spreadsheetEvent.highlightActionBarFormatting(pluginId, style);
                        } else {
                            spreadsheetEvent.highlightActionBarFormatting(pluginId, {});
                        }
                    }
                }
            });

            this.updateSelectedColumn(inputParam.colID, selCol);
            /*apply style to selected col*/
            this.selectColumns();
            createTemplates.enableSortingIcons(true);
        },
        selectColumns: function () {
            var selCol = this.selectedColumns.selected,
                sortedColumns = this.sortedColumns;
            $.each(selCol, function (i, val) {
                $("div[colid='" + val.Name + "']").addClass('selectedCol');
            });

            if (selCol.length === 1) {
                var sort = sortedColumns.filter(function (obj) {
                    if (obj.colId === selCol[0].Name) {
                        return obj;
                    }
                });
                if (sort !== undefined && sort.length > 0) {
                    if (sort[0].sort === "asc") {
                        $("#sortAsc").addClass('iconActive');
                        $("#sortDesc").removeClass('iconActive');
                    } else {
                        $("#sortAsc").removeClass('iconActive');
                        $("#sortDesc").addClass('iconActive');
                    }
                }
            }
        },
        updateSelectedColumn: function (colId, data) {
            //Update the last selected Index
            this.selectedColumns.lastSelected = this.selectedColumns.currentSelected === "" ? colId : this.selectedColumns.currentSelected;
            //Update the currently selected index
            this.selectedColumns.currentSelected = colId;
            //Maintain Currently Selected Rows
            this.selectedColumns.selected = data;
        },
        selectAllColumn: function () {
            var newColumnDefs = this.gridOptions.columnDefs,
                selCol = [];
            $.each(newColumnDefs, function (i, val) {
                selCol.push({
                    colIndex: i,
                    Name: newColumnDefs[i].field
                });

                $("div[colid='" + newColumnDefs[i].field + "']").addClass('selectedCol');
            });
        },
        deSelectAllColumn: function () {
            this.selectedColumns.selected = [];
            $("#" + this.pluginId).find("div").removeClass('selectedCol');
            createTemplates.enableSortingIcons(false);
        },
        /*Cell Selection*/
        selectCell: function (inputParam) {
            var cellSelectedStatus = false;
            if (this.selectedRows.selected.length > 0) {
                cellSelectedStatus = true;
            }
            if (this.enableFormatting) {
                spreadsheetEvent.highlightActionBarFormatting(this.pluginId, inputParam.event.target.style);
            }
            //Removing all the Columns Selection
            this.deSelectAllColumn();
            //Removing all the Row Selection
            this.deSelectAllRows();
            if (inputParam.event.shiftKey) {
                //update the selected Records
                this.updateSelectedCell(inputParam);
            } else if (inputParam.event.ctrlKey) {
                if (inputParam.colDef.field === inputParam.colDef.field) {

                } else {

                }
                //update the selected Records
                this.updateSelectedCell(inputParam);
            } else {
                //Deselect all the selected cell
                this.deSelectAllCell();
                //update the selected Records
                this.updateSelectedCell(inputParam);
            }
            //this.cellFormat =  cellFormat;
            this.gridOptions.api.setFocusedCell(inputParam.node.rowIndex, inputParam.colDef.field);

            //Function to return selected cell
            if (typeof this.statusCellSelected === "function") {
                this.statusCellSelected(true);
            }
        },
        setCellFocus: function (cellData) {
            //Focus respective column cell based on rowIndex
            this.gridOptions.api.setFocusedCell(cellData.rowIndex, cellData.colName);
        },
        getCurrentRowIndex: function () {
            return this.gridOptions.api.getFocusedCell();
        },
        updateSelectedCell: function (data) {
            //Update the last selected Index
            this.selectedCell.lastSelected = this.selectCell.currentSelected;
            //Update the currently selected index
            this.selectedCell.currentSelected = {
                rowIndex: data.node.rowIndex,
                colID: data.colDef.field,
                value: data.value
            };
            //Maintain Currently Selected Rows
            this.selectedCell.selected.push(data);
        },
        selectAllCell: function () { },
        deSelectAllCell: function () {
            this.selectedCell = {
                lastSelected: "",
                currentSelected: "",
                selected: []
            };
            this.gridOptions.api.setFocusedCell(-1, "");
        },
        getSelectedCell: function(){
            return this.selectedCell;
        },      
        /*Column Freezing*/
        freezeColumn: function (data) {
            //check column freezing is enabled
            if (!this.gridOptions.enableColFreezing) {
                console.error('spreadsheet: Column freezing is not enabled.');
                return;
            }

            //get all the frozen columns
            var forzenColumn = this.frozenColumns;

            //if used send any column to froze add to the frozen column list
            if (typeof data !== "undefined") {
                $.each(data, function (i) {
                    forzenColumn.push(this);
                });
            }

            //freeze all the selected columns
            $.each(this.selectedColumns.selected, function (i) {
                forzenColumn.push({
                    colId: this.Name,
                    pinned: "left"
                });
            });

            //loopthrough all the frozen column list
            for (var i = 0; i < forzenColumn.length; i++) {
                //using grid api method to froze the columns
                this.gridOptions.columnApi.setColumnPinned(forzenColumn[i].colId, forzenColumn[i].pinned);
            }

            this.forzenColumn = forzenColumn;

            //enabling disabling of un-pin and un-pin all menus
            if (this.frozenColumns.length === 0) {
                common.hideBySelector(".unpin");
                common.hideBySelector(".unpinall");
            } else {
                common.showBySelector(".unpin");
                common.showBySelector(".unpinall");
            }
        },
        unFreezeColumn: function (data) {
            //check column freezing is enabled
            if (!this.gridOptions.enableColFreezing) {
                console.error('spreadsheet: Column freezing is not enabled.');
                return;
            }
            if (typeof data === "undefined") {
                data = this.selectedColumns.selected;
            }
            $.each(this.selectedColumns.selected, function (i) {
                data.push({
                    colId: this.Name,
                    pinned: null
                });
            });
            for (var i = 0; i < data.length; i++) {
                this.gridOptions.columnApi.setColumnPinned(data[i].colId, data[i].pinned);
                this.frozenColumns.push({
                    colId: data[i].colId,
                    pinned: data[i].pinned
                });
            }

            if (this.frozenColumns.length === 0) {
                common.hideBySelector(".unpin");
                common.hideBySelector(".unpinall");
            }
        },
        unFreezeAllColumn: function () {
            //check column freezing is enabled
            if (!this.gridOptions.enableColFreezing) {
                console.error('spreadsheet: Column freezing is not enabled.');
                return;
            }
            //loopthrough all the frozen column list
            for (var i = 0; i < this.frozenColumns.length; i++) {
                //using grid api method to un-freeze the columns
                this.gridOptions.columnApi.setColumnPinned(this.frozenColumns[i].colId, null);
            }
            //setting the frozen column list as empty
            this.frozenColumns = [];
        },
        /*Row Freezing*/
        freezeRow: function (position) {
            if (!this.enableRowFreezing) {
                console.error('spreadsheet: Row freezing is not enabled.');
                return;
            }
            var frozenRows = [],
                frozenNodes = [],
                lastSelectedRow = this.gridOptions.api.getFocusedCell().rowIndex;
            this.gridOptions.api.forEachNodeAfterFilterAndSort(function (node, index) {
                if (index <= lastSelectedRow) {
                    frozenRows.push(node.data);
                    frozenNodes.push(node);
                }
                if (index > lastSelectedRow) {
                    return frozenNodes;
                }
            });

            this.frozenRows = frozenRows;
            this.deleteNodes(frozenNodes);
            if (position === 'Botton') {
                this.gridOptions.api.setFloatingBottomRowData(this.frozenRows);
            } else {
                this.gridOptions.api.setFloatingTopRowData(this.frozenRows);
            }
            this.applyState();
            this.getFrozenRowsCount();
        },
        getFrozenRowsCount: function () {
            var frozenRowsCount = this.frozenRows.length;
            return frozenRowsCount;
        },
        unFreezeRow: function (position) {
            if (!this.enableRowFreezing) {
                console.error('spreadsheet: Row freezing is not enabled.');
                return;
            }
            if (position === 'Botton') {
                position = this.curData.length; // getting the Data Length
                //loopthrough all the selected node and move to the new position
                for (var i = 0; i < this.frozenRows.length; i++) {
                    this.insertItemsAtIndex(position, this.frozenRows[i]);
                }
                this.gridOptions.api.setFloatingBottomRowData([]);
            } else {
                //loopthrough all the selected node and move to the new position
                for (var j = this.frozenRows.length - 1; j >= 0; j--) {
                    this.insertItemsAtIndex(0, this.frozenRows[j]);
                }
                this.gridOptions.api.setFloatingTopRowData([]);
            }
            this.frozenRows = [];
            common.hideBySelector("#" + this.pluginId + " #row-context-menu #unFreezeRow");
            common.showBySelector("#" + this.pluginId + " #row-context-menu #freezerow");
            this.applyState();
        },
        /*Sorting*/
        sortColumn: function (data) {
            if (!this.enableColSorting) {
                console.error('spreadsheet: Sorting is not enabled.');
                return;
            }
            //Enable Ag-Grid Sorting
            this.gridOptions.enableSorting = true;
            $("#" + this.pluginId).find("span#agSortAsc1").addClass("ag-hidden");
            $("#" + this.pluginId).find("span#agSortDesc1").addClass("ag-hidden");
            var sortData = this.sortedColumns,
                colIdName;

            //Checking is there any parameter is passed 
            if (typeof data !== "undefined") {
                //checking is the column is already sorted
                var retVal = sortData.filter(function (obj) {
                    if (obj.colId === data[0].colId) {
                        obj.sort = data[0].sort;
                        return obj;
                    }
                });

                //if the column is not sorted
                if (retVal.length === 0) {
                    if (data[0].colId !== "") {
                        //adding the column to the sort list on first position
                        sortData.push(data[0]);
                        colIdName = data[0].colId;
                    }
                }
            }

            if (typeof data === "undefined") {
                //getting all the selected columns
                data = this.selectedColumns.selected;

            }

            //loop  through all the selected column and add the column to the select list
            $.each(this.selectedColumns.selected, function (i) {
                if (data[0].colId === "") {
                    colIdName = this.Name;
                }
                var sortedColumn = sortData.filter(function (obj) {
                    //if the selected column is already sorted update the sort type
                    if (obj.colId == colIdName) {
                        obj.sort = data[0].sort;
                        return obj;
                    }
                });

                //if the selected column is not sorted add to the sort list
                if (sortedColumn.length == 0) {
                    var sortedColumnData = {
                        colId: this.Name,
                        sort: data[0].sort
                    };
                    sortData.push(sortedColumnData);
                }
            });

            //Assigning the sortData to sortedColumns for further use
            this.sortedColumns = sortData;
            //sorting the column using ag-grid api method
            this.gridOptions.api.setSortModel(sortData);

            //Disable Ag-Grid Sorting
            this.gridOptions.enableSorting = false;

            //Enable or disable sort icons 
            this.enableSortIcons();

            this.selectColumns();

            //Call back function for onSpreadsheetColumnSorting
            this.spreadsheetColumnSorting();
        },
        enableSortIcons: function () {
            var sortData = this.sortedColumns;
            //enable or disable un-sort menu 
            if (sortData === undefined || sortData.length === 0) {
                common.hideBySelector(".unsortall");
            } else {
                common.showBySelector(".unsortall");
            }
            $.each(sortData, function (i, obj) {
                if (obj.sort === "asc") {
                    $("span[colid='" + obj.colId + "']").find("#agSortAsc1").removeClass("ag-hidden");
                    $("span[colid='" + obj.colId + "']").find("#agSortDesc1").addClass("ag-hidden");
                    $("#sortAsc").addClass('iconActive');
                    $("#sortDesc").removeClass('iconActive');
                    $("span[colid='" + obj.colId + "']").find("#agSortAsc1 .s_MenuDropDown").addClass('activeBorder');
                    $("span[colid='" + obj.colId + "']").find("#agSortAsc1 .s_MenuDropDown").removeClass('inActiveBorder');
                } else if (obj.sort === "desc") {
                    $("span[colid='" + obj.colId + "']").find("#agSortDesc1").removeClass("ag-hidden");
                    $("span[colid='" + obj.colId + "']").find("#agSortAsc1").addClass("ag-hidden");
                    $("#sortAsc").removeClass('iconActive');
                    $("#sortDesc").addClass('iconActive');
                    $("span[colid='" + obj.colId + "']").find("#agSortDesc1 .s_MenuDropDown").addClass('activeBorder');
                    $("span[colid='" + obj.colId + "']").find("#agSortDesc1 .s_MenuDropDown").removeClass('inActiveBorder');
                }

            });

        },
        unsortAllColumn: function (data) {
            if (!this.enableColSorting) {
                console.error('spreadsheet: Sorting is not enabled.');
                return;
            }
            this.gridOptions.enableSorting = true;
            this.gridOptions.api.setSortModel(null);
            this.gridOptions.enableSorting = false;
            this.sortedColumns = [];
            if (this.sortedColumns === undefined || this.sortedColumns.length === 0) {
                common.hideBySelector(".unsortall");
            } else {
                common.showBySelector(".unsortall");
            }
            $("#" + this.pluginId).find("span#agSortAsc1").addClass("ag-hidden");
            $("#" + this.pluginId).find("span#agSortDesc1").addClass("ag-hidden");
            this.resizeRowHeight();
            var sorteddata = [];
            this.gridOptions.api.forEachNodeAfterFilterAndSort(function (rowNode) {
                sorteddata.push(rowNode.data);
            });
            this.spreadsheetColumnSorting(sorteddata);
        },
        getSortModel: function () {
            return this.sortedColumns;
        },
        /*column hide/unhide*/
        hideColumn: function (data) {
            if (!this.gridOptions.enableColHide) {
                console.error('spreadsheet: Column hide is not enabled.');
                return;
            }
            var hideColumn = this.hiddenColumns;
            if (typeof data !== "undefined") {
                $.each(data, function (i) {
                    hideColumn.push(this);
                });
            }
            $.each(this.selectedColumns.selected, function (i) {
                hideColumn.push(this.Name);
            });
            if (hideColumn.length !== 0) {
                this.gridOptions.columnApi.setColumnsVisible(hideColumn, false);
                this.hiddenColumns = hideColumn;
                this.enableDisableIcons();
            }
        },
        unhideColumn: function (data) {
            if (!this.gridOptions.enableColHide) {
                console.error('spreadsheet: Column hide is not enabled.');
                return;
            }
            var hideColumn = this.hiddenColumns;
            if (typeof data !== "undefined") {
                $.each(data, function (i) {
                    hideColumn.push(this);
                });
            }
            $.each(this.selectedColumns.selected, function (i) {
                hideColumn.push(this.Name);
            });
            if (hideColumn.length !== 0) {
                this.gridOptions.columnApi.setColumnsVisible(hideColumn, true);
                this.hiddenColumns = hideColumn;
                this.enableDisableIcons();
            }
        },
        enableDisableIcons: function () {
            if (this.hiddenColumns.length === 0) {
                common.hideBySelector("#" + this.pluginId + " #unhideAll");
                common.hideBySelector(".unHideAll");
            } else {
                common.showBySelector("#" + this.pluginId + " #unhideAll");
                common.showBySelector(".unHideAll");
            }
        },
        unhideAll: function (data) {
            if (!this.gridOptions.enableColHide) {
                console.error('spreadsheet: Column hide is not enabled.');
                return;
            }
            for (var i = 0; i < this.hiddenColumns.length; i++) {
                this.gridOptions.columnApi.setColumnVisible(this.hiddenColumns[i], true);
            }
            this.hiddenColumns = [];
            this.enableDisableIcons();

        },
        /*Formatting*/
        fontOptions: function (type, value, mandatory, toggle) {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            var selectedCols = this.selectedColumns.selected,
                colFormat = this.colFormat,
                selectedRows = this.selectedRows.selected,
                rowFormat = this.rowFormat,
                selectedCell = this.selectedCell.selected,
                cellFormat = this.cellFormat,
                uniqueFieldName = this.uniqueFieldName;

            /*Cell is the cell is selected*/
            if (selectedCell.length > 0) {
                /*format all the seleted row*/
                $.each(selectedCell, function (i) {
                    /*if already formatted */
                    var data = cellFormat.filter(function (obj) {
                        if (selectedCell[i].colDef.field == obj.col && selectedCell[i].data[uniqueFieldName] == obj.row && selectedCell[i].value == obj.value) {
                            obj = formatting.setCellFormat(obj, type, value, mandatory, true);
                            return obj;
                        }
                    });

                    if (data.length === 0) {
                        var row = {
                            row: selectedCell[i].data[uniqueFieldName],
                            col: selectedCell[i].colDef.field,
                            value: selectedCell[i].value,
                            style: {}
                        };
                        row = formatting.setCellFormat(row, type, value, mandatory, true);
                        cellFormat.push(row);
                    }
                });
                this.cellFormat = cellFormat;
                this.formatCell();
            }

            /*Check is the column is selected*/
            if (selectedCols.length > 0) {
                /*format all the seleted row*/
                $.each(selectedCols, function (i, colVal) {
                    $.each(cellFormat, function (index, obj) {
                        if (obj.col === colVal.Name) {
                            if (obj.style[type] == value) {
                                delete obj.style[type];
                            } else {
                                obj.style[type] = value;
                            }
                            return obj;
                        }
                    });

                    /*if already formatted */
                    var data = colFormat.filter(function (obj) {
                        if (obj.col === selectedCols[i].Name) {
                            obj = formatting.setColFormat(obj, type, value, mandatory, true);
                            return obj;
                        }
                    });
                    if (data.length === 0) {
                        var col = {
                            col: selectedCols[i].Name,
                            style: {}
                        };
                        col = formatting.setColFormat(col, type, value, mandatory, true);
                        colFormat.push(col);
                    }
                });
                this.colFormat = colFormat;
                this.formatColumn();
            }

            /*Check is the row is selected*/
            if (selectedRows.length > 0) {
                /*Check any selected row is formatted*/
                $.each(selectedRows, function (i) {
                    cellFormat.filter(function (obj) {
                        if (obj.row === selectedRows[i].data[uniqueFieldName]) {
                            if (obj.style[type] === value) {
                                delete obj.style[type];
                                return obj;
                            }
                        }
                    });

                    rowFormat.filter(function (obj) {
                        if (obj.id === selectedRows[i].data[uniqueFieldName]) {
                            if (typeof obj.style[type] === 'undefined') {
                                mandatory = true;
                            }
                        }
                    });
                });

                /*format all the seleted row*/
                $.each(selectedRows, function (i) {
                    /*if already formatted */
                    var data = rowFormat.filter(function (obj) {
                        if (obj.id === selectedRows[i].data[uniqueFieldName]) {
                            obj = formatting.setRowFormat(obj, type, value, mandatory, true);
                            return obj;
                        }
                    });
                    if (data.length === 0) {
                        var row = {
                            id: selectedRows[i].data[uniqueFieldName],
                            style: {}
                        };
                        row = formatting.setRowFormat(row, type, value, mandatory, true);
                        rowFormat.push(row);
                    }
                });
                this.rowFormat = rowFormat;
                this.formatRow();
            }

            this.selectColumns();
        },
        removeAllFormat: function () {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            $.each(this.gridOptions.columnDefs, function (i, obj) {
                $("div[colid='" + obj.field + "']").css('background-color', '');
                $("div[colid='" + obj.field + "']").css('color', '');
                $("div[colid='" + obj.field + "']").css('font-weight', '');
                $("div[colid='" + obj.field + "']").css('font-style', '');
                $("div[colid='" + obj.field + "']").css('text-decoration', '');
                $("div[colid='" + obj.field + "']").css('font-size', '');
                $("div[colid='" + obj.field + "']").css('font-family', '');
            });
        },
        format: function (input) {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            $("div[row='" + input.id + "'] div[colid='" + input.col + "']").css('color', input.style['color'] === undefined ? "" : input.style['color']);

            $("div[row='" + input.id + "'] div[colid='" + input.col + "']").css('background-color', input.style['background-color'] === undefined ? "" : input.style['background-color']);

            $("div[row='" + input.id + "'] div[colid='" + input.col + "']").css('font-weight', input.style['font-weight'] === undefined ? "" : input.style['font-weight']);

            $("div[row='" + input.id + "'] div[colid='" + input.col + "']").css('font-style', input.style['font-style'] === undefined ? "" : input.style['font-style']);

            $("div[row='" + input.id + "'] div[colid='" + input.col + "']").css('text-decoration', input.style['text-decoration'] === undefined ? "" : input.style['text-decoration']);

            $("div[row='" + input.id + "'] div[colid='" + input.col + "']").css('font-size', input.style['font-size'] === undefined ? "" : input.style['font-size']);

            $("div[row='" + input.id + "'] div[colid='" + input.col + "']").css('font-family', input.style['font-family'] === undefined ? "" : input.style['font-family']);
        },
        formatRow: function (type, fotmatValue, mandatory, toggle) {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            var nodes = this.gridOptions.api.getRenderedNodes();
            //Refreshing all the Rows
            this.gridOptions.api.refreshRows(nodes);
        },
        formatColumn: function () {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            var colFormat = this.colFormat;
            $.each(colFormat, function (index, obj) {
                $("div[colid='" + obj.col + "']").css(obj.style);
            });
        },
        formatCell: function (type, fotmatValue, mandatory, toggle) {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            var nodes = this.gridOptions.api.getRenderedNodes();
            //Refreshing all the Rows
            this.gridOptions.api.refreshRows(nodes);
        },
        bold: function () {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            this.fontOptions('font-weight', 'bold', false, true);
        },
        italic: function () {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            this.fontOptions('font-style', 'italic', false, true);
        },
        underline: function () {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            this.fontOptions('text-decoration', 'underline', false, true);
        },
        fontSize: function (value) {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            this.fontOptions('font-size', value + "px", true, false);
        },
        fontType: function (value) {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            this.fontOptions('font-family', value, true, false);
        },
        fontColor: function (value) {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            this.fontOptions('color', value, true, false);
        },
        backgroundColor: function (value) {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            this.fontOptions('background-color', value, true, false);
        },
        getRowFormat: function () {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            var rowFormat = this.rowFormat;
            this.rowFormat = [];
            for (var i = rowFormat.length - 1; i >= 0; i--) {
                if (!$.isEmptyObject(rowFormat[i].style)) {
                    this.rowFormat.push(rowFormat[i]);
                }
            }
            return this.rowFormat;
        },
        getCellFormat: function () {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            return this.cellFormat;
        },
        getColFormat: function () {
            if (!this.enableFormatting) {
                console.error('spreadsheet: formatting is not enabled.');
                return;
            }
            return this.colFormat;
        },
        /*Data Source Creation*/
        createNewDatasource: function () {
            this.gridOptions.rowModelType = 'pagination';
            var data = this.inpData;
            if (!data) {
                // in case user selected 'onPageSizeChanged()' before the json was loaded
                return;
            }
            var dataSource = {
                //rowCount: ???, - not setting the row count, infinite paging will be used
                getRows: function (params) {
                    // this code should contact the server for rows. however for the purposes of the demo,
                    // the data is generated locally, a timer is used to give the experience of
                    // an asynchronous call

                    setTimeout(function () {
                        // take a chunk of the array, matching the start and finish times
                        var rowsThisPage = data.slice(params.startRow, params.endRow);
                        // see if we have come to the last page. if we have, set lastRow to
                        // the very last row of the last page. if you are getting data from
                        // a server, lastRow could be returned separately if the lastRow
                        // is not in the current page.
                        var lastRow = -1;
                        if (data.length <= params.endRow) {
                            lastRow = data.length;
                        }
                        params.successCallback(rowsThisPage, lastRow);
                    }, 500);
                }
            };
            this.gridOptions.api.setDatasource(dataSource);
        },
        /*Row Reordering*/
        rowReorder: function (input) {
            if (!this.enableRowMoveable) {
                console.error('spreadsheet: Row Moveable is not enabled.');
                return;
            }
            var newIndex = 0,
                selectedNodes = this.gridOptions.api.getSelectedNodes(); //get all selected nodes
            if (input.position === "Top") {
                newIndex = 0;
            } else if (input.position === "Bottom") {
                newIndex = this.inpData.length - 1;
            }
            //loopthrough all the selected node and move to the new position
            for (var i = selectedNodes.length - 1; i >= 0; i--) {
                if (input.position === "Up") {
                    if (parseInt(selectedNodes[i].childIndex) !== 0) {
                        newIndex = parseInt(selectedNodes[i].childIndex) - 1;
                    }
                } else if (input.position === "Down") {
                    if ((parseInt(selectedNodes[i].childIndex)) !== (this.inpData.length - 1)) {
                        newIndex = parseInt(selectedNodes[i].childIndex) + 1;
                    } else {
                        newIndex = parseInt(selectedNodes[i].childIndex);
                    }
                }

                //delete all selected nodes
                this.deleteNodes([selectedNodes[i]]);
                var data = selectedNodes[i].data;
                this.insertItemsAtIndex(newIndex, data);
                var model = this.gridOptions.api.getModel();
                model.getRow(selectedNodes[i].childIndex);
                this.selectRowByIndex(newIndex);
            }
        },
        /*Column Reordering*/
        colReorder: function (input) {
            if (this.gridOptions.suppressMovableColumns) {
                console.error('spreadsheet: Column moveable is not enabled.');
                return;
            }
            var newColDef = this.gridOptions.columnApi.getAllColumns(),
                gridOptions = this.gridOptions,
                data = this.gridOptions.newColIndex,
                newIndex = this.gridOptions.newColIndex.toIndex,
                //get all the selected columns
                selCol = this.selectedColumns.selected;

            if (newIndex === 0) {
                newIndex += 1;
            }
            if (typeof data !== "undefined") {
                var retVal = selCol.filter(function (obj) {
                    if (obj.Name === data.column.colId) {
                        return obj;
                    }
                });
                if (retVal.length === 0) {
                    gridOptions.columnApi._columnController.moveColumn(data.column.colId, newIndex);
                    newIndex++;
                }
            }
            this.gridOptions.columnApi.setColumnPinned(data.column.colId, null);
            for (var i = newColDef.length - 1; i >= 0; i--) {
                selCol.filter(function (obj) {
                    if (newColDef[i].colId === obj.Name) {
                        gridOptions.columnApi._columnController.moveColumn(newColDef[i].colId, newIndex);
                    }
                });
            }
            //this.reorderedColumns.push();
        },
        /*Column Resizing*/
        colResize: function (input) {
            if (!this.gridOptions.enableColResize) {
                console.error('spreadsheet: Column Resizing is not enabled.');
                return;
            }
            var newColDef = this.gridOptions.columnDefs,
                selCol = [],
                gridOptions = this.gridOptions;

            //get all the selected columns
            selCol = this.selectedColumns.selected;
            var colSelected = selCol.filter(function (obj) {
                if (input.column.colId === obj.Name) {
                    return obj;
                }
            });

            if (selCol.length <= 0 || colSelected.length <= 0) {
                selCol = [];
                if (input.column != undefined) {
                    selCol.push({
                        Name: input.column.colId
                    });
                }
            }
            $.each(selCol, function (index, value) {
                newColDef.filter(function (obj) {
                    if (input.column.colId == obj.field || value.Name == obj.field) {
                        gridOptions.columnApi._columnController.setColumnWidth(obj.field, input.column.actualWidth, false);
                        obj.width = input.column.actualWidth;
                    }
                });
            });

            this.gridOptions.api.refreshView();
            this.selectColumns();
        },
        /*Row Resizing*/
        rowHeight: function (height) {

        },
        toggleRowHeight: function () {
            if (!this.enableRowResize) {
                console.error('spreadsheet: Row Resizing is not enabled.');
                return;
            }
            this.defaultRowHeight = this.defaultRowHeight === this.toggleRowHeightMin ? this.toggleRowHeightMax : this.toggleRowHeightMin;
            var $this = this,
                defaultRowHeight = this.defaultRowHeight,
                topHeight = 0,
                gridOptions = $this.gridOptions,
                nodes = [];


            if (this.sortedColumns != undefined && this.sortedColumns.length > 0) {
                //set New height for each row
                gridOptions.api.forEachNodeAfterFilterAndSort(function (rowNode) {
                    nodes.push($this.updateRowNodeHeight(rowNode, defaultRowHeight, topHeight));
                    topHeight = rowNode.rowHeight + topHeight;
                });
            } else {
                gridOptions.api.forEachNode(function (rowNode) {
                    nodes.push($this.updateRowNodeHeight(rowNode, defaultRowHeight, topHeight));
                    topHeight = rowNode.rowHeight + topHeight;
                });
            }
            gridOptions.api.refreshRows(nodes);
        },
        updateRowNodeHeight: function (rowNode, defaultRowHeight, topHeight) {
            if (!this.enableRowResize) {
                console.error('spreadsheet: Row Resizing is not enabled.');
                return;
            }
            rowNode.rowHeight = defaultRowHeight;
            rowNode.rowTop = topHeight;
            return rowNode;
        },
        rowResizes: function (e) {
            if (!this.enableRowResize) {
                console.error('spreadsheet: Row Resizing is not enabled.');
                return;
            }
            var startHeight = parseInt(e.target.closest(".ag-row").style.height, 10);
            this.rowResize = {
                startY: e.clientY,
                startHeight: startHeight,
                isResize: true,
                rowId: e.target.dataset.rowid
            };
            document.documentElement.addEventListener('mouseup', function (event) {
                var plugin = $(this).find('.spreadsheetWidget').data('plugin');
                $('#' + plugin).spreadsheetWidget('rowStopDrag', event);
            });
        },
        onRowResizing: function (e) {
            if (this.rowResize.isResize) {
                var rowHeight = (this.rowResize.startHeight + e.clientY - this.rowResize.startY);
                $('#' + e.target.id).parent().parent().addClass('rowResizeActive');
                $('#' + e.target.id).parent().parent().parent().find('.rowResizeActive').css('background-color', '#404040');
                $('#' + e.target.id).parent().parent().parent().find('.rowResizeActive').css('opacity', '.5');
                $('#' + e.target.id).parent().parent().parent().find('.rowResizeActive').css('color', '#fff');
                $("#" + e.target.id).parent().parent().parent().find('.rowResizeActive').css('height', rowHeight + 'px');
                $("#" + e.target.id).parent().parent().parent().find('.rowResizeActive').css('position', 'absolute');
                $("#" + e.target.id).parent().parent().parent().find('.rowResizeActive').css('top', '-1px');
                $("#" + e.target.id).parent().parent().parent().find('.rowResizeActive').css('border-right', '1px solid #404040');
                $("#" + e.target.id).parent().parent().parent().css('cursor', 'row-resize');
            }
        },
        rowStopDrag: function (e) {
            if (!this.enableRowResize) {
                console.error('spreadsheet: Row Resizing is not enabled.');
                return;
            }
            if (this.rowResize.isResize) {
                this.rowResize.isResize = false;
                var rowHeight = (this.rowResize.startHeight + e.clientY - this.rowResize.startY),
                    rowId = this.rowResize.rowId,
                    newRowHeight = this.gridOptions.rowNewHeight,
                    selRows = this.getSelectedRowData(),
                    uniqueFieldName = this.uniqueFieldName;

                var rowSel = selRows.filter(function (obj) {
                    return obj[uniqueFieldName] === rowId;
                });
                if (rowSel.length > 0) {
                    $.each(selRows, function (index, value) {
                        var rowData = newRowHeight.filter(function (obj) {
                            if (obj.rowId === value[uniqueFieldName]) {
                                obj.height = rowHeight;
                                return obj;
                            }
                        });
                        if (rowData.length <= 0) {
                            newRowHeight.push({
                                rowId: value[uniqueFieldName],
                                height: rowHeight
                            });
                        }
                    });
                } else {
                    if (newRowHeight.length > 0) {
                        var rowData = newRowHeight.filter(function (obj) {
                            if (obj.rowId === rowId) {
                                obj.height = rowHeight;
                                return obj;
                            }
                        });
                        if (rowData.length <= 0) {
                            newRowHeight.push({
                                rowId: rowId,
                                height: rowHeight
                            });
                        }
                    } else {
                        newRowHeight.push({
                            rowId: rowId,
                            height: rowHeight
                        });
                    }
                }
                //this.sortColumn();
                this.gridOptions.rowNewHeight = newRowHeight;
                this.rowResize.height = rowHeight;
                //this.applyState();
                this.resizeRowHeight();
            }
        },
        resizeRowHeight: function () {
            if (!this.enableRowResize) {
                console.error('spreadsheet: Row Resizing is not enabled.');
                return;
            }
            var uniqueFieldName = this.uniqueFieldName,
                gridOptions = this.gridOptions,
                nodes = [],
                topHeight = 0,
                currentRowId = "",
                newRowHeight = this.gridOptions.rowNewHeight;

            if (this.sortedColumns != undefined && this.sortedColumns.length > 0) {
                //set New height for each row
                gridOptions.api.forEachNodeAfterFilterAndSort(function (rowNode) {
                    //check is the row height is modified
                    var data = newRowHeight.filter(function (obj) {
                        if (obj.rowId === rowNode.data[uniqueFieldName]) {
                            currentRowId = obj.rowId;
                            return obj;
                        }
                    });
                    if (data.length === 0) {
                        //row height is not modified so update only the row top height
                        rowNode.rowTop = topHeight;
                    } else {
                        //Row height is already modified so assign the new row height
                        rowNode.rowHeight = data[0].height;
                        //assign the row top
                        rowNode.rowTop = topHeight;
                    }


                    if (topHeight !== 0) {
                        // calculate the next rop top position
                        topHeight = rowNode.rowHeight + topHeight;
                    } else {
                        //Now we are in first row, For next row just adding the current row height for the nextrow top height
                        topHeight = rowNode.rowHeight;
                    }
                    nodes.push(rowNode);
                });
            } else {
                //set New height for each row
                gridOptions.api.forEachNode(function (rowNode) {
                    //check is the row height is modified
                    var data = newRowHeight.filter(function (obj) {
                        if (obj.rowId === rowNode.data[uniqueFieldName]) {
                            currentRowId = obj.rowId;
                            return obj;
                        }
                    });
                    if (data.length === 0) {
                        //row height is not modified so update only the row top height
                        rowNode.rowTop = topHeight;
                    } else {
                        //Row height is already modified so assign the new row height
                        rowNode.rowHeight = data[0].height;
                        //assign the row top
                        rowNode.rowTop = topHeight;
                    }


                    if (topHeight !== 0) {
                        // calculate the next rop top position
                        topHeight = rowNode.rowHeight + topHeight;
                    } else {
                        //Now we are in first row, For next row just adding the current row height for the nextrow top height
                        topHeight = rowNode.rowHeight;
                    }
                    nodes.push(rowNode);
                });
            }

            //Refreshing all the Rows
            gridOptions.api.refreshRows(nodes);
        },
        /*Export to CSV*/
        exportDatatoCSV: function () {
            if (!this.enableExportToCSV) {
                console.error('spreadsheet: Export to CSV is not enabled.');
                return;
            }
            var tempColumns = [];
            $.each(this.gridOptions.columnDefs, function(i, val){
                if(val.field != "#Sl"){
                    tempColumns.push(val.field);
                }
            });
            var params = {
                skipHeader: false,
                skipFooters: false,
                skipGroups: false,
                skipFloatingTop: false,
                skipFloatingBottom: false,
                allColumns: true,
                onlySelected: false,
                suppressQuotes: false,
                fileName: this.caption + ".csv",
                columnSeparator: '|',
                columnKeys : tempColumns
            };
            
            if(this.enableExpotCustomCellRenderer){
                params.processCellCallback =   this.exportCustomCellRenderer;
            }
                    
         
            this.gridOptions.api.exportDataAsCsv(params);
        },
        getDataAsCsv: function () {
            if (!this.enableExportToCSV) {
                console.error('spreadsheet: Export to CSV is not enabled.');
                return;
            }
            var params = {
                skipHeader: false,
                skipFooters: false,
                skipGroups: false,
                skipFloatingTop: false,
                skipFloatingBottom: false,
                allColumns: true,
                onlySelected: false,
                suppressQuotes: false,
                fileName: this.caption + ".csv",
                columnSeparator: ','
            };
	
            if(this.enableExpotCustomCellRenderer){
                params.processCellCallback =   this.exportCustomCellRenderer;
            }             

            return this.gridOptions.api.getDataAsCsv(params);
        },
        /*Goto Col*/
        jumpToCol: function (value) {
            if (!this.enableJumpToColumn) {
                console.error('spreadsheet: Jump to column is not enabled.');
                return;
            }
            var colLength = $.map(this.inpData[0], function (n, i) {
                return i;
            }).length;
            if (colLength > value) {
                var index = Number(value);
                if (typeof index !== 'number' || isNaN(index) || value === '') {
                    return;
                }
                // it's actually a column the api needs, so look the column up
                var allColumns = this.gridOptions.columnApi.getAllColumns();
                var column = allColumns[index];
                if (column) {
                    this.gridOptions.api.ensureColumnVisible(column);
                }
                var rowIndex = 1;
                if (this.enableJumpToRow) {
                    rowIndex = this.getJumpToRowIndex();
                }
                this.gridOptions.api.setFocusedCell(rowIndex - 1, column.colDef.field);
                this.setJumpToColumnIndex(index);
            } else {
                BootstrapDialog.alert({
                    message: "Column Does not Exist.",
                    size: 'small',
                    title: "Warning"
                });
            }
        },
        getJumpToColumnIndex: function () {
            if (!this.enableJumpToColumn) {
                console.error('spreadsheet: Jump to column is not enabled.');
                return;
            }
            var colIndex = $("#" + this.pluginId).find("input#jumpToColumn").val();
            if (colIndex === "") {
                colIndex = 1;
            }
            colIndex = Number(colIndex);
            if (typeof colIndex !== 'number' || isNaN(colIndex)) {
                console.error('spreadsheet: Jump to column must be numeric value.');
                return 1;
            }
            return colIndex;
        },
        setJumpToColumnIndex: function (index) {
            if (!this.enableJumpToColumn) {
                console.error('spreadsheet: Jump to column is not enabled.');
                return;
            }
            $("#" + this.pluginId).find("input#jumpToColumn").val(index);
        },
        /*Goto Row*/
        jumpToRow: function (value) {
            if (!this.enableJumpToRow) {
                console.error('spreadsheet: Jump to row is not enabled.');
                return;
            }
            if (this.inpData.length >= value) {
                var index = Number(value);
                if (typeof index === 'number' && !isNaN(index)) {
                    this.gridOptions.api.ensureIndexVisible(index - 1);
                }
                var colIndex = 1;
                if (this.enableJumpToColumn) {
                    colIndex = this.getJumpToColumnIndex();
                }
                this.gridOptions.api.setFocusedCell(index - 1, this.gridOptions.columnDefs[colIndex].field);
                this.setJumpToRowIndex(value);
            } else {
                BootstrapDialog.alert({
                    message: "Row Does not Exist.",
                    size: 'small',
                    title: "Warning"
                });
            }
        },
        getJumpToRowIndex: function () {
            if (!this.enableJumpToRow) {
                console.error('spreadsheet: Jump to row is not enabled.');
                return;
            }
            var rowIndex = $("#" + this.pluginId).find("input#jumpToRow").val();
            if (rowIndex === "") {
                rowIndex = 1;
            }
            rowIndex = Number(rowIndex);
            if (typeof rowIndex !== 'number' || isNaN(rowIndex)) {
                console.error('spreadsheet: Jump to row must be numeric value.');
                return 1;
            }
            return rowIndex;
        },
        setJumpToRowIndex: function (index) {
            if (!this.enableJumpToRow) {
                console.error('spreadsheet: Jump to row is not enabled.');
                return;
            }
            $("#" + this.pluginId).find("input#jumpToRow").val(index);
        },
        /*Delete Row*/
        deleteNodes: function (nodes) {
            //delete all selected nodes
            this.gridOptions.api.removeItems(nodes);
        },
        /*Insert Row at Index*/
        insertItemsAtIndex: function (index, data) {
            this.gridOptions.api.insertItemsAtIndex(index, [data]);
        },
        /*Add Filter*/
        addFilter: function (colID) {
            //Raised immediately after row was clicked.
            if (typeof this.onFilterAdd === "function") {
                this.onFilterAdd(colID.colId);
            }
        },
        /*Refresh the Grid*/
        refresh: function () {

        },
        getState: function () {
            var colDef = this.gridOptions.columnDefs.map(function (item) {
                delete item.headerCellTemplate;
                item.isHeaderMenu = true;
                return item;
            });
            colDef = colDef.filter(function (obj) {
                return obj.field !== '#Sl';
            });
            return {
                caption: this.caption,
                frozenColumns: this.frozenColumns,
                hiddenColumns: this.hiddenColumns,
                sortedColumns: this.sortedColumns,
                reorderedColumns: this.reorderedColumns,
                rowFormat: this.rowFormat,
                colFormat: this.colFormat,
                cellFormat: this.cellFormat,
                defaultRowHeight: this.defaultRowHeight,
                uniqueFieldName: this.uniqueFieldName,
                customStateData: this.customStateData,
                columnDefs: colDef,
                rowNewHeight: this.rowNewHeight,
                colorByRule: this.colorByRule,
                selectedRule: this.selectedRule,
                //selectedCell : this.selectedCell,
                //selectedColumns : this.selectedColumns,
                //selectedRows : this.selectedRows,

                floatingTopRowData: this.floatingTopRowData,
                floatingBottomRowData: this.floatingBottomRowData,
                //row reordered
            };
        },
        setState: function () { },
        applyState: function () {
            //this.fontOptions();
            createTemplates.enableSortingIcons(false);
            if (this.sortedColumns == undefined || this.sortedColumns.length === 0) {
                common.hideBySelector(".unsortall");
            } else {
                common.showBySelector(".unsortall");
                this.sortColumn();
            }
            this.enableDisableIcons();
            if (this.hiddenColumns.length !== 0) {
                this.hideColumn();
            }
            if (this.frozenColumns.length === 0) {
                common.hideBySelector(".unpin");
                common.hideBySelector(".unpinall");
            } else {
                common.showBySelector(".unpin");
                common.showBySelector(".unpinall");
                this.freezeColumn();
            }

            if (this.frozenRows.length === 0) {
                common.hideBySelector("#" + this.pluginId + " #row-context-menu #unFreezeRow");
                common.showBySelector("#" + this.pluginId + " #row-context-menu #freezerow");
            } else {
                common.showBySelector("#" + this.pluginId + " #row-context-menu #unFreezeRow");
                common.hideBySelector("#" + this.pluginId + " #row-context-menu #freezerow");
                this.formatRow();
            }
        },
        getSortedData: function () {
            var sorteddata = [];
            this.gridOptions.api.forEachNodeAfterFilterAndSort(function (rowNode) {
                sorteddata.push(rowNode.data);
            });
            return sorteddata;
        },


        /*Color by Value*/
        getCtrlValue: function (controlName) {
            var dataFieldSelected = $("#" + this.pluginId).find(controlName).val();
            return dataFieldSelected;
        },
        getCurrentRule: function () {
            var rowModel = this.colorByValueGridOptions.api.getModel(),
                rules = [];
            $.each(rowModel.rowsToDisplay, function (index, value) {
                rules.push(value.data);
            });
            return rules;
        },
        loadColorByValuePopup: function () {
            this.setColorByRule();
            if (this.selectedRule === "") {
                this.selectedRule = this.getDataField();
            }
            $("#" + this.pluginId).find("select#ddl_operators").trigger('change');
            $("#" + this.pluginId).find("select#ddl_colorSchemeType").trigger('change');
            $("#" + this.pluginId).find("input#usingDataField").trigger('change');
        },
        bindDataField: function () {
            var defaultSelection = this.selectedRule;
            common.bindDropDown(this.pluginId, "select#ddl_colorByDataValueFields", this.dataFields, defaultSelection);
        },
        onDataFieldChange: function () {
            this.selectedRule = this.getDataField();
            this.bindColorByValueByDataField();
        },
        onUsingDataField: function (params) {
            if (params) {
                $("#" + this.pluginId).find("select#ddl_valueInDataField").removeClass('btn-is-disabled');
            } else {
                $("#" + this.pluginId).find("select#ddl_valueInDataField").addClass('btn-is-disabled');
            }
        },
        bindValueDataField: function () {
            common.bindDropDown(this.pluginId, "select#ddl_valueInDataField", this.dataFields);
        },
        onValueDataFieldChange: function () {
            alert('onValueDataFieldChange');
        },
        bindSavedSchemes: function () {
            common.bindDropDown(this.pluginId, "select#saveSchemes", this.dataFields);
        },
        onSavedSchemesChange: function () {
            alert('onSavedSchemesChange');
        },
        bindColorSchemeType: function () {
            common.bindDropDown(this.pluginId, "select#ddl_colorSchemeType", this.dataFields);
        },
        onColorSchemaTypeChange: function (input) {
            var value = input;
            if (value == "MintoMax") {
                $("#" + this.pluginId).find(".byRulesPattern").not(".gradientPatten").hide();
                $("#" + this.pluginId).find(".gradientPatten").show();
            } else if (value == "byRules") {
                $("#" + this.pluginId).find(".gradientPatten").not(".byRulesPattern").hide();
                $("#" + this.pluginId).find(".byRulesPattern").show();
                this.bindColorByValueByDataField();
            }
        },
        bindDataUnit: function () { },
        onDataUnitChange: function () {
            alert('onDataUnitChange');
        },
        bindColorByValueOperators: function () {
            common.bindDropDown(this.pluginId, "select#ddl_operators", this.colorByValueOperators);
        },
        onColorByValueOperatorsChange: function (input) {
            var selectedVal = input,
                pluginID = this.pluginId;
            if (selectedVal == '==' || selectedVal == '!=') {
                $('#' + pluginID).find('.colorSchemeRules').find('.stringTextArea').css({
                    'display': 'block'
                });
                $('#' + pluginID).find('.colorSchemeRules').find('.stringText,.stringTextBetween').css({
                    'display': 'none'
                });
            } else if (selectedVal == '>' || selectedVal == '>=' || selectedVal == '<' || selectedVal == '<=' || selectedVal == 'Contains' || selectedVal == 'Does not Contain' || selectedVal == 'Start With' || selectedVal == 'Does not Start With' || selectedVal == 'End With' || selectedVal == 'Does not End With') {
                $('#' + pluginID).find('.colorSchemeRules').find('.stringTextArea,.stringTextBetween').css({
                    'display': 'none'
                });
                $('#' + pluginID).find('.colorSchemeRules').find('.stringText').css({
                    'display': 'block'
                });
            } else if (selectedVal == 'Between(Inclusive)' || selectedVal == 'Not Between') {
                $('#' + pluginID).find('.colorSchemeRules').find('.stringTextArea,.stringText').css({
                    'display': 'none'
                });
                $('#' + pluginID).find('.colorSchemeRules').find('.stringTextBetween').css({
                    'display': 'block'
                });
            } else if (selectedVal == 'Exists' || selectedVal == 'Does Not Exist') {
                $('#' + pluginID).find('.colorSchemeRules').find('.stringTextArea,.stringText,.stringTextBetween').css({
                    'display': 'none'
                });
            }
        },
        onAddNewColorByValueRule: function () {
            $("#" + this.pluginId).find(".colorSchemeRules").show();
        },
        addNewColorByValueRule: function () {
            var ruleId = this.colorByValueGridOptions.api.getModel().rowsToDisplay.length + 1,
                ruleColor = $("#byRulesColorpicker" + this.pluginId).spectrum("get").toHexString(),
                rule = "",
                operator = this.getOperators(),
                count = 0,
                value = [],
                fieldName;

            if (operator == '==' || operator == '!=') {
                value = this.getCtrlValue("#textareabox").split("\n");
                rule = operator + " " + value;
            } else if (operator == '>' || operator == '>=' || operator == '<' || operator == '<=' || operator == 'Contains' || operator == 'Does not Contain' || operator == 'Start With' || operator == 'Does not Start With' || operator == 'End With' || operator == 'Does not End With') {
                value.push(this.getCtrlValue("#textOperand"));
                rule = operator + " " + value;
            } else if (operator == 'Between(Inclusive)' || operator == 'Not Between') {
                value.push(this.getCtrlValue("#textboxbetween1"));
                value.push(this.getCtrlValue("#textboxbetween2"));
                rule = operator + " " + value[0] + " and " + value[1];
            } else if (operator == 'Exists' || operator == 'Does Not Exist') {

            }
            fieldName = this.selectedRule;
            count = this.getValueCountByField(fieldName, operator, value);

            var dataForRow = {
                color: ruleColor,
                count: count,
                rule: rule,
                ruleID: ruleId,
                operator: operator,
                value: value
            };

            this.colorByValueGridOptions.api.addItems([dataForRow]);
            this.cancelNewColorByValueRule();
            var rules = this.getCurrentRule();
            rules.filter(function (obj) {
                if (obj.rule == 'Undefined') {
                    obj.count -= count;
                    if (obj.count < 0) {
                        obj.count = 0;
                    }
                }
            });
            this.colorByValueGridOptions.api.refreshView();
            this.setRowDataColorPicker(rules);
        },
        getValueCountByField: function (fieldName, operator, value) {
            var count = 0;
            this.inpData.filter(function (obj) {
                var condition = "";
                if (operator == '==' || operator == '!=') {
                    condition += "('" + obj[fieldName] + "' " + operator + " '";
                    condition += value.join("' || '" + obj[fieldName] + "' " + operator + " '");
                    condition += "')";
                } else if (operator == '>' || operator == '>=' || operator == '<' || operator == '<=') {
                    condition = "" + obj[fieldName] + " " + operator + " " + value[0];
                } else if (operator == 'Contains') {
                    //contains
                    condition += "('" + obj[fieldName] + "'.match(/" + $.trim(value[0]) + "/g))";
                } else if (operator == 'Does not Contain') {
                    //not_contains
                    condition += "(!'" + obj[fieldName] + "'.match(/" + $.trim(value[0]) + "/g))";
                } else if (operator == 'Start With') {
                    //starts_with
                    condition += "('" + obj[fieldName] + "'.match(/^" + $.trim(value[0]) + "/g))";
                } else if (operator == 'Does not Start With') {
                    //not_starts_with
                    condition += "(!'" + obj[fieldName] + "'.match(/^" + $.trim(value[0]) + "/g))";
                } else if (operator == 'End With') {
                    //ends_with
                    condition += "('" + obj[fieldName] + "'.match(/" + $.trim(value[0]) + "$/g))";
                } else if (operator == 'Does not End With') {
                    //not_ends_with
                    condition += "(!'" + obj[fieldName] + "'.match(/" + $.trim(value[0]) + "$/g))";
                } else if (operator == 'Between(Inclusive)') {
                    condition += "('" + obj[fieldName] + "' >= " + $.trim(value[0]);
                    condition += " && '" + obj[fieldName] + "'  <=" + $.trim(value[1]) + ")";
                } else if (operator == 'Not Between') {
                    condition += "('" + obj[fieldName] + "' < " + $.trim(value[0]);
                    condition += " || '" + obj[fieldName] + "' > " + $.trim(value[1]) + ")";
                } else if (operator == 'Exists' || operator == 'Does Not Exist') {

                }
                if (eval(condition)) {
                    count++;
                }
            });
            return count;
        },
        setRowDataColorPicker: function (data) {
            for (var rowId = 0; rowId < data.length; rowId++) {
                formatting.gridColorPickerById(this.pluginId, data[rowId].ruleID);
                $('#' + this.pluginId).find("#ColorGridColorpicker_" + data[rowId].ruleID).spectrum("set", data[rowId].color);
            }
        },
        cancelNewColorByValueRule: function () {
            $("#" + this.pluginId).find("#ddl_operators").val("==");
            $("#" + this.pluginId).find("#textareabox").val("");
            $("#" + this.pluginId).find("#textboxbetween1").val("");
            $("#" + this.pluginId).find("#textboxbetween2").val("");
            $("#" + this.pluginId).find("#textOperand").val("");
            $('#' + this.pluginId).find("#byRulesColorpicker" + this.pluginId).spectrum("set", "#fff");
            $("#" + this.pluginId).find(".colorSchemeRules").hide();
        },
        removeNewColorByValueRule: function () {
            var selectedRow = this.colorByValueGridOptions.api.getSelectedRows(),
                selectedRowLength = selectedRow.length,
                rules = this.getCurrentRule();
            if (selectedRow[0].rule != 'Undefined') {
                if (selectedRowLength <= 0) {
                    alert('Please select rule to delete.');
                    return;
                }

                rules.filter(function (obj) {
                    if (obj.rule == 'Undefined') {
                        obj.count += selectedRow[0].count;
                    }
                });

                var selectedNodes = this.colorByValueGridOptions.api.getSelectedNodes();
                this.colorByValueGridOptions.api.removeItems(selectedNodes);
                this.colorByValueGridOptions.api.refreshView();
                this.setRowDataColorPicker(rules);
            }
        },
        initColorByValueGrid: function () {
            var colorByValueDiv = document.querySelector('#grid_colorByValue');
            new agGrid.Grid(colorByValueDiv, this.colorByValueGridOptions);
        },
        setColorByRule: function () {
            var dataFields = this.dataFields,
                pluginID = this.pluginId,
                colorByRule = {};
            colorByRule = this.colorByRule;
            if (jQuery.isEmptyObject(colorByRule)) {
                var count = this.gridOptions.api.rowModel.rowsToDisplay.length;
                $.each(dataFields, function (i, column) {
                    var dataForRow = [{
                        color: '#fff',
                        count: count,
                        rule: 'Undefined',
                        ruleID: "Rule1_" + pluginID,
                        operator: 'Undefined',
                        values: ''

                    }];
                    colorByRule[column.value] = dataForRow;
                });
                this.colorByRule = colorByRule;

            } else {
                //Disable all the Controls other than Data Field(s) to color:
            }
            //this.colorByRule
        },
        setGridOption: function () {
            this.colorByValueGridOptions = {
                columnDefs: [
                    {
                        headerName: 'Rule ID',
                        field: 'ruleID',
                        hide: true
                    },
                    {
                        headerName: 'Color',
                        field: 'color',
                        cellRenderer: this.colorByValueCellRendering,
                        cellStyle: {
                            'text-align': 'center'
                        }
                    },
                    {
                        headerName: 'Count',
                        field: 'count',
                        cellStyle: {
                            'text-align': 'right'
                        }
                    },
                    {
                        headerName: 'Rule',
                        field: 'rule'
                    },
                    {
                        headerName: 'Operator',
                        field: 'operator',
                        hide: true
                    },
                    {
                        headerName: 'Value',
                        field: 'value',
                        hide: true
                    },
                ],
                rowSelection: 'single',
                onRowSelected: function (event) {
                    if (event.node.selected) {
                        $("#colorByValPopUp").find("button#btn_removeRules").removeClass('btn-is-disabled');
                    } else {
                        $("#colorByValPopUp").find("button#btn_removeRules").addClass('btn-is-disabled');
                    }
                },
            };
        },
        colorByValueCellRendering: function (params) {
            var colorGridDiv = document.createElement('div');
            colorGridDiv.setAttribute("id", 'colorGridDivID');
            colorGridDiv.innerHTML = "<input id='ColorGridColorpicker_" + params.data.ruleID + "'/>";
            return colorGridDiv;
        },
        getColorByRule: function (dataField) {
            var selectedRule = [];
            if (dataField !== "" && dataField != "undefined") {
                //Get the selected Field Rules
                /* $.each(this.colorByRule, function (index, value) {
                     if (index == dataField) {
                         selectedRule = value;
                     }
                 });*/
                if (this.colorByRule[dataField] != undefined) {
                    selectedRule = this.colorByRule[dataField];
                }

            } else {
                selectedRule = this.colorByRule[dataField];
            }
            return selectedRule;
        },
        bindColorByValueByDataField: function () {
            //getting the Selected Data field
            var dataFieldSelected = this.selectedRule;
            //Get the selected Field Rules
            var addItems = this.getColorByRule(dataFieldSelected);
            //Assiging the selected fields rules to the Grid            
            this.colorByValueGridOptions.api.setRowData(addItems);
            var rules = this.getCurrentRule();
            this.setRowDataColorPicker(rules);
        },
        saveSchema: function () {
            alert('saveSchema');
        },
        saveSchemaAs: function () {
            alert('saveSchemaAs');
        },
        cancelColorByValue: function () {
            this.cancelNewColorByValueRule();
        },
        applyColorByValue: function () {
            var dataFieldSelected = this.selectedRule,
                rules = this.getCurrentRule();
            this.colorByRule[dataFieldSelected] = rules;
            this.formatCell();
        },
        applyAndCloseColorByValue: function () {
            var dataFieldSelected = this.selectedRule,
                rules = this.getCurrentRule();

            this.colorByRule[dataFieldSelected] = rules;
            this.cancelNewColorByValueRule();
            this.formatCell();
        },
        setgradientMinColor: function (color) {
            this.gradientMinHexVal = color;
        },
        getgradientMinColor: function () {
            return this.gradientMinHexVal;
        },
        setgradientMaxColor: function (color) {
            this.gradientMaxHexVal = color;
        },
        getgradientMaxColor: function () {
            return this.gradientMaxHexVal;
        },
        setgradientMidColor: function (color) {
            this.gradientMidHexVal = color;
        },
        getgradientMidColor: function () {
            return this.gradientMidHexVal;
        },
        getDataField: function () {
            //getting the Selected Data field
            var dataFieldSelected = this.getCtrlValue("select#ddl_colorByDataValueFields option:selected");
            return dataFieldSelected;
        },
        getOperators: function () {
            //getting the Selected Data field
            var dataFieldSelected = this.getCtrlValue("select#ddl_operators option:selected");
            return dataFieldSelected;
        },
        setGridColorByRule: function (setColorWithRule) {
            var rules = this.getCurrentRule();

            rules.filter(function (obj) {
                if (obj.ruleID == setColorWithRule.ruleID) {
                    obj.color = setColorWithRule.pointsColor;
                    return obj;
                }
            });
            this.gridOptions.api.refreshView();
            this.setRowDataColorPicker(rules);
        },
        getFocusedCell: function () {
            return this.gridOptions.api.getFocusedCell();
        },
        getRowDataByIndex : function(rowIndex){
            var model = this.gridOptions.api.getModel();
            var data = model.getRow(rowIndex);
            return data.data;
        }
    };
    // Create the plugin name and defaults once
    var pluginName = 'spreadsheetWidget';

    // add the plugin to the jQuery.fn object
    $.fn[pluginName] = function () {
        var option = arguments[0],
            args = arguments,
            value,
            allowedMethods = [
                "setData",
                "setRowData",
                "renameViewer",
                "onFocusoutViewerName",
                "sizeToFit",
                "autoSizeAllColumns",
                "sortColumn",
                "getSortModel",
                "unsortAllColumn",
                "format",
                "bold",
                "italic",
                "underline",
                "fontColor",
                "backgroundColor",
                "fontType",
                "fontSize",
                "fontOptions",
                "getCellFormat",
                "getColFormat",
                "getRowFormat",
                "jumpToRow",
                "jumpToCol",
                "toggleRowHeight",
                "exportDatatoCSV",
                "getDataAsCsv",
                "getSelectedColumn",
                "getSelectedCell",
                "selectColumns",
                "deSelectAllColumn",
                "selectAllColumn",
                "selectRow",
                "selectAllRows",
                "spreadsheetRowSelected",
                "selectCell",
                "deSelectAllCell",
                "closeWidget",
                "addFilter",
                "freezeColumn",
                "unFreezeColumn",
                "unFreezeAllColumn",
                "freezeRow",
                "unFreezeRow",
                "hideColumn",
                "unhideColumn",
                "unhideAll",
                "colReorder",
                "rowReorder",
                "colResize",
                "rowResizes",
                "rowStopDrag",
                "getSpreadsheetParam",
                "getSelectedRowData",
                "getCustomState",
                "setCustomState",
                "deSelectAllRows",
                "setRowSelected",
                "getState",
                "headerDropdownMenu",
                "onRowResizing",
                "spreadsheetColumnSorting",
                "getFrozenRowsCount",
                "getSortedData",
                "enableSortIcons",
                /*Color By Value Functions*/
                "getgradientMinColor",
                "getgradientMaxColor",
                "getgradientMidColor",
                "getColorByRule",
                "getDataField",
                "setgradientMinColor",
                "setgradientMaxColor",
                "setgradientMidColor",
                "onColorSchemaTypeChange",
                "onColorByValueOperatorsChange",
                "cancelNewColorByValueRule",
                "onAddNewColorByValueRule",
                "removeNewColorByValueRule",
                "onDataFieldChange",
                "onUsingDataField",
                "onValueDataFieldChange",
                "onSavedSchemesChange",
                "onDataUnitChange",
                "saveSchema",
                "saveSchemaAs",
                "cancelColorByValue",
                "applyColorByValue",
                "applyAndCloseColorByValue",
                "addNewColorByValueRule",
                "loadColorByValuePopup",
                "setGridColorByRule",
                /*Added new function*/
                "setCellFocus",
                "selectRowByIndex",
                "getSelectedRowNodes",
                "getCurrentRowIndex",
                "getTotalRecordsCount",
                "setNoRecords",
                "spreadsheetCellDoubleClicked",
                "ResetColumnDefinition",
                "getFocusedCell",
                "getRowDataByIndex"
            ];

        this.each(function () {
            var $this = $(this),
                data = $this.data("spreadsheetWidget"),
                options = $.extend({}, $.fn.spreadsheetWidget.defaults, $this.data(), typeof option === "object" && option);

            if (typeof option === "string") {
                //Check the method available to access outside
                if ($.inArray(option, allowedMethods) < 0) {
                    throw "Method " + option + " does not exist on spreadsheetWidget";
                }
                //call the allowed methods
                if (typeof args[1] !== "undefined") {
                    value = data[option](args[1]);
                } else {
                    value = data[option]();
                }
            } else {
                data = new SpreadsheetWidgetApi($this, options);
                $this.data("spreadsheetWidget", data);
                data.init(this.id);
            }
        });
        return value === "undefined" ? this : value;
    };
    $.fn[pluginName].defaults = {
        /*Action Bar Properties*/
        caption: "Spreadsheet Widget",
        enableActionBar: false, //one of [true, false]
        enableRename: false,
        enableCloseButton: false,
        enableColumnMoveable: false,
        enableFormatting: false,
        enableExportToCSV: false,
        enableJumpToRow: false,
        enableJumpToColumn: false,
        enableRowResize: false,
        uniqueFieldName: "#Sl",
        onFirstLoad: true,
        fontSizes: [
            {
                value: 8,
                text: 8
            },
            {
                value: 9,
                text: 9
            },
            {
                value: 10,
                text: 10
            },
            {
                value: 11,
                text: 11
            },
            {
                value: 12,
                text: 12
            },
            {
                value: 14,
                text: 14
            },
            {
                value: 16,
                text: 16
            },
            {
                value: 18,
                text: 18
            },
            {
                value: 20,
                text: 20
            },
            {
                value: 22,
                text: 22
            },
            {
                value: 24,
                text: 24
            },
            {
                value: 26,
                text: 26
            },
            {
                value: 28,
                text: 28
            }
        ],
        fontTypes: [
            {
                value: 'Arial',
                text: 'Arial'
            },
            {
                value: 'Arimo',
                text: 'Arimo'
            },
            {
                value: 'Calibri',
                text: 'Calibri'
            }, {
                value: 'Cambria',
                text: 'Cambria'
            }, {
                value: 'Comic Sans MS',
                text: 'Comic Sans MS'
            }, {
                value: 'Constantia',
                text: 'Constantia'
            }, {
                value: 'Corbel',
                text: 'Corbel'
            }, {
                value: 'Courier New',
                text: 'Courier New'
            }, {
                value: 'DejaVu Sans Mono',
                text: 'DejaVu Sans Mono'
            }, {
                value: 'Ebrima',
                text: 'Ebrima'
            }, {
                value: 'Ebrima Bold',
                text: 'Ebrima Bold'
            }, {
                value: 'Georgia',
                text: 'Georgia'
            }, {
                value: 'Impact',
                text: 'Impact'
            }, {
                value: 'Lucida Console',
                text: 'Lucida Console'
            }, {
                value: 'Times New Roman',
                text: 'Times New Roman'
            }, {
                value: 'Verdana',
                text: 'Verdana'
            }
        ],

        /*grid properties*/
        enableFilter: false, //one of [true, false]
        enableColumnfloatingFilter: false, //one of [true, false]
        enableColFreezing: false, //one of [true, false]
        enableColSorting: false, //one of [true, false]
        enableColHide: false, //one of [true, false]
        enableColResize: false, //one of [true, false]
        suppressDragLeaveHidesColumns: false, //one of [true, false]
        enableRowFreezing: false, //one of [true, false]        
        enableRowMoveable: false, //one of [true, false]  
        frozenColumns: [],
        hiddenColumns: [],
        sortedColumns: [],
        reorderedColumns: [],
        frozenRows: [],
        customStateData: [],
        enablePagination: false,
        paginationPageSize: 10,
        /*Cell*/
        selectedCell: {
            lastSelected: "",
            currentSelected: "",
            selected: []
        },
        cellFormat: [],

        /*Column Properties*/
        columnDefs: [],
        selectedColumns: {
            lastSelected: "",
            currentSelected: "",
            selected: []
        },
        colFormat: [],

        /*Row Properties*/
        rowData: null,
        rowSelection: "multiple", // one of ['single','multiple'], leave blank for no selection
        defaultRowHeight: 25,
        toggleRowHeightMin: 25,
        toggleRowHeightMax: 40,
        rowNewHeight: [],
        rowFormat: [],
        suppressRowClickSelection: true,
        rowModelType: '', // virtual, pagination
        // no rows to float to start with
        floatingTopRowData: [],
        floatingBottomRowData: [],
        selectedRows: {
            lastSelected: "",
            currentSelected: "",
            selected: []
        },
        rowContextMenu: [
            {
                id: 1,
                name: 'Move Selected',
                callback: "",
                submenu: [
                    {
                        id: "selTop",
                        name: 'To the Top',
                        callback: "rowReorder",
                        param: {
                            position: "Top"
                        },
                        class: ""
                    },
                    {
                        id: "selUp",
                        name: 'Up',
                        callback: "rowReorder",
                        param: {
                            position: "Up"
                        },
                        class: ""
                    },
                    {
                        id: "selDown",
                        name: 'Down',
                        callback: "rowReorder",
                        param: {
                            position: "Down"
                        },
                        class: ""
                    },
                    {
                        id: "selBottom",
                        name: 'To the Bottom',
                        callback: "rowReorder",
                        param: {
                            position: "Bottom"
                        },
                        class: ""
                    }
                ],
                class: "",
                groupName: "rowReordering"
            },
            {
                id: "freezerow",
                name: 'Freeze Row',
                callback: "freezeRow",
                submenu: [],
                param: {},
                class: "freezerow",
                groupName: "rowfreeze"
            },
            {
                id: "unFreezeRow",
                name: 'UnFreeze Row',
                callback: "unFreezeRow",
                submenu: [],
                param: {},
                class: "unFreezeRow",
                groupName: "rowfreeze"
            }
        ],

        /*callback functions*/
        onFilterAdd: function() {},
        onWidgetClose: function() {},
        rowResize: {
            isResize: false,
        },

        /*Color By Value Properties*/
        selectedRule: "",
        enableColorByValue: false, //one of [true, false]
        dataFields: [],
        colorByRule: {},
        gradientMinHexVal: '#000000',
        gradientMidHexVal: '#00ff00',
        gradientMaxHexVal: '#a61c00',
        colorByValueGridOptions: {},
        colorByValueOperators: [
            {
                value: '==',
                text: '='
            },
            {
                value: '!=',
                text: 'Not ='
            },
            {
                value: '>',
                text: '>'
            },
            {
                value: '>=',
                text: '>='
            },
            {
                value: '<',
                text: '<'
            },
            {
                value: '<=',
                text: '<='
            },
            {
                value: 'Between(Inclusive)',
                text: 'Between(Inclusive)'
            },
            {
                value: 'Not Between',
                text: 'Not Between'
            },
            /*{
                value: 'Exists',
                text: 'Exists'
            },
            {
                value: 'Does Not Exist',
                text: 'Does Not Exist'
            },*/
            //Has Modifier
            //Does not has modifier
            {
                value: 'Contains',
                text: 'Contains'
            },
            {
                value: 'Does not Contain',
                text: 'Does not Contain'
            },
            {
                value: 'Start With',
                text: 'Start With'
            },
            {
                value: 'Does not Start With',
                text: 'Does not Start With'
            },
            {
                value: 'End With',
                text: 'End With'
            },
            {
                value: 'Does not End With',
                text: 'Does not End With'
            }
        ],
        suppressCellSelection: false,
        enableCellSelection: true,
        enableRowSelectionOnCellClick: false,
        rowDoubleClicked: function() {},

        enableCellDoubleClicked: false,
        onSpreadsheetCellDoubleClicked: function() {},

        enableAutoSizeColumns: false,
        enableSizeColumnsToFit: false,
        defaultColWidth: 100,
        enableCustomNavigation: false,
        onNavigateToNextCell: function() {},
        onTabToNextCell: function() {},
        enableExpotCustomCellRenderer: false,
        exportCustomCellRenderer: null,
        enableRowIndexColumn: false
    };
})(jQuery);
