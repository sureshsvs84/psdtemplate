﻿var GetNotificationDetailsCallURL = "../TatvamNotification/GetTatvamNotificationDetails";

//function to get the notification details to display
function getNotificationDetails() {
    //ajax call to get the notification details
    TatvamAjaxCalls("GET", GetNotificationDetailsCallURL, null, loadPanelData, {});
}

//function to update selected message counter
function updatedSelectedCounter(curObj) {
    showEllipsis(curObj);
    $(curObj).parent().toggleClass("activeNotification");
    $(curObj).parent().parent().toggleClass("activeNotification");
    $(curObj).toggleClass('notificationSelected');
    $(curObj).find('input').attr('checked');
    if ($(curObj).find('input').attr('checked')) {
        $(curObj).find('input').removeAttr('checked');
    } else {
        $(curObj).find('input').attr('checked', 'checked');
    }
    updateNotificationCounter();
}

//
function updateNotificationCounter() {
    var counter = $('.notificationCards').find('.notificationSelected').length;
    $('.slectionCounter').text(counter);
    if (counter < 1) {
        $('.notificationBar').slideUp(1000);
    } else {
        $('.notificationBar').slideDown(1000);
    }
}

//function to activate notification
function selectedStatus(curObj) {
    $(curObj).parent().parent().toggleClass('notificationActive');
}

//function to show ellipsis on each panel right side
function showEllipsis(curObj) {
    $(curObj).find('.hiddenInvisible').css('visibility', 'visible');
    $(curObj).css('background-color', '#F2F7FD');
    $(curObj).find('.panel-heading').css('background-color', '#F2F7FD');
}
function hideEllipsis(curObj) {
    $(curObj).find('.hiddenInvisible').css('visibility', 'hidden');
    $(curObj).css('background-color', '#fff');
    $(curObj).find('.panel-heading').css('background-color', '#fff');
}

//Function to unselect all selected notifications
function clearSelection(event) {
    event.stopPropagation();
    $('.customCheckBox').find('input').removeAttr('checked');
    $('.notificationBar').slideUp();
    $('.selectAll').prop('checked', true);
    $('.notificationCards').find('.notificationSelected').removeClass('notificationSelected');
    $(".notificationCards").find('.activeNotification').removeClass('activeNotification');
}

function loadPanelData(data) {

    $(".notificationCards").empty();

    data = data.response;

    if (data.length <= 0) {
        $(".notificationCards").append("We didn't find anything to show here.");
    }

    var i, notificationPanelData = '';
    for (i = 0; i < (data.length) ; i++) {
        notificationPanelData += '<div class="panel panel-default" onmouseover="showEllipsis(this)" onmouseout="hideEllipsis(this)">';
        notificationPanelData += '<div class="panel-heading">';
        notificationPanelData += '<div class="checkbox customCheckBox" onclick="updatedSelectedCounter(this)">'; notificationPanelData += '<span class="control control--checkbox"><input type="checkbox" value=' + data[i].MessageID + '><div class="control__indicator"></div></span></div>';
        if (data[i].Status == 0) {
            notificationPanelData += '<span class="messageStatus unReadMeassage"><i class="fa fa-envelope" aria-hidden="true"></i></span><span class="unReadMeassage">';
        } else {

            notificationPanelData += '<span class="messageStatus readMeassage"><svg class="readMeassageSvg" viewBox="0 0 24 24"><path fill="#675D5C" d="M4,8L12,13L20,8V8L12,3L4,8V8M22,8V18A2,2 0 0,1 20,20H4A2,2 0 0,1 2,18V8C2,7.27 2.39,6.64 2.97,6.29L12,0.64L21.03,6.29C21.61,6.64 22,7.27 22,8Z" /></svg></span><span class="readMeassage">';


        }
        notificationPanelData += data[i].Title + '</span>';
        notificationPanelData += '<div class="dropdown pull-right customDropDown ">';
        notificationPanelData += '<a class="dropdown-toggle hiddenInvisible" data-toggle="dropdown"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></a>';
        notificationPanelData += '<ul class="dropdown-menu">';
        if (data[i].Status == 0) {
            notificationPanelData += '<li><a href="#" id="idMarkasRead" onclick="markCurrentRecordsAsReadorArchive(this,statusmarkasread);"  data-messageid=' + data[i].MessageID + '>';
            notificationPanelData += '<svg class="dropDownCheckedIcon" viewbox="0 0 24 24">'
            notificationPanelData += '<path fill="#107bb4" d="M0.41,13.41L6,19L7.41,17.58L1.83,12M22.24,5.58L11.66,16.17L7.5,12L6.07,13.41L11.66,19L23.66,7M18,7L16.59,5.58L10.24,11.93L11.66,13.34L18,7Z" />';
            notificationPanelData += '</svg>';
            notificationPanelData += 'Mark As Read</a></li>';
            notificationPanelData += '<li><a href="#" id="idMarkasArchive" onclick ="markCurrentRecordsAsReadorArchive(this,statusArchive);" data-messageid=' + data[i].MessageID + '><span  class="dropDownArchiveIcon"><img src="../Content/Images/archiveIconBlue.svg" alt="Archive" width="20px"></span>Archive</a></li>';
        } else if (data[i].Status == 1) {
            notificationPanelData += '<li><a href="#" id="idMarkasUnRead" onclick="markCurrentRecordsAsReadorArchive(this,statusmarkasunread);"  data-messageid=' + data[i].MessageID + '>';
            notificationPanelData += '<svg class="dropDownCheckedIcon" viewbox="0 0 24 24">'
            notificationPanelData += '<path fill="#107bb4" d="M0.41,13.41L6,19L7.41,17.58L1.83,12M22.24,5.58L11.66,16.17L7.5,12L6.07,13.41L11.66,19L23.66,7M18,7L16.59,5.58L10.24,11.93L11.66,13.34L18,7Z" />';
            notificationPanelData += '</svg>';
            notificationPanelData += 'Mark As UnRead</a></li>';
            notificationPanelData += '<li><a href="#" id="idMarkasArchive" onclick ="markCurrentRecordsAsReadorArchive(this,statusArchive);" data-messageid=' + data[i].MessageID + '><span  class="dropDownArchiveIcon"><img src="../Content/Images/archiveIconBlue.svg" alt="Archive" width="20px"></span>Archive</a></li>';
        } else if (data[i].Status == 2) {
            notificationPanelData += '<li><a href="#" id="idMarkasUnArchive" onclick ="markCurrentRecordsAsReadorArchive(this,statusmarkasunread);" data-messageid=' + data[i].MessageID + '><span  class="dropDownArchiveIcon"><img src="../Content/Images/archiveIconBlue.svg" alt="UnArchive" width="20px"></span>UnArchive</a></li>';
        }        
        notificationPanelData += '</ul>';
        notificationPanelData += '</div>';


        notificationPanelData += '<span class="pull-right fromDate badge customBadge">' + data[i].Received + '</span>';
        notificationPanelData += '<div class="recieveDate"><span class="userIcon">';
        notificationPanelData += '<svg enable-background="new 0 0 64 64" height="15px" viewBox="0 0 64 64" width="64px"><g id="Layer_1"><g><circle cx="32" cy="32" fill="#000" r="32"/></g><g opacity="0.2"><g><path d="M43.905,47.543c-3.821-1.66-5.217-4.242-5.643-6.469c2.752-2.215,4.943-5.756,6.148-9.573     c1.239-1.579,1.96-3.226,1.96-4.62c0-0.955-0.347-1.646-0.955-2.158c-0.203-8.106-5.942-14.613-13.039-14.714     C32.322,10.009,32.268,10,32.213,10c-0.022,0-0.043,0.004-0.065,0.004c-7.052,0.039-12.783,6.41-13.125,14.409     c-0.884,0.528-1.394,1.305-1.394,2.469c0,1.641,0.992,3.63,2.663,5.448c1.187,3.327,3.118,6.38,5.5,8.438     c-0.354,2.292-1.699,5.039-5.697,6.776c-2.159,0.938-6.105,1.781-7.808,2.649c4.362,4.769,12.624,7.769,19.589,7.805l0.099,0.003     C31.983,57.999,31.992,58,32,58c7.014,0,15.325-3.01,19.713-7.808C50.01,49.324,46.063,48.481,43.905,47.543z" fill="#231F20"/></g></g><g><g><path d="M43.905,45.543c-3.821-1.66-5.217-4.242-5.643-6.469c2.752-2.215,4.943-5.756,6.148-9.573     c1.239-1.579,1.96-3.226,1.96-4.62c0-0.955-0.347-1.646-0.955-2.158C45.213,14.618,39.474,8.11,32.378,8.01     C32.322,8.009,32.268,8,32.213,8c-0.022,0-0.043,0.004-0.065,0.004c-7.052,0.039-12.783,6.41-13.125,14.409     c-0.884,0.528-1.394,1.305-1.394,2.469c0,1.641,0.992,3.63,2.663,5.448c1.187,3.327,3.118,6.38,5.5,8.438     c-0.354,2.292-1.699,5.039-5.697,6.776c-2.159,0.938-6.105,1.781-7.808,2.649c4.362,4.769,12.624,7.769,19.589,7.805l0.099,0.003     C31.983,55.999,31.992,56,32,56c7.014,0,15.325-3.01,19.713-7.808C50.01,47.324,46.063,46.481,43.905,45.543z" fill="#FFFFFF"/></g></g></g><g id="Layer_2"/></svg>';
        notificationPanelData += '</span><span class="fromUserLable">' + data[i].FromUser + '</span></div>';
        notificationPanelData += '</div>';
        notificationPanelData += '<div class="panel-body">';
        notificationPanelData += '<div class="col-sm-12">';
        notificationPanelData += '</div>';
        notificationPanelData += '<div class="col-sm-12 panelDescription">';
        notificationPanelData += '<p class="notificationDescription more">' + data[i].Description + '</p>';

        notificationPanelData += '</div>';
        notificationPanelData += '</div>';
        notificationPanelData += '</div>';
    }
    $('.notificationCards').append(notificationPanelData);
    updateNotificationCounter();
    Messagecount();
}



$("a").on("click", function (e) {
    // Id of the element that was clicked
    elementId = $(this).attr("id");
});

/**
 *  Get all the selected notifications message id's
 */

function getAllSelectedMessageIds() {
    var checkedNotifications = $(".notificationCards input:checked");
    var selectedMessageIDs = $.map(checkedNotifications, function (obj, i) {
        return obj.value;
    });
    return selectedMessageIDs;
}


/**
 *  Mark all the currently selected notifications as read
 */

function markAllSelectedRecordsAsReadorArchive(messageStatus) {
    var selectedMessageIDs = getAllSelectedMessageIds();
    markAsReadorArchive(selectedMessageIDs, messageStatus);
}

/**
 *  Mark all the currently selected notifications as read
 */

function markCurrentRecordsAsReadorArchive(inpObj, messageStatus) {
    var selectedMessageIDs = [inpObj.dataset.messageid];
    var Id = inpObj.id;
    markAsReadorArchive(selectedMessageIDs, messageStatus, Id);
    Messagecount();
}

/**
 *  Will validate the is there any notifications is selected.
 *  update the notification as read in the database
 */

function markAsReadorArchive(messageIDs, messageStatus) {
    if (messageIDs.length <= 0) {
        bootbox.alert({
            size: "small",
            title: "Message",
            message: "No rows are selected.",
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            }
        })
        return false;
    }
    // call method to update the status as 'mark as read' or 'archive' for selected notifications
    UpdateNotification(messageIDs, messageStatus);
    // if any 'show read' or 'show archive' is not selected then display only unread notifications
    if (elementId == undefined) {
        getNotificationDetails();
    }
    else {
        // if any 'show read' is selected then display only unread+read notifications

        if (elementId === "idShowRead") {
            ListReadandUnReadNotificationMessages();
        }
        // if any 'show archive' is selected then display only unread+archive notifications
        if (elementId === "idShowArchive") {
            ListArchiveNotificationMessages();
        }
    }

}



/**/
var result = "";
var statusmarkasunread = 0;
var statusmarkasread = 1;
var statusArchive = 2;

var UpdateNotificationStatusCallURL = "../TatvamNotification/UpdateTatvamNotificationStatus";
var MessageReadCountCallURL = "../TatvamNotification/TatvamNotificationMessageReadCount";
var ListReadUnReadCallURL = "../TatvamNotification/ListReadandUnReadTatvamNotificationMessages";
var ListAllCallURL = "../TatvamNotification/ListAllTatvamNotificationMessages";
var UnReadCallURL = "../TatvamNotification/TatvamUnReadNotification";
var ArchivedCallURL = "../TatvamNotification/ListArchiveNotificationMessages";




function notificationmessageid() {
    var grid = $("#TatvamNotificationid");
    var rowKey = grid.getGridParam("selrow");

    if (!rowKey) {
        bootbox.alert({
            title: "Message",
            size:"small",
            message: "No rows are selected .",
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            },
            callback: function () {
                $(this).modal('hide');
            }
        })      
    } else {
        var selectedIDs = grid.getGridParam("selarrrow");
        UpdateNotification(selectedIDs, statusArchive);
    }
}

function BindNotificationToGrid(jsonData) {
    if (jsonData && jsonData.length === 0) {
        $(".nodata").empty();
        jQuery("#TatvamNotificationid").jqGrid("clearGridData");
        $("#TatvamNotificationid").append('<div  class=\'nodata\' style="width: 200px;">No Data Available.</div>');
        return false;
    }
    $(".nodata").empty();
    $("#TatvamNotificationid").jqGrid({
        datatype: 'local',
        data: jsonData,
        colNames: ['Id', 'CustomerCode', 'From', 'Title', 'Description', 'Received Date', 'Message Status'],
        colModel: [
            { name: "MessageID", hidden: true, key: true },
            { name: "CustomerID", hidden: true },
            { name: "FromUser", width: 250 },
            { name: "Title", index: 'title', align: 'left', width: 250 },
            { name: "Description", index: 'message_desc', width: 580, align: 'left' },
            { name: "Received", index: 'Received_Date', align: 'center', width: 110 },
            { name: "StatusName", index: 'StatusName', align: 'center', width: 100 }],
        height: '550',
        autowidth: true,
        rowNum: 20,
        loadonce: true,
        pager: '#TatvamNotificationidpager',
        //   sortname: 'MessageID',
        viewrecords: true,
        gridview: true,
        //    sortorder: 'desc',
        emptyrecords: 'No Records To Display',
        hoverrows: true,
        navOptions: { reloadGridOptions: { fromServer: true } },
        jsonreader: {
            repeatitems: false,
            Id: "0"
        },
        multiselect: true,
        loadComplete: function () {

            var width = $("#TatvamNotificationid").width();
            $(".ui-jqgrid-bdiv").css({ "width": width + 20 });
            $(".ui-jqgrid-hdiv").css({ "width": width });
            $(".ui-jqgrid-toppager").css({ "width": width });
            var height = $("#TatvamNotificationid").height();
            if (height > 150) {
                $(".ui-jqgrid-bdiv").css({ "height": height + 30 });

                $(".ui-jqgrid-toppager").css({ "height": height + 30 });
            }
        },
    }).navGrid('#TatvamNotificationidpager', { edit: false, add: false, del: false, search: false, refresh: false, });

    jQuery('#TatvamNotificationid').jqGrid('clearGridData');
    jQuery('#TatvamNotificationid').jqGrid('setGridParam', { data: jsonData });
    jQuery('#TatvamNotificationid').trigger('reloadGrid');

}

function UpdateNotification(messageId, messageStatus) {
    $.ajax({
        url: UpdateNotificationStatusCallURL,
        data: { Id: messageId, Messagestatus: messageStatus },
        type: "POST",
        success: function (Results) {
            var jsonData = TatvamObjectToJsonConvert(Results);
            Messagecount();
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}


function Messagecount() {
    $.ajax(
    {
        url: MessageReadCountCallURL,
        type: "Get",
        success: function (Result) {
            $("#spanid").text(Result);
            if (Result > 0) {                
                $("#spanid").attr("style", "visibility:visible");
            }
            else {
                $("#spanid").attr("style", "visibility:hidden");
            }
        }
    });
}

Messagecount();



function CountNotReadNotificationMessages() {
    $.ajax(
    {
        url: MessageReadCountCallURL,
        type: "Get",
        success: function (Result) {
            var jsonData = TatvamObjectToJsonConvert(Result);
            var count = jsonData.length;
            $("#OnCount").val(jsonData.length);
        }
    });
}

function archivecheckbox() {
    $.ajax(
    {
        url: ArchivedCallURL,
        type: "Get",
        success: function (Result) {
            var jsonData = TatvamObjectToJsonConvert(Result);
            BindNotificationToGrid(jsonData);
            for (var i = 0; i < Result.length; i++) {
                if (Result[i].Status == 2) {
                    var id = Result[i].MessageID
                    $('tr#' + id).css('background-color', '#D3D3D3');
                }
            }
            ($('#checkbox1').prop('checked', false));
        }
    });
}

function Readcheckbox() {
    $.ajax(
    {
        url: ListReadUnReadCallURL,
        type: "Get",
        success: function (Result) {
            var jsonData = TatvamObjectToJsonConvert(Result);
            BindNotificationToGrid(jsonData);
            for (var i = 0; i < Result.length; i++) {
                if (Result[i].Status == 1) {
                    var id = Result[i].MessageID
                    $('tr#' + id).css('background-color', '#D3D3D3');
                }
            }
        }
    });
}

function ReadAllNotificationMessages() {
    $.ajax(
    {
        url: ListAllCallURL,
        type: "Get",
        success: function (Result) {
            var jsonData = TatvamObjectToJsonConvert(Result);

            BindNotificationToGrid(jsonData);
            for (var i = 0; i < Result.length; i++) {
                if (Result[i].Status == 1) {
                    var id = Result[i].MessageID
                    $('tr#' + id).css('background-color', '#D3D3D3');
                }
                if (Result[i].Status == 2) {
                    var id = Result[i].MessageID
                    $('tr#' + id).css('background-color', '#D3D3D3');
                }
            }
        }
    });
}

function UnreadNotificationMessages() {
    $.ajax(
    {
        url: UnReadCallURL,
        type: "Get",
        success: function (Result) {
            var jsonData = TatvamObjectToJsonConvert(Result);
            BindNotificationToGrid(jsonData);
        }
    });
}


function ListReadandUnReadNotificationMessages() {
    TatvamAjaxCalls("GET", ListReadUnReadCallURL, null, loadPanelData, {});    
}

function ListArchiveNotificationMessages() {
    TatvamAjaxCalls("GET", ArchivedCallURL, null, loadPanelData, {});
}


function TatvamObjectToJsonConvert(searchResults) {
    var gidData = JSON.stringify(searchResults);
    var jsonData = jQuery.parseJSON(gidData);
    return jsonData;
}