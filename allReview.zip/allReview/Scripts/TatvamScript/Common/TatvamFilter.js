﻿
var FilterMainCallURL = "../Filter/TatvamFilter";


/*Add New Filter Control to the selected report*/
function AddTatvamFilter(control, reportid)
{

    if (typeof (control.id) === "undefined") {
        control = control;
    } else
        control = control.id;

    $.ajax({
        type: "POST",
        async: false,
        url: FilterMainCallURL,
        data: { ReportCategoryId: reportid },
        success: function(result) {
            $("#" + control).append(result);
            $($("#" + control)).parent().parent().parent().find("#hdn_reportid").val(Filtermodel[0].ReportCategoryId);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

/*Get Unique Id for Tatvam Filter*/
function uniqId() {
    return Math.round(new Date().getTime() + (Math.random() * 100));
}

$(".deleteicon").click(function() {
    if (this.parentElement.parentElement.getElementsByClassName("searchpanel").length > 1)
        $(this).parent().remove();
});


$(".addicon").unbind().click(function() {
    var reprotid = $(this).parent().parent().parent().find("#hdn_reportid").val();
    AddTatvamFilter($(this).parent().parent().attr("id"), reprotid);
});
