﻿var myColors = ['#3f51b5', '#03a9f4', '#ffca08', '#ff710f', '#a0a700', '#007bc3', '#a7008f', '#309b46', '#8ebc00', '#ff7663', '#10c4b2', '#ff4350', '#ff4350', '#99d101', '#008fd3', '#004586', '#006bff', '#c4f565', '#ff420e', '#ffd320', '#579d1c', '#7e0021', '#83caff', '#314004', '#aecf00', '#4b1f6f', '#ff950e', '#c5000b', '#0084d1'];

var shapes = ['circle', 'cross', 'triangle-up', 'triangle-down', 'diamond', 'square', 'hexagram', 'x', 'star-triangle-up', 'star-triangle-down', 'x-open', 'circle-open', 'triangle-up-open', 'triangle-down-open', 'diamond-open', 'square-open', 'hexagram-open', 'star-triangle-up-open', 'star-triangle-down-open'];


function TatvamAjaxCalls(method, url, data, callBack, params) {
    if (method === "POST") {
        data = JSON.stringify(data);
    } else if (method === "GET") {
        data = data;
    }

    $.ajax({
        type: method,
        url: url,
        data: data,
        contentType: "application/json",
        async: false,
        success: function (result) {
            if (typeof callBack === "function") {
                params.response = result;
                callBack(params);
            }
        },
        error: function (xhr, status, p3, p4) {
            if (xhr.status === 401) {
                TatvamAlert(xhr.statusText + " Access is denied due to invalid credentials.", "Error");
            } else {
                var error = JSON.parse(xhr.responseText)
                TatvamAlert(error.ErrorMessage, "Error");
            }
        }
    });
}

function TatvamAjaxCallWithReturn(method, url, data) {
    if (method === "POST") {
        data = JSON.stringify(data);
    } else if (method === "GET") {
        data = data;
    }

    return $.ajax({
        type: method,
        url: url,
        data: data,
        contentType: "application/json",
        async: false,
        success: function (result) {
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

function toDate(d) {
    return new Date(d);
}

function getBool(val) {
    return !!JSON.parse(String(val).toLowerCase());
}

function trimChar(string, charToRemove) {
    while (string.charAt(0) === charToRemove) {
        string = string.substring(1);
    }

    while (string.charAt(string.length - 1) === charToRemove) {
        string = string.substring(0, string.length - 1);
    }

    return string;
}

function GetYaxisMaxValue(value) {

    var dtick;
    var yMax;
    var max = value / 1000;

    if (max > 10) {
        yMax = Math.ceil(value / 1000) * 1000;
        dtick = 1000;
        max = value / 500;
        if (max <= 10 && max >= 1) {
            yMax = Math.ceil(value / 500) * 500;
            dtick = 500;
        }
        max = value / 200;
        if (max <= 10 && max >= 1) {
            yMax = Math.ceil(value / 200) * 200;
            dtick = 200;
        }
    }
    else if (max <= 10 && max >= 1) {
        yMax = Math.ceil(value / 1000) * 1000;
        dtick = 1000;
        max = value / 500;
        if (max <= 10 && max >= 1) {
            yMax = Math.ceil(value / 500) * 500;
            dtick = 500;
        }
        max = value / 200;
        if (max <= 10 && max >= 1) {
            yMax = Math.ceil(value / 200) * 200;
            dtick = 200;
        }
    } else {
        max = value / 100;
        yMax = Math.ceil(value / 100) * 100;
        dtick = 100;
        if (max <= 10 && max >= 1) {

            max = value / 50;
            if (max <= 10 && max >= 1) {
                yMax = Math.ceil(value / 50) * 50;
                dtick = 50;
            }
            max = value / 25;
            if (max <= 10 && max >= 1) {
                yMax = Math.ceil(value / 25) * 25;
                dtick = 25;
            }
            max = value / 20;
            if (max <= 10 && max >= 1) {
                yMax = Math.ceil(value / 20) * 20;
                dtick = 20;
            }
            max = value / 15;
            if (max <= 10 && max >= 1) {
                yMax = Math.ceil(value / 15) * 15;
                dtick = 15;
            }
        } else {
            max = value / 10;
            yMax = Math.ceil(value / 10) * 10;
            dtick = 10;
            if (max <= 10 && max >= 1) {
                max = value / 5;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 5) * 5;
                    dtick = 5;
                }
                max = value / 2;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 2) * 2;
                    dtick = 2;
                }
                max = value / 1;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 1) * 1;
                    dtick = 1;
                }
            } else if (max <= 10 && max <= 1) {
                max = value / 5;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 5) * 5;
                    dtick = 5;
                }
                max = value / 2;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 2) * 2;
                    dtick = 2;
                }
                max = value / 1;
                if (max <= 10 && max >= 1) {
                    yMax = Math.ceil(value / 1) * 1;
                    dtick = 1;
                }
            }
        }
    }
   

    return [{ max: yMax, dtick: dtick }];
}


/*Wait Cursor Script Starts*/
var overlay = $('<div id="overlay" class="modal-backdrop fade in"></div>');

function showLoadingCursor() {
    $("body").css("cursor", "none");
    //overlay.show();
    $('<div class="modal-backdrop fade in"></div>').appendTo('body');
    $('.popup').show();
}

function hideLoadingCursor() {
    $('.popup').hide();
    $('.modal-backdrop').remove();
    $("body").css("cursor", "auto");
}

/*Wait Cursor Script Ends*/


function GetXaxisMaxValue() {


}

function ConvertTatvamDataFormat(value, type) {
    var format = d3.format(type);
    return format(value);

}

/*common handler which acts as interceptor to all ajax requests.
currently, this handler is used to handle session time out related scenarios with ajax requests for data.
*/
$(document).ajaxSuccess(function (event, request, settings) {
    //to-do: need to check for solution other than considering 203 status code.    
    if (request.status === 203) {
        window.location.href = "../SessionTimeOut/SessionTimeOut";
    }
});

//Method to add class to element based on ID.
function AddClassToElementById(id, className) {

    if (!(className && id))
        return;

    $("#" + id).addClass(className);
}



//common method to add a new object (with one property) inside a base object.
function setObjProp(baseObj, baseObjPropName, newPropName, newPropValue) {
    //checks whether the base object contains the expected baseObjProp, if not then adds the baseObjPropName along with new property name value.
    if (baseObj[baseObjPropName] === undefined) {        
        baseObj[baseObjPropName] = {};
    }
    setProp(baseObj[baseObjPropName], newPropName, newPropValue);
}

//common method to add a new property and value
function setProp(obj, propName, propValue) {
    obj[propName] = propValue;
}

//To-Do: Need to consider the default parameters even when call is made without most of the properties.
// Common method for displaying the dialog popup 
function TatvamGenericConfirmDialog(dialogProperties) {

    //Bind the message for the dialog
    $(dialogProperties.dialogID).html(dialogProperties.message);

    var buttonProps = {};

    //Dynamically adding the buttons and it respective call back methods as per configuration.
    for (var index = 0; index < dialogProperties.buttonFunctions.length; index++) {
        var currentButtonFunction = dialogProperties.buttonFunctions[index];
        setProp(buttonProps, currentButtonFunction.name, currentButtonFunction.func);
    }

    //Binding the properties to the actual dialog box.
    $(dialogProperties.dialogID).dialog({
        resizable: dialogProperties.resizable,
        modal: dialogProperties.modal,
        title: dialogProperties.dialogTitle,
        height: dialogProperties.dialogHeight,
        width: dialogProperties.dialogWidth,
        buttons: buttonProps
    });
}

//Method to populate dropdown options
function PopulateDdlOptions(obj) {
    var optionsLength = obj.list.length;
    if (obj.list && optionsLength > 0) {

        for (var index = 0; index < optionsLength; index++) {
            var curOption = obj.list[index];

            if (curOption.Selected) {
                obj.controlObj.append('<option value="' +
                    curOption[obj.valueSelector] +
                    '"  selected="selected">' +
                    curOption[obj.textSelector] +
                    '</option>');
            }
            else {
                obj.controlObj.append('<option value="' +
                   curOption[obj.valueSelector] +
                   '">' +
                   curOption[obj.textSelector] +
                   '</option>');
            }
        }
    }
}


function TatvamRatingColor(rating) {
    if (rating < 1) {
        return '#4286f4';
    }
    else if (rating < 1.5) {
        return '#f34443';
    }
    else if (rating >= 1.5 && rating < 2.5) {
        return '#e66e0b';
    }
    else if (rating >= 2.5 && rating < 3.5) {
        return '#f3b81a';
    }
    else if (rating >= 3.5 && rating < 4.5) {
        return '#2dac07';
    }
    else if (rating >= 4.5) {
        return '#196004';
    }
}



//on success reload the page to get accurate data based on the periodicity
function tatvamDocumentReload() {
    document.location.reload(true);
}