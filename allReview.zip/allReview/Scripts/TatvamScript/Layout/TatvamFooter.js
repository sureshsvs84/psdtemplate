﻿var footerConstants = {
    url: {
        getBuildDetail: '../Data/BuildInfo'
    },
    elementIDConstant: {
        versionID: "#spnVersion",
        buildID: "#spnBuild",
        buildDate : "#spnBuildDate"
    },
};

$(function () {
    GetBuildDetails(BuildFooter);
});

//set build details in footer
function BuildFooter(buildInfo) {
    if (buildInfo) {
        $(footerConstants.elementIDConstant.versionID).text(buildInfo.Version);
        $(footerConstants.elementIDConstant.buildID).text(buildInfo.Build);
        $(footerConstants.elementIDConstant.buildDate).text(buildInfo.BuildDate);
    }
}

//get build details
function GetBuildDetails(callback) {
    $.ajax({
        url: BUILDINFO_URL,
        async: true,
        success: function (data) {
            callback(data);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}