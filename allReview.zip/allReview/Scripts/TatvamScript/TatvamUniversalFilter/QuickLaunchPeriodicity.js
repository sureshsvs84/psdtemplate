﻿//method to handle quick filters
function QuickLaunch(Periodicity) {    
    $("#" + Periodicity).siblings().removeClass('active')
    $("#" + Periodicity).addClass('active');

    switch (Periodicity) {
        case 'CurrentMonth':
            QuickFilterPeriodicity('Weekly', Periodicity);
            break;
        case 'Last3months':
        case 'Last6months':
        case 'Last13months':
            QuickFilterPeriodicity('Monthly', Periodicity);
            break;
    }
}

function weekofyear(date) {
    var d = new Date(+date);
    d.setHours(0, 0, 0);
    d.setDate(d.getDate() + 4 - (d.getDay() || 7));
    return Math.ceil((((d - new Date(d.getFullYear(), 0, 1)) / 8.64e7) + 1) / 7);
};
function getFormattedDate(input) { 
    var sptdate = input.split("-");
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var myMonth = sptdate[1];
    var myDay = sptdate[0];
    if (myDay.length == 1)
        myDay = "0" + myDay;
    var myYear = sptdate[2];
    var combineDatestr = myDay + "/" + months[myMonth - 1] + "/" + myYear;
    return combineDatestr;
}

function TatvamAlert(Message, Title) {
    bootbox.alert({
        size: "small",
        title: Title,
        message: Message,
        buttons: {
            ok: {
                label: 'Ok',
                className: 'btn-primary'
            }
        }
    })
}

//This method makes a server call to set periodicity based on QuickFilter selection
function QuickFilterPeriodicity(periodicity, startvalue) {
    $.ajax({
        type: 'Get',
        url: '../TatvamUniversalFilter/QuickLaunchPeriodicity',
        data: { Periodicity: periodicity, Period: startvalue },
        success: function () {
            //on success reload the page to get accurate data based on the periodicity
            document.location.reload(true);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

function Reset() {
    bootbox.confirm({
        message: "Do you want to reset?",
        size:"small",
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn-primary'
            },
            cancel: {
                label: 'No',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            $(this).modal('hide');
            if (result) {
                $.ajax(
                   {
                       url: "../TatvamUniversalFilter/reset",
                       type: "Get",
                       success: function (Result) {
                           window.location.href = Result;
                       },
                       error: function (jqXHR, exception) {
                           var msg = '';
                           if (jqXHR.status === 0) {
                               msg = 'Not connect.\n Verify Network.';
                           } else if (jqXHR.status == 404) {
                               msg = 'Requested page not found. [404]';
                           } else if (jqXHR.status == 500) {
                               msg = 'Internal Server Error [500].';
                           } else if (exception === 'parsererror') {
                               msg = 'Requested JSON parse failed.';
                           } else if (exception === 'timeout') {
                               msg = 'Time out error.';
                           } else if (exception === 'abort') {
                               msg = 'Ajax request aborted.';
                           } else {
                               msg = 'Uncaught Error.\n' + jqXHR.responseText;
                           }
                           console.log(msg);
                       },
                   });
            } else {
                $(this).modal('hide');
            }
        }
    });

 
}