﻿var tatvamAnalytics_CallURL = "http://www.tatvaminsights.com/";

var sessionTimeOut_CallURL = "../SessionTimeOut/SessionTimeOut";

//Hiding the Address View by default
$('#aboutusaddressView').hide();

//On click of Deatils button , show the details and hide the address data
function aboutusdetails() {
    $('#aboutusdetailsView').show();
    $('#aboutusaddressView').hide();
}

//On click of Address button , show the address and hide the details data
function aboutusaddress() {
    $('#aboutusdetailsView').hide();
    $('#aboutusaddressView').show();
}

//OnClick of Tatvam Logo redirect to Tatvam Analytics Website
function tatvamLogo() {
    window.open(tatvamAnalytics_CallURL, "_blank");
}

//Showing the popup onclick of About Us 
function aboutUsClick() {
    $('.dropdown-admin > .dropdown-menu').css('display', 'none');
    $.ajax({
        url: aboutUS_CallURL,
        success: function (data) {
            if (data.indexOf("<title>SessionTimeOut</title>") > -1) {
                window.location.href = sessionTimeOut_CallURL;
            }
            else {
                $("#window").empty();
                $("#window").html(data);
                FillAboutTatvamDetails(model[0]);
                $('#TatvamaboutUs').modal("show");
                $('.dropdown-admin > .dropdown-menu').css('display', 'none');
            }
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

function FillAboutTatvamDetails(JsonData) {
    $("#version").text(model[0].Version);
    $("#build").text(model[0].Build);
    $("#buildDate").text(model[0].BuildDate);
    $("#lastUpdate").text(model[0].LastUpdate);
}
