﻿var gridster;
var tatvamFilterCallURL = "../Filter/TatvamFilter";
$(function() {
    // To generate the Width and Height of the Base Widget Dynamically - Start
    var maxColumns = 12;
    var widgetWidth = (($(".gridster").width()) / maxColumns) - 10;
    var widgetHeight = 128;
    // To generate the Width and Height of the Base Widget Dynamically - End

    gridster = $(".gridster > ul").gridster({
        widget_margins: [5, 5], // Gap between widget
        draggable: {
            enabled: false
        },
        widget_base_dimensions: [widgetWidth, widgetHeight], //Widget min height and width
        min_cols: maxColumns,
        resize: {
            enabled: false,
            stop: function () {
            },
            resize: function (e, ui, $widget) {
                //alert($widget.children().find("div.reportpanel").attr("id"));
                var width = $widget.children().width();
                var height = $widget.children().height();
                var reportId = $widget.children().find("div.reportpanel div").attr("id");
                var reportname = $widget.children().find("div.reportpanel").attr("id");
                var update = {
                    width: width - 10, // or any new width
                    height: height - 10 // " "
                };

                if (reportname !== "14") {
                    Plotly.relayout(reportId, update);

                } else {
                    d3.select("svg")
                        .attr('height', height - 100)
                        .attr('width', width - 50)
                        .select("g")
                        .attr("transform", "translate(" + width / 2.5 + "," + height / 2.8 + ")")
                        .selectAll('text')
                        .attr("transform", function (d) {
                            return "translate(" + [d.x * 1.1, d.y * 1] + ")rotate(" + d.rotate + ")";
                        })
                        .style("font-size", function (d) {
                            return (d.size) * width * 0.002;
                        });

                }
            }
        }
    }).data('gridster').disable();

});


$(document).ready(function() {

    $('.restore').hide();

    /*Minimize Widget Starts*/
    $(".box-header span.minimize").click(function() // Grid Minimize function
    {
        $(this).parent().parent().find(".restore").show();
        $(this).parent().parent().parent().addClass("hide-class");
        $(this).hide();
        $('.filterby_panel_ul').hide();
        $(this).parent().parent().children().next('div.reportpanel').slideToggle('700');
    });
    /*Minimize Widget Ends*/

    /*Restore Widget Starts*/
    $(".box-header span.restore").click(function() //Grid Restore function
    {
        $(this).hide();
        $(this).parent().parent().find(".minimize").show();
        $(this).parent().parent().parent().removeClass("hide-class");
        $(this).parent().parent().children().next('div.reportpanel').slideToggle('700');
    });
    /*Restore Widget Ends*/

    /*Close Widget Starts*/
    $(".box-header span.close_window").click(function() {
        var parent = $(this).parent().parent().parent().parent();

        /*Tatvam Confirmation Message Box Starts*/
        bootbox.confirm({
            title: "Confirmation Box",
            size: "small",
            message: "Are you Sure? You want to close this widget.",
            buttons: {
                confirm: {
                    label: 'Yes',
                    className: 'btn-primary'
                },
                cancel: {
                    label: 'No',
                    className: 'btn-default'
                }
            },
            callback: function (result) {
                if (result) {
                    $(this).modal('hide');
                    gridster.remove_widget(parent);
                } else {
                    $(this).modal('hide');
                }
            }
        });
    });
    /*Close Widget Ends*/

    $('.filterby_panel_ul').hide();
    $(".filterby_panel").click(function() {
        $(this).next('.filterby_panel_ul').slideToggle();
        $(".ui-multiselect-menu").css("display", "none");
        if ($(".ui-selectmenu-menu").hasClass("ui-selectmenu-open"))
            $(".ui-selectmenu-menu").removeClass("ui-selectmenu-open");
    });

    $(".FilterCancel").click(function() {
        $('.filterby_panel_ul').slideUp();
        $(this).next('.filterby_panel_ul').slideToggle();
        //$('.exportto_panel_ul').slideUp(300);
    });    
});


function Tatvamfilter(event) {
    $('.filterby_panel_ul').not($(event.target).closest('li').find('.filterby_panel_ul')).hide(300);
    $(event.target).closest('li').find('.filterby_panel_ul').slideToggle(300);
}

/*Clear Report Level Filter*/
function ClearFilter(reportid) {
    var control = 'filter' + reportid;
    $(event.target).closest('li').find('.filterpanel').empty();
    $.ajax({
        type: "POST",
        async: false,
        url: tatvamFilterCallURL,
        data: { ReportCategoryId: reportid },
        success: function(result) {
            $("#" + control).append(result);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}

/*Cancel Report Level Filter*/
function CancelFilter() {
    $(".filterby_panel_ul").hide("slow");
}

$(function() {

    $('.item').draggable({
        revert: true,
        proxy: 'clone',
        onStartDrag: function() {
            $(this).draggable('options').cursor = 'not-allowed';
            $(this).draggable('proxy').css('z-index', 10);
        },
        onStopDrag: function() {
            $(this).draggable('options').cursor = 'move';
        }
    });
    $('.gridster').droppable({
        onDragEnter: function(e, source) {
            $(source).draggable('options').cursor = 'auto';
        },
        onDragLeave: function(e, source) {
            $(source).draggable('options').cursor = 'not-allowed';
        },
        onDrop: function(e, source) {
            var name = $(source).find('span:eq(0)').html();
            var url = $(source).find('span:eq(1)').html();


            addProduct(name, url);
        }

    });
});

function addProduct(name) {
    creatDaynamicDiv();

    function creatDaynamicDiv() {
        for (var i = 0; i < 2; i++) {
            var row = i;
        }
        $("<li data-row=" + i + " data-col=" + i + " data-sizex='1' data-sizey='1' class='gs-w'>" + name + "</li>").appendTo('.gridster ul');

    }
}

$('#pending').removeAttr('style');

$(".tabs-menu a").click(function(event) {

    event.preventDefault();
    $(this).parent().addClass("current");
    $(this).parent().siblings().removeClass("current");
    var tab = $(this).attr(".tabs-menu href");
    $(".tab-content").not(tab).css("display", "none");

});


$('.gridster ul li').click(function() {
    $(this).find('.sub-menu').slideToggle(300);
});


function TatvamConfirmation(msg) {
    /*Tatvam Confirmation Message Box Starts*/
    bootbox.confirm({
        title: "Confirmation Box",
        size: "small",
        message: msg,
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn-primary'
            },
            cancel: {
                label: 'No',
                className: 'btn-default'
            }
        },
        callback: function (result) {
            if (result) {
                $(this).modal('hide');
                return true;
            } else {
                $(this).modal('hide');
                return false;
            }
        }

    });
   
}


$(function() {
    $("#dialog").dialog({
        autoOpen: false,
        width: 550,
        height: 170,
        show: {
            effect: ""
        },
        hide: {
            effect: ""  
        }
    });
    var opt = {
        autoOpen: false,
        effect: "",
        width: 550,
        height: 170,
        title: 'Filter'
    };

    //$(this).dialog('close');	

    $(".opener").click(function() {
        var theDialog = $("#dialog").dialog(opt);
        theDialog.dialog("open");
    });
});


function SearchFilter(reportid, reportType, chartType) {    
    var array = [];
    $('#filter' + reportid + ' .searchpanel').each(function() {
        var searchbyText = $(this).find("#ddl_searchby option:selected").text();
        var searchbyValue = $(this).find("#ddl_searchby option:selected").val();

        var operatorName = $(this).find("#ddl_operator option:selected").text();
        var operatorValue = $(this).find("#ddl_operator option:selected").val();


        var valueId = $(this).find("[id^='ddl_value']").attr("id");

        var SelectedText = [];
        var SelectedValue = [];
        $(this).find("#" + valueId + " option:selected").each(function() {
            SelectedText.push({ Name: this.text });
            SelectedValue.push({ Name: this.value });
        });

        if (SelectedText.length === 0) {
            var val = $(this).find("#" + valueId).val();
            if (val !== "" && val !== null) {
                SelectedValue = [];
                SelectedText.push({ Name: '%' + val + '%' });
                SelectedValue.push({ Name: '%' + val + '%' });
            }
        }

        var conditionName = $(this).find("#ddl_whereclause option:selected").text();
        var conditionValue = $(this).find("#ddl_whereclause option:selected").val();
        if (SelectedValue.length > 0) {
            array.push({
                "SearchbyText": searchbyText,
                "SearchbyValue": searchbyValue,
                "OperatorName": operatorName,
                "OperatorValue": operatorValue,
                "SelectedText": SelectedText,
                "SelectedValue": SelectedValue,
                "ConditionName": conditionName,
                "ConditionValue": conditionValue
            });
        }
    });

    $.ajax({
        type: 'POST',
        async: false,
        url: '../' + reportType + '/' + chartType,
        data: { reportId: reportid, TatvamReportFilterTo: JSON.stringify(array) },
        success: function(result) {
            $("#" + reportid).html(result);
            CancelFilter(reportid);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}