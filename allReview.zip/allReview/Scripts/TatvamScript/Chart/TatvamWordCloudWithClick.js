﻿var LinePlusBarChartWith2YAxisWithClick_CallURL = "../Chart/LinePlusBarChartWith2YAxisWithClick";

// Tatvam Word Cloud chart 
(function BuildWordCloudWithClick($) {
    var wordCloudWithClickDataSet;
    var formatAs2Dec = d3.format(".2f");

    var wordCloudWithClick = {
        tatvam_wordcloudwithclick: function (data, reportId) {
            if (data.length <= 0) {
                $("#wordCloudWithClick").empty();
                $(".reportpanel").append("<div class=\'nodata\'>No Data Available.</div>");
                return;
            }
            var wordScale = d3.scale.linear().domain([1, d3.max(data, function (d) {
                return d.Count;
            })]).range([14, 30]).clamp(true);
            var maxValue = 0, selectedval, avg, childcount = 0;
            $("#wordCloudWithClick").empty();

            var height = $('#report_' + reportId).height();
            var width = $('#report_' + reportId).width() - 50;
            var padding = 10 / data.length;

            d3.layout.cloud()
				.size([width, height])
				.words(data.map(function (d) {
				    if (maxValue < d.Count) {
				        maxValue = d.Count;
				        avg = d.Avg;
				        selectedval = d.ParentWord;
				        childcount = d.ChildCount;
				    }
				    return { text: d.ParentWord, size: d.Count, Avg: d.Avg };
				}))
				.padding(4)
			    .rotate(function () { return ~~(Math.random() * 2) * 0; })
				.font("Lato")
				.fontSize(function (d) {
				    return wordScale(+d.size);
				})
				.on("end", wordCloudWithClick.create_WordCloudWithClick_chart)
				.start();
            if (selectedval == undefined)
                var classifiername = 'None';
            else
                classifiername = selectedval;

            $("#selectedValue").empty();

            var selectedFilter = "<div class='wordCloudSelectedItem " + actualBgColor(formatAs2Dec(avg)) + "'><label class='lblClassifier'><span id='wordCloudWithClickSelectedVal' style='padding-right: 5px;'>" + classifiername + "</span>";
            if (formatAs2Dec(avg) != "0.00") {
                selectedFilter += "<span class='averageRating " + actualBgColor(formatAs2Dec(avg)) + "'> " + formatAs2Dec(avg) + "</span>";
            }
            selectedFilter += "</label><label class='lblSubClassifier'>Sub Classifier <span class='subClassifierCount'>" + childcount + "</span></label><label class='lblUniqueReviews'>Unique Review <span class='uniqueReviewsCount'>" + maxValue + "</span></label></div>";

            $("#selectedValue").empty();
            $("#selectedValue").append(selectedFilter);


            var SelectedText = [];
            var SelectedValue = [];
            SelectedText.push(selectedval);
            SelectedValue.push(selectedval);
            //CallLinePlusBarChartWith2YAxisonWordCloudClick(reportId, SelectedText, SelectedValue, 'Classifier', '(TARGET_ENTITY_VALUE in (@Classifier) or PARENT_VALUE  in (@Classifier))');
            CallStackedBarChart(worldCloudClickReportId, SelectedText, SelectedValue, 'Classifier', '(TARGET_ENTITY_VALUE in (@Classifier) or PARENT_VALUE  in (@Classifier))');
            CallReviewListonWordCloudClick(worldCloudClickReportId, SelectedText, SelectedValue, 'Classifier', '(TARGET_ENTITY_VALUE in (@Classifier) or PARENT_VALUE  in (@Classifier))');

        },
        create_WordCloudWithClick_chart: function (words) {

            var height = $('#report_' + worldCloudClickReportId).height() - 40;
            var width = $('#report_' + worldCloudClickReportId).width();

            d3.select("#wordCloudWithClick").append("svg")
				.attr("width", width)
				.attr("height", height)
				.append("g")
                .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")")
				.attr("cursor", "pointer")
				.selectAll("text")
				.data(words)
				.enter().append("text")
				.style("font-size", function (d) { return d.size + "px"; })
				.style("font-family", "Lato")
				.style("font-weight", "bold")
				.style("fill", function (d, i) {
				    if (words[i].Avg == 0) {
				        return myColors[i];
				    }
				    return TatvamRatingColor(words[i].Avg);
				})
				.attr("text-anchor", "middle")
				.attr("transform", function (d) {
				    return "translate(" + [d.x - 3, d.y - 5] + ")rotate(" + d.rotate + ")";
				})
				.text(function (d) { return d.text; })
				.on("click", function (d) {
				    var that = this;
				    setTimeout(function () {
				        var dblclick = parseInt($(that).data('double'), 10);
				        if (dblclick > 0) {
				            $(that).data('double', dblclick - 1);
				        } else {
				            var rtn = wordCloudWithClick.findNode(d.text, wordCloudWithClickDataSet);
				            var weight = rtn.Count;
				            var avg = rtn.Avg;
				            var children = 0;

				            children = rtn.ChildCount;
				            var selectedFilter = "<div class='wordCloudSelectedItem " + actualBgColor(formatAs2Dec(avg)) + "'><label class='lblClassifier'><span id='wordCloudWithClickSelectedVal' style='padding-right: 5px;'>" + d.text + "</span>";
				            if (formatAs2Dec(avg) != "0.00") {
				                selectedFilter += "<span class='averageRating " + actualBgColor(formatAs2Dec(avg)) + "'> " + formatAs2Dec(avg) + "</span>";
				            }
				            selectedFilter += "</label><label class='lblSubClassifier'>Sub Classifier <span class='subClassifierCount'>" + children + "</span></label><label class='lblUniqueReviews'>Unique Review <span class='uniqueReviewsCount'>" + weight + "</span></label></div>";

				            $("#selectedValue").empty();
				            $("#selectedValue").append(selectedFilter);
				            var SelectedText = [];
				            var SelectedValue = [];
				            SelectedText.push(d.text);
				            SelectedValue.push(d.text);
				            //CallLinePlusBarChartWith2YAxisonWordCloudClick(reportId, SelectedText, SelectedValue, 'Classifier', '(TARGET_ENTITY_VALUE in (@Classifier) or PARENT_VALUE  in (@Classifier))');				            
				            CallStackedBarChart(worldCloudClickReportId, SelectedText, SelectedValue, 'Classifier', '(TARGET_ENTITY_VALUE in (@Classifier) or PARENT_VALUE  in (@Classifier))');
				            CallReviewListonWordCloudClick(worldCloudClickReportId, SelectedText, SelectedValue, 'Classifier', '(TARGET_ENTITY_VALUE in (@Classifier) or PARENT_VALUE  in (@Classifier))');
				        }
				    }, 300);
				})
				.on("mouseover", function (d) {
				    $("#selectedValue").hide();
				    var rtn = wordCloudWithClick.findNode(d.text, wordCloudWithClickDataSet);
				    var weight = rtn.Count;
				    var avg = rtn.Avg;
				    var children = 0;
				    children = rtn.ChildCount;

				    var selectedFilter = "<div class='wordCloudSelectedItem lightGreen'><label class='lblClassifier'><span id='wordCloudWithClickSelectedVal' style='padding-right: 5px;'>" + d.text + "</span>";
				    if (formatAs2Dec(avg) != "0.00") {
				        selectedFilter += "<span class='averageRating " + actualBgColor(formatAs2Dec(avg)) + "'> " + formatAs2Dec(avg) + "</span>";
				    }
				    selectedFilter += "</label><label class='lblSubClassifier'>Sub Classifier <span class='subClassifierCount'>" + children + "</span></label><label class='lblUniqueReviews'>Unique Review <span class='uniqueReviewsCount'>" + weight + "</span></label></div>";

				    $("#mouseover").empty();
				    $("#mouseover").append(selectedFilter);
				})
				.on("mouseout", function () {
				    $("#mouseover").empty();
				    $("#selectedValue").show();
				});
        },
        findNode: function (text, json) {
            if (!(json && "object" === typeof json)) { return; }
            if (json.ParentWord === text) { return json; }
            for (var x in json) {
                if (Object.hasOwnProperty.call(json, x)) {
                    var result = wordCloudWithClick.findNode(text, json[x]);
                    if (result !== undefined) { return result; }
                }
            }
        }
    }

    var methods = {
        init: function (options) {
            this.TatvamWordCloudWithClick.settings = $.extend({}, this.TatvamWordCloudWithClick.defaults, options);
            return this.each(function () {
                //  var $element = $(this), // reference to the jQuery version of the current DOM element
                //element = this;      // reference to the actual DOM element                    
            });
        },

        // a public method. to draw the Tatvam Word Cloud chart!
        create_tatvamWordCloudWithClick: function (data) {
            wordCloudWithClickDataSet = data.data;
            wordCloudWithClick.tatvam_wordcloudwithclick(data.data, data.reportId);
        }
    }


    $.fn.TatvamWordCloudWithClick = function (method) {
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            $.error('Method "' + method + '" does not exist in TatvamWordCloudWithClick plugin!');
        }
    }


})(jQuery);


function CallLinePlusBarChartWith2YAxisonWordCloudClick(reportId, selectedText, selectedValue, searchbyText, searchbyValue) {

    var array = [];
    $('.searchpanel').each(function () {
        var searchbyText = $(this).find("#ddl_searchby option:selected").text();
        var searchbyValue = $(this).find("#ddl_searchby option:selected").val();

        var operatorName = $(this).find("#ddl_operator option:selected").text();
        var operatorValue = $(this).find("#ddl_operator option:selected").val();

        var valueId, selectedText = "", selectedValue = "";
        valueId = $(this).find("[id^='ddl_value']").attr("id");

        var SelectedText = [];
        var SelectedValue = [];

        $(this).find("#" + valueId + " option:selected").each(function () {
            SelectedText.push({ Name: this.text });
            SelectedValue.push({ Name: this.value });
        });

        if (SelectedText.length === 0) {
            var val = $(this).find("#" + valueId).val();
            if (val !== "") {
                SelectedValue = [];
                SelectedText.push({ Name: '%' + val + '%' });
                SelectedValue.push({ Name: '%' + val + '%' });
            }
        }

        var conditionName = $(this).find("#ddl_whereclause option:selected").text();
        var conditionValue = $(this).find("#ddl_whereclause option:selected").val();


        if (SelectedValue.length > 0) {
            array.push({
                "SearchbyText": searchbyText,
                "SearchbyValue": searchbyValue,
                "OperatorName": operatorName,
                "OperatorValue": operatorValue,
                "SelectedText": SelectedText,
                "SelectedValue": SelectedValue,
                "ConditionName": "or",
                "ConditionValue": "or"
            });
        }
    });

    array.push({
        "SearchbyText": searchbyText,
        "SearchbyValue": searchbyValue,
        "OperatorName": "Equal To",
        "OperatorValue": "=",
        "SelectedText": selectedText,
        "SelectedValue": selectedValue,
        "ConditionName": "or",
        "ConditionValue": "or"
    });

    $.ajax({
        type: 'POST',
        async: true,
        //dataType: 'json',
        url: LinePlusBarChartWith2YAxisWithClick_CallURL,
        data: { reportId: reportId, tatvamReportFilterTo: JSON.stringify(array) },
        success: function (result) {
            var reportCategoryIdIndex = result.indexOf("ReportCategoryId");
            if (reportCategoryIdIndex !== -1) {
                var reportCategoryId = result.substr(reportCategoryIdIndex + 9).split('"')[0]
                $("#report_" + reportCategoryId).empty();
                $("#report_" + reportCategoryId).html(result);
            }
            //$("#66").empty();
            //$("#66").html(result);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error, "Error");
        }
    });
}

function onRatingSmileClick(val, reportID) {
    $(".reviewListFilterSmile li").removeClass("selectedli");
    var scoreclass = $('.' + val)
    scoreclass.addClass("selectedli");
    var mainClassifier = $.trim($("#wordCloudWithClickSelectedVal").text());
    var subClassifier = $.trim($("#StackedBarChartSelectedSubClassifier").text());
    subClassifier = $.trim(subClassifier);
    var selectedText = [];
    var selectedValue = [];
    if (subClassifier == "") {
        selectedText.push(mainClassifier);
        selectedValue.push(mainClassifier);
    }
    else {
        subClassifier = subClassifier.replace("> ", "");
        selectedText.push(subClassifier);
        selectedValue.push(subClassifier);
    }
    if (val != 0) {
        CallReviewListonWordCloudClick(reportID, selectedText, selectedValue, 'Classifier', ' TARGET_ENTITY_VALUE in (@Classifier) or PARENT_VALUE  in (@Classifier)');
    }
    else {
        CallReviewListonWordCloudClick(reportID, selectedText, selectedValue, 'Classifier', ' TARGET_ENTITY_VALUE in (@Classifier) or PARENT_VALUE  in (@Classifier)');
    }
}

function actualBgColor(rating) {
    if (rating < 1.5) {
        return "red";
    }
    else if (rating >= 1.5 && rating < 2.5) {
        return "orange";
    }
    else if (rating >= 2.5 && rating < 3.5) {
        return "yellow";
    }
    else if (rating >= 3.5 && rating < 4.5) {
        return "lightGreen";
    }
    else if (rating >= 4.5) {
        return "darkGreen";
    }
}


function GetWorldCloudClickData(reportId) {
    $.getJSON("../Data/GetWordCloudData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        if (data.Result == null || data.Result.length <= 0) {
            $("#wordCloudWithClick").empty();  
            $("#wordCloudWithClick").append("<div class=\'nodata\'>No Data Available.</div>");
        } else {  
            $('#wordCloudWithClick').TatvamWordCloudWithClick('create_tatvamWordCloudWithClick', { data: data.Result, reportId: reportId } );
        }
        $("#chartloader_" + reportId).css('display', 'none');
    })
        .fail(function () { 
            $('#wordCloudWithClick').css('display', 'block'); 
            $("wordCloudWithClick").empty(); 
            $("#wordCloudWithClick").append("Something went wrong."); 
        });

}