﻿function GetFacebookRecommendationsData(reportId){
    $.getJSON("../Data/GetChartData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        $("#facebookRecommendations").css('display', 'block');
        if(data.Result == null){
            $("#facebookRecommendations").empty();
            $("#facebookRecommendations").append("<div class=\'nodata\'>No Data Available.</div>");
        }  else if(data.Result.Recommend === 0 && data.Result.DoesntRecommend === 0){
            $("#facebookRecommendations").empty();
            $("#facebookRecommendations").append("<div class=\'nodata\'>No Data Available.</div>");
        } else {
            if (data.Result.Recommend === undefined) {
                $("#facebookRecommendations").empty();
                $("#facebookRecommendations").append("<div class=\'nodata\'>No Data Available.</div>");
            } else {
                $("#recommendationCount").text(data.Result.Recommend);
                $("#notrecommendationCount").text(data.Result.DoesntRecommend);            }
        }
    })
        .fail(function() { 
            $("#facebookRecommendations").css('display', 'block');  
            $("#facebookRecommendations").empty();  
            $("#facebookRecommendations").append("Something went wrong.");  
        })
        .always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}