//Tabs Navigation
var currentPassword;

var saveProfileCallURL = "../UserProfile/SaveUserProfile";
var updateProfileCallURL = "../UserProfile/UpdateUserPassword";
var getProfileCallURL = "../UserProfile/GetUserProfile";

$(document).ready(function () {
    $(".button").button();

    $(".nav-tabs a").click(function () {
        $('#inputCurrentPassword').val("");
        $('#inputNewPassword').val("");
        $('#inputreTypePassword').val("");
        var tabcontrol = $(this);
        var element = $(this)[0];
        var tabname = element.innerHTML;
        if (tabname == "Change Password") {
            $(".edit").attr("style", "visibility: hidden");
            if ($('#submit').prop('disabled') == false) {
                event.stopPropagation();
                bootbox.confirm({
                    title: "Confirm Navigation",
                    message: "The Changes you made will be lost if you navigate away from this tab. Are you sure you want to leave this tab?",
                    buttons: {
                        confirm: {
                            label: 'Ok',
                            className: 'btn-primary'
                        },
                        cancel: {
                            label: 'Cancel',
                            className: 'btn-default'
                        }
                    },
                    callback: function (result) {
                        if (result) {
                            tabcontrol.tab('show');
                        } else {
                            event.stopPropagation();
                        }
                        $(this).modal('hide');
                    }

                })


                event.stopPropagation();
            }
        } else {
            $(".edit").attr("style", "visibility: visible");
            readUserProfile();
            $('#submit').prop('disabled', true);
            $('#submit').addClass("blur")
        }
    });

    readUserProfile();

    //Image onmouse over
    // var colorOrig = $(".onovercolor").css('background');
    $("#onovercolor").mouseover(function () {
    });

    //onclick of edit image file mode opened
    $("#updateimg").click(function () {

        $("input[id='my_file']").click();
        readFile();
        $('#submit').prop('disabled', false);
        $('#submit').removeClass("blur");
    });

    //on click of edit image upload the image 
    function EL(id) {
        return document.getElementById(id);
    } // Get el by ID helper function

    var image;

    function readFile() {
        if (this.files && this.files[0]) {
            if (this.files[0].type !== "image/png" && this.files[0].type !== "image/jpeg" && this.files[0].type !== "image/jpg" && this.files[0].type !== "image/gif") {
                TatvamAlert("Wrong file type, please select an image", "Warning")
                return;
            }
            var FR = new FileReader();
            FR.onload = function (e) {
                EL("imgProfilepic").src = e.target.result;

                image = e.target.result;
            };
            FR.readAsDataURL(this.files[0]);
        }
    }

    EL("my_file").addEventListener("change", readFile, false);


    //on click of delete image the delete the uploaded image and display the Default Image 
    $('#deleteimg').on('click', function () {

        $('#imgProfilepic').attr("src", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEwAACxMBAJqcGAAABIhJREFUeJzt3U9oHGUYx/HvJKVp1KoFLdVbNf6BlFTQi6Bic6miFY+CJ0FQBPEiPSle7MGCYpGCCNVLQYsgghRU8A9a6NFaRcGD/xCVVmtTJBqSNh7eppQl6+5m5t1n3v39PvAcmpDyzPv8Znd2ZnYXzMzMzMzMzExFFd1AgzYBu4AdwAywFdgIrKv5/y4BZ4DvgS+Bj4DD539mLTANHAQWgOUh1TxwALhhCNtnXWwE9gPnGN7gO2sR2AtMZt5W6zANfEfc4DvrODCVdYvtgtuBv4gfemedAG7JuN0GbKOdw784BH4kyORy2vWw/39PBz4myGA/8cPtt/ZmWgNZ24g92h+0FvFLxEYdJH6og9aBLCshaBPDPcnTVM2TzlW02lh0A324H1gf3cQaTAL3RTfRSwkB2BHdQA2z0Q30UkIAZqIbqGF7dAO9lBCArdEN1HBddAO9lHA5eJH6l3SjLNLy45cSArAc3UBNrV7jEp4CLCMHQJwDIM4BEOcAiHMAxDkA4hwAcQ6AOAdAnAMgzgEQ5wCIcwDEOQDiHABxDoA4B0CcAyDOARDnAIhzAMQ5AOIcAHEOgDgHQJwDIM4BEOcAiHMAxDkA4koIwNnoBmpYim6glxICMBfdQA2t772EAPwU3UANP0Y30EsJAfgiuoEajkU30EsJAfgkuoEaSu69Na4E/iX+o18HrX/O995qJTwCnAbejG5iDQ6RercG3Eh6SRW9V/dbZ4Gbs6yEsBeJH2y/tS/TGki7BPia+OH2qm+BSzOtgbwp4CTxQ+5WfwI3Zdt6A9JXs50gftirDf+2jNttF7me9O1c0UNfqW9IB6o2RBuAF0ifyB05/Nfxc36oY8QG4J78m5hPCSeCLCMHQJwDIM4BEOcAiHMAxDkA4hwAcQ6AFe1R0s0XkWcCj5C+4dyGqAKeI/4i0EodB67NusV2wTrgNeKH3lk/4CuC2W0BPiV+2N3qNLAr18aruxP4jfgh91PPA+N5lkHPOLCbsu4KXgY+BK7JsB5SpoDPiR/mWusU8FDjqyJgDHgSmCd+iE3UIeCqRldohM1Q9l7frU4Cj+CTb11dAbxMec/1g9YRYHtDazYSxkl7xu/ED2dYtQS8AlzdwPoVqyK9Zi7h3T656gzwDIJ3Fd8BfEb8ANpSvwKPAxN1FrXtKuBu4GPiF7yt9TPwBCMWhArYiff4QeoX4CngsjWsd2tMkA7uviJ+QUutU8Ae0jWQYmwBnqWc8/Yl1ALwBnDrAHMYqop0seYt4t+rN+p1FHiYlhwnbAaeJr07Nnph1OoP4CVguueUGjYBPAi8g/f2ttRR4DEy3po2BtwFvEo6MIneYNfqtQC8TdpBN6w6yQGMk07Y7COdqIjeONdgNUc6cLwXWE8XVce/J4FZ4AFSijZ3+0MryhzwHvAu8AHw98ovKtJNFztJSZklhcBG1wLpI2wPA+9XpIcLE+WbE8Q5AOIcAHEOgDgHQJwDIM4BEOcAiHMAxDkA4hwAcQ6AOAdAnAMgzgEQ5wCIcwDEOQDiHABxDoA4B0CcAyDOARD3H/liu7UYRkgoAAAAAElFTkSuQmCC");
        $('#submit').prop('disabled', false);
        $('#submit').removeClass("blur");
    });


    //profile information Enable and Disable the  button with validation	
    $("#submit").attr('disabled', 'disabled');
    $("#Profilevalidation").delegate("input", "input", function () {

        $("#submit").attr('disabled', 'disabled');
        // Validating Fields
        var Mobile = $('#inputContactNo').val().trim();
        var FirstName = $('#inputFirstName').val().trim();
        var LastName = $('#inputLastName').val().trim();
        var Dname = $('#inputDisplayName').val().trim();
        var EmailId = $('#inputEmail').val().trim();
        //var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
        //var Phoneno=/^([0-9])$/;
        var regex = new RegExp("^[a-z?=.*!@#$%^&*]+$");
        //if (!(Fname == "" || Lname == "" || Dname == "" || email=="" || Contactno=="")) {

        $('#submit').prop('disabled', false);
        $('#submit').removeClass("blur");

        //  }	   
        if (Mobile == "")
            $('#inputContactNo').val("");
        if (FirstName == "")
            $('#inputFirstName').val("");
        if (LastName == "")
            $('#inputLastName').val("");
        if (Dname == "")
            $('#inputDisplayName').val("");
    });

    //Json Data for User Profile and Change password
    //User profile JSON Data
    $('#Profilevalidation').submit(function () {

        var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
        if ($('#inputFirstName').val().trim() == "") {
            TatvamAlert("Enter the First name", "Error");

        } else if ($('#inputLastName').val().trim() == "") {
            TatvamAlert("Enter the last name", "Error");
        } else if ($('#inputDisplayName').val().trim() == "") {
            TatvamAlert("Enter the Display name", "Error");
        } else if (!filter.test($('#inputEmail').val())) //|| regex.test(FirstName) && regex.test(LastName))) {
        {
            TatvamAlert("Enter proper Email-Id", "Error");

        } else {
            if (image == undefined)
                image = $('#imgProfilepic').attr("src");
            var userData = $('#Profilevalidation').serializeObject();
            $.ajax({
                url: saveProfileCallURL,
                type: "POST",
                data: { Userdetails: userData, userimage: image },
                reloadAfterSubmit: true,
                success: function (result) {
                    var userImageName = "<img src=" + image + " class='img-circle userProfileImage imgProfilepic' title='Profile' / >" + userData.DisplayName
                    $("#LoggedInUserName")[0].innerHTML = userImageName;                    
                    bootbox.alert({
                        message: "User Profile Successfully Updated.",
                        title: "Alert Box",
                        size: "small",                     
                        callback: function (result) {
                            closeNav();
                            readUserProfile();
                        }
                    });
                },
                error: function (a, b, c) {
                    TatvamAlert("UserProfile: Error While Updating the Records.", "Error");
                }
            });
        }
        return false;
    });

    $("#chgpwdform").delegate("input", "input", function () {
        $('#submitchangepassword').removeClass("blur");
        $('#submitchangepassword').prop('disabled', false);
        var Currentpassword = $('#inputCurrentPassword').val().trim();
        var Newpassword = $('#inputNewPassword').val().trim();
        var Retypepassword = $('#inputreTypePassword').val().trim();


        if (Currentpassword == "")
            $('#inputCurrentPassword').val("");
        if (Newpassword == "")
            $('#inputNewPassword').val("");
        if (Retypepassword == "")
            $('#inputreTypePassword').val("");
    });

    //Change Password JSON Data
    $('#chgpwdform').submit(function () {
        // Validating Fields
        var Currentpassword = $('#inputCurrentPassword').val().trim();
        var Newpassword = $('#inputNewPassword').val().trim();
        var Retypepassword = $('#inputreTypePassword').val().trim();

        if (Currentpassword == "") {
            TatvamAlert("Enter Current Password.", "Error");
            return false;
        } else if (Newpassword == "") {
            TatvamAlert("Enter New Password.", "Error");
            return false;
        } else if (Retypepassword == "") {
            TatvamAlert("Enter Re-Type Password.", "Error");
            return false;
        }

        if (!(Currentpassword == "" || Newpassword == "" || Retypepassword == "")) {
            if (Currentpassword === Newpassword) {
                TatvamPasswordAlert("Current and New Password cannot be same.", "Error");
                $('#submitchangepassword').prop('disabled', true);
                $('#submitchangepassword').addClass("blur");
            } else if (Newpassword != Retypepassword) {
                TatvamPasswordAlert("New and Re-Type Password should be same.", "Error");
                $('#submitchangepassword').addClass("blur");
                $('#submitchangepassword').prop('disabled', true);
            } else {

                $.ajax({
                    url: updateProfileCallURL,
                    type: "POST",
                    data: { Newpassword: Newpassword, Currentpassword: Currentpassword },
                    success: function (result) {
                        if (result == 'Password has been Successfully Updated.') {
                            TatvamPasswordAlert(result, "Success");

                        } else {
                            TatvamPasswordAlert(result, "Error");
                            $('#submitchangepassword').addClass("blur");
                            $('#submitchangepassword').prop('disabled', true);

                        }
                    },
                    error: function () {
                        TatvamPasswordAlert("UserProfile: Error While Updating the user password.", "Error");
                    }
                });


            }
        }


        return false;

    });
});


function readUserProfile() {

    $.ajax({
        url: getProfileCallURL,
        type: "POST",
        success: function (searchResults) {

            if (searchResults.EmailId === "") {
                if (searchResults.indexOf("<title>SessionTimeOut</title>") > -1) {

                    window.location.href = "../SessionTimeOut/SessionTimeOut";
                } else {
                    var jsonData = searchResults;
                    globalData = jsonData;
                    FillProfileData(jsonData);
                }
            } else {
                var jsonData = searchResults;
                globalData = jsonData;
                FillProfileData(jsonData);
            }

        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}


//Displaying the hardcoded JSON Data
function FillProfileData(UserProfileJsonObject) {

    /*Writing the values to User Profile*/
    $('#lblUsername').text(UserProfileJsonObject.DisplayName);
    if (UserProfileJsonObject.Role !== undefined) {
        $('#lblUserrole').text(UserProfileJsonObject.Role);
        $("#pusrrole").css('display', 'block');
    } else {
        //$(".fa fa-briefcase").css('visibility', 'hidden');
        $("#pusrrole").css('display', 'none');
    }
    if (UserProfileJsonObject.EmailId !== undefined) {
        $('#lblUseremailid').text(UserProfileJsonObject.EmailId);

        $("#pusremail").css('display', 'block');
    } else {
        $("#pusremail").css('display', 'none');

    }
    if (UserProfileJsonObject.Mobile.trim() !== "") {
        $('#lblUsercontactno').text(UserProfileJsonObject.Mobile);
        //  $("p i3").addClass("fa fa-mobile");
        $("#pusrcontact").css('display', 'block');
    } else {
        $("#pusrcontact").css('display', 'none');

    }


    /*Images of User profile*/
    $('#imgProfilepic').attr("src", UserProfileJsonObject.UserImage)

    //Writing the valus to the Right side Profile tab 
    $('#inputFirstName').val(UserProfileJsonObject.FirstName);
    $('#inputLastName').val(UserProfileJsonObject.LastName);
    $('#inputDisplayName').val(UserProfileJsonObject.DisplayName);
    $('#inputEmail').val(UserProfileJsonObject.EmailId);
    $('#inputContactNo').val(UserProfileJsonObject.Mobile);

    currentPassword = UserProfileJsonObject.Password;
    $('#submit').addClass("blur");
    $('#submitchangepassword').addClass("blur");
    $('#submitchangepassword').prop('disabled', true);
}


//On submit  form data convert into JSON Formate
$.fn.serializeObject = function () {
    var o = {};
    var a = this.serializeArray();
    $.each(a, function () {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};


function TatvamAlert(Message, Title) {
    bootbox.alert({
        title: Title,
        message: Message,
        buttons: {
            ok: {
                label: 'Ok',
                className: 'btn-primary'
            }
        }
    })
}

function TatvamPasswordAlert(Message, Title) {
    bootbox.alert({
        title: Title,
        message: Message,
        buttons: {
            ok: {
                label: 'Ok',
                className: 'btn-primary'
            }
        },
        callback: function () {
            $('#inputCurrentPassword').val("");
            $('#inputNewPassword').val("");
            $('#inputreTypePassword').val("");
            $('#submitchangepassword').addClass("blur");
            $(this).modal('hide');
        }

    })

}


function OnMenuClick(reportCategoryId) {
    showLoadingCursor();
    $('#hdn_reportid_page').val(reportCategoryId);
    sessionStorage.setItem("ReportId", reportCategoryId);
    window.location.href = "../Home/Home";
    return false;
}