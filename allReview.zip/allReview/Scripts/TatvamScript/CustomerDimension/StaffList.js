﻿//string constants used for this module
var staffListConstants = {
    elementIDConstant: {
        treeViewID: "#treeview"
    },
    columnValues:
        {
            countOfPositiveReviews: "countOfPositiveReviews",
            countOfNegativeReviews: "countOfNegativeReviews",
            countOfNeutralReviews: "countOfNeutralReviews"
        },
    columnHeaders:
        {
            PositiveReviews: "Positive Reviews",
            NegativeReviews: "Negative Reviews",
            NeutralReviews: "Neutral Reviews",
            Departments: "Departments"
        },
    states: {
        opened: "opened"
    },
    columnWidth:
        {
            width: 130,
            auto: 'auto'
        },
    messages: {
        noDataAvailable: "<div class=\'nodata\'>No Data Available.</div>",
    },
    treeConfig: {
        state: "state"
    }
}
//on document ready, following steps are executed
$(document).ready(function () {
  
    //To-Do: Need to review the code
    var staffListArr = [];
    //iterate the model and include it an array
    for (var i = 0; i < staffListModel.length; i++) {
        //method to set state 'open' so that base node expands to first level        
        setObjProp(staffListModel[i], staffListConstants.treeConfig.state, staffListConstants.states.opened, true);        
        staffListArr.push(staffListModel[i]);
    }
    //call method to display treetable
    DisplayTreeView(staffListArr);
});

//Fucntion for displaying the details of the deparments and their staff.
function DisplayTreeView(treeData) {
    //check for treedata length, if no data then display no data message.
    if (treeData.length === 0) {
        $(staffListConstants.elementIDConstant.treeViewID).append(staffListConstants.messages.noDataAvailable);
        return;
    }
    //bind treedata with the needed jstree configuration like core, sort,table etc..
    $(staffListConstants.elementIDConstant.treeViewID)
        .jstree({
            "core": {
                "multiple": false,
                'data': treeData //Data Binded to tree
            },
            "plugins":
            [
                , "sort" //automatically arranges all sibling nodes defaults to alphabetical order.
                , "table" //For creating a table 
            ],
            // configure tree table
            table: {
                columns: [
                    {
                        //width defines column width of treetable
                        width: staffListConstants.columnWidth.auto,
                        header: staffListConstants.columnHeaders.Departments,
                    },

                    {
                        //width defines column width of treetable
                        width: staffListConstants.columnWidth.width,
                        //the attribute on the node to use as the value for this cell - entered as the text. Must be a string, number, boolean or other primitive.
                        //this is the value to bind to the header
                        value: staffListConstants.columnValues.countOfPositiveReviews,
                        // string to use as a header for the column like "Positive Reviews"
                        header: staffListConstants.columnHeaders.PositiveReviews,
                    },

                    {   //width defines column width of treetable
                        width: staffListConstants.columnWidth.width,
                        //the attribute on the node to use as the value for this cell - entered as the text. Must be a string, number, boolean or other primitive.
                        //this is the value to bind to the header
                        value: staffListConstants.columnValues.countOfNegativeReviews,
                        // string to use as a header for the column lke "Negative Reviews"
                        header: staffListConstants.columnHeaders.NegativeReviews,

                    },
                    {   //width defines column width of treetable
                        width: staffListConstants.columnWidth.width,
                        //the attribute on the node to use as the value for this cell - entered as the text. Must be a string, number, boolean or other primitive.
                        //this is the value to bind to the header
                        value: staffListConstants.columnValues.countOfNeutralReviews,
                        // string to use as a header for the column lke "Neutral Reviews"
                        header: staffListConstants.columnHeaders.NeutralReviews,

                    }

                ]

            }
        });
}






