const webpack = require('webpack');
const path = require('path');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

module.exports = (env, argv) => ({
  entry: './src/index.js',
  output: {
    filename: 'main.js',
    path: path.resolve(__dirname, 'dist')
  },
  optimization: {
    minimizer: argv.mode === 'production' ? [
      new UglifyJsPlugin({
        cache: true,
        parallel: true,
        sourceMap: true // set to true if you want JS source maps
      }),
      new OptimizeCSSAssetsPlugin({})
    ] : [],
  },
  module: {
    rules: [
      {
        test: /\.?js$/,
        exclude: /(node_modules|bower_components)/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env']
          }
        }
      },
      {
        test: /\.(scss)$/,
        use: [
          {
            loader: argv.mode !== 'production' ? 'style-loader' : MiniCssExtractPlugin.loader, // inject CSS to page
          },
          {
            loader: 'css-loader', // translates CSS into CommonJS modules
          }, {
            loader: 'postcss-loader', // Run post css actions
            options: {
              plugins: function () { // post css plugins, can be exported to postcss.config.js
                return [
                  require('precss'),
                  require('autoprefixer')
                ];
              }
            }
          }, {
            loader: 'sass-loader' // compiles Sass to CSS
          },
        ]
      },
      {
        test: /\.hbs/,
        loader: 'handlebars-loader',
      },
      {
        test: /\.(png|jpg|gif|svg)$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              outputPath: 'assets/images',
              publicPath: argv.mode === 'production' ? '../images' : 'assets/images',
            },
          },
        ],
      },
      {
        test: /\.(eot|woff|woff2|svg|ttf)([\?]?.*)$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              outputPath: 'assets/fonts',
              publicPath: argv.mode === 'production' ? '../fonts' : 'assets/fonts',
            },
          },
        ],
      },
          {
            test: /\.css$/,
            use: ['style-loader', 'css-loader']
          }

     ],
  },
  devServer: {
    contentBase: path.join(__dirname, 'dist'),
    compress: true,
    port: 3000,
    inline: true,
  },
  plugins: [
    new CleanWebpackPlugin(['dist', 'dist.zip']),
    new MiniCssExtractPlugin({
       filename: "assets/css/[name].css",
       chunkFilename: "assets/css/[id].css"
    }),
    new HtmlWebpackPlugin({
      title: 'GoVictor - Home',
      filename: 'index.html',
      template: 'src/templates/index.hbs',
    }),
    new HtmlWebpackPlugin({
      title: 'GoVictor - Product offerings',
      filename: 'product-offerings.html',
      template: 'src/templates/product-offerings.hbs',
    }),
       new HtmlWebpackPlugin({
         title: 'GoVictor - About Us',
      filename: 'about-us.html',
      template: 'src/templates/about-us.hbs',
    }),
    new HtmlWebpackPlugin({
      title: 'GoVictor - Terms of use',
      filename: 'terms-of-use.html',
      template: 'src/templates/terms-of-use.hbs',
    }),
    new HtmlWebpackPlugin({
      title: 'GoVictor - Privacy policy',
      filename: 'privacy-policy.html',
      template: 'src/templates/privacy-policy.hbs',
    }),
    new CopyWebpackPlugin([
      { from: 'src/assets/images', to: 'assets/images' }
    ]),
    new webpack.HotModuleReplacementPlugin(),
  ],
});
