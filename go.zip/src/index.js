import $ from "jquery";
import "bootstrap/dist/css/bootstrap.min.css";
import "./assets/js/typeahead";
import Bloodhound from "bloodhound-js"
import "./assets/scss/main.scss";
import "bootstrap/dist/js/bootstrap"

let timer = null;
let industry = [
  {
    "NAICS": 111110,
    "Description": "Soybean Farming"
  },
  {
    "NAICS": 111120,
    "Description": "Oilseed (except Soybean) Farming"
  },
  {
    "NAICS": 111130,
    "Description": "Dry Pea and Bean Farming"
  },
  {
    "NAICS": 111140,
    "Description": "Wheat Farming"
  },
  {
    "NAICS": 111150,
    "Description": "Corn Farming"
  },
  {
    "NAICS": 111160,
    "Description": "Rice Farming"
  },
  {
    "NAICS": 111191,
    "Description": "Oilseed and Grain Combination Farming"
  },
  {
    "NAICS": 111199,
    "Description": "All Other Grain Farming"
  },
  {
    "NAICS": 111211,
    "Description": "Potato Farming"
  },
  {
    "NAICS": 111219,
    "Description": "Other Vegetable (except Potato) and Melon Farming"
  },
  {
    "NAICS": 111310,
    "Description": "Orange Groves"
  },
  {
    "NAICS": 111320,
    "Description": "Citrus (except Orange) Groves"
  },
  {
    "NAICS": 111331,
    "Description": "Apple Orchards"
  },
  {
    "NAICS": 111332,
    "Description": "Grape Vineyards"
  },
  {
    "NAICS": 111333,
    "Description": "Strawberry Farming"
  },
  {
    "NAICS": 111334,
    "Description": "Berry (except Strawberry) Farming"
  },
  {
    "NAICS": 111335,
    "Description": "Tree Nut Farming"
  },
  {
    "NAICS": 111336,
    "Description": "Fruit and Tree Nut Combination Farming"
  },
  {
    "NAICS": 111339,
    "Description": "Other Noncitrus Fruit Farming"
  },
  {
    "NAICS": 111411,
    "Description": "Mushroom Production"
  },
  {
    "NAICS": 111419,
    "Description": "Other Food Crops Grown Under Cover"
  },
  {
    "NAICS": 111421,
    "Description": "Nursery and Tree Production"
  },
  {
    "NAICS": 111422,
    "Description": "Floriculture Production"
  },
  {
    "NAICS": 111910,
    "Description": "Tobacco Farming"
  },
  {
    "NAICS": 111920,
    "Description": "Cotton Farming"
  },
  {
    "NAICS": 111930,
    "Description": "Sugarcane Farming"
  },
  {
    "NAICS": 111940,
    "Description": "Hay Farming"
  },
  {
    "NAICS": 111991,
    "Description": "Sugar Beet Farming"
  },
  {
    "NAICS": 111992,
    "Description": "Peanut Farming"
  },
  {
    "NAICS": 111998,
    "Description": "All Other Miscellaneous Crop Farming"
  },
  {
    "NAICS": 112111,
    "Description": "Beef Cattle Ranching and Farming"
  },
  {
    "NAICS": 112112,
    "Description": "Cattle Feedlots"
  },
  {
    "NAICS": 112120,
    "Description": "Dairy Cattle and Milk Production"
  },
  {
    "NAICS": 112130,
    "Description": "Dual-Purpose Cattle Ranching and Farming"
  },
  {
    "NAICS": 112210,
    "Description": "Hog and Pig Farming"
  },
  {
    "NAICS": 112310,
    "Description": "Chicken Egg Production"
  },
  {
    "NAICS": 112320,
    "Description": "Broilers and Other Meat Type Chicken Production"
  },
  {
    "NAICS": 112330,
    "Description": "Turkey Production"
  },
  {
    "NAICS": 112340,
    "Description": "Poultry Hatcheries"
  },
  {
    "NAICS": 112390,
    "Description": "Other Poultry Production"
  },
  {
    "NAICS": 112410,
    "Description": "Sheep Farming"
  },
  {
    "NAICS": 112420,
    "Description": "Goat Farming"
  },
  {
    "NAICS": 112511,
    "Description": "Finfish Farming and Fish Hatcheries"
  },
  {
    "NAICS": 112512,
    "Description": "Shellfish Farming"
  },
  {
    "NAICS": 112519,
    "Description": "Other Aquaculture"
  },
  {
    "NAICS": 112910,
    "Description": "Apiculture"
  },
  {
    "NAICS": 112920,
    "Description": "Horses and Other Equine Production"
  },
  {
    "NAICS": 112930,
    "Description": "Fur-Bearing Animal and Rabbit Production"
  },
  {
    "NAICS": 112990,
    "Description": "All Other Animal Production"
  },
  {
    "NAICS": 113110,
    "Description": "Timber Tract Operations"
  },
  {
    "NAICS": 113210,
    "Description": "Forest Nurseries and Gathering of Forest Products"
  },
  {
    "NAICS": 113310,
    "Description": "Logging"
  },
  {
    "NAICS": 114111,
    "Description": "Finfish Fishing"
  },
  {
    "NAICS": 114112,
    "Description": "Shellfish Fishing"
  },
  {
    "NAICS": 114119,
    "Description": "Other Marine Fishing"
  },
  {
    "NAICS": 114210,
    "Description": "Hunting and Trapping"
  },
  {
    "NAICS": 115111,
    "Description": "Cotton Ginning"
  },
  {
    "NAICS": 115112,
    "Description": "Soil Preparation, Planting, and Cultivating"
  },
  {
    "NAICS": 115113,
    "Description": "Crop Harvesting, Primarily by Machine"
  },
  {
    "NAICS": 115114,
    "Description": "Postharvest Crop Activities (except Cotton Ginning)"
  },
  {
    "NAICS": 115115,
    "Description": "Farm Labor Contractors and Crew Leaders"
  },
  {
    "NAICS": 115116,
    "Description": "Farm Management Services"
  },
  {
    "NAICS": 115210,
    "Description": "Support Activities for Animal Production"
  },
  {
    "NAICS": 115310,
    "Description": "Support Activities for Forestry"
  },
  {
    "NAICS": 211120,
    "Description": "Crude Petroleum Extraction"
  },
  {
    "NAICS": 211130,
    "Description": "Natural Gas Extraction"
  },
  {
    "NAICS": 211130,
    "Description": "Natural Gas Extraction"
  },
  {
    "NAICS": 212111,
    "Description": "Bituminous Coal and Lignite Surface Mining"
  },
  {
    "NAICS": 212112,
    "Description": "Bituminous Coal Underground Mining"
  },
  {
    "NAICS": 212113,
    "Description": "Anthracite Mining"
  },
  {
    "NAICS": 212210,
    "Description": "Iron Ore Mining"
  },
  {
    "NAICS": 212221,
    "Description": "Gold Ore Mining"
  },
  {
    "NAICS": 212222,
    "Description": "Silver Ore Mining"
  },
  {
    "NAICS": 212230,
    "Description": "Copper, Nickel, Lead, and Zinc Mining"
  },
  {
    "NAICS": 212230,
    "Description": "Copper, Nickel, Lead, and Zinc Mining"
  },
  {
    "NAICS": 212291,
    "Description": "Uranium-Radium-Vanadium Ore Mining"
  },
  {
    "NAICS": 212299,
    "Description": "All Other Metal Ore Mining"
  },
  {
    "NAICS": 212311,
    "Description": "Dimension Stone Mining and Quarrying"
  },
  {
    "NAICS": 212312,
    "Description": "Crushed and Broken Limestone Mining and Quarrying"
  },
  {
    "NAICS": 212313,
    "Description": "Crushed and Broken Granite Mining and Quarrying"
  },
  {
    "NAICS": 212319,
    "Description": "Other Crushed and Broken Stone Mining and Quarrying"
  },
  {
    "NAICS": 212321,
    "Description": "Construction Sand and Gravel Mining"
  },
  {
    "NAICS": 212322,
    "Description": "Industrial Sand Mining"
  },
  {
    "NAICS": 212324,
    "Description": "Kaolin and Ball Clay Mining"
  },
  {
    "NAICS": 212325,
    "Description": "Clay and Ceramic and Refractory Minerals Mining"
  },
  {
    "NAICS": 212391,
    "Description": "Potash, Soda, and Borate Mineral Mining"
  },
  {
    "NAICS": 212392,
    "Description": "Phosphate Rock Mining"
  },
  {
    "NAICS": 212393,
    "Description": "Other Chemical and Fertilizer Mineral Mining"
  },
  {
    "NAICS": 212399,
    "Description": "All Other Nonmetallic Mineral Mining"
  },
  {
    "NAICS": 213111,
    "Description": "Drilling Oil and Gas Wells"
  },
  {
    "NAICS": 213112,
    "Description": "Support Activities for Oil and Gas Operations"
  },
  {
    "NAICS": 213113,
    "Description": "Support Activities for Coal Mining"
  },
  {
    "NAICS": 213114,
    "Description": "Support Activities for Metal Mining"
  },
  {
    "NAICS": 213115,
    "Description": "Support Activities for Nonmetallic Minerals (except Fuels) Mining"
  },
  {
    "NAICS": 221111,
    "Description": "Hydroelectric Power Generation"
  },
  {
    "NAICS": 221112,
    "Description": "Fossil Fuel Electric Power Generation"
  },
  {
    "NAICS": 221113,
    "Description": "Nuclear Electric Power Generation"
  },
  {
    "NAICS": 221114,
    "Description": "Solar Electric Power Generation"
  },
  {
    "NAICS": 221115,
    "Description": "Wind Electric Power Generation"
  },
  {
    "NAICS": 221116,
    "Description": "Geothermal Electric Power Generation"
  },
  {
    "NAICS": 221117,
    "Description": "Biomass Electric Power Generation"
  },
  {
    "NAICS": 221118,
    "Description": "Other Electric Power Generation"
  },
  {
    "NAICS": 221121,
    "Description": "Electric Bulk Power Transmission and Control"
  },
  {
    "NAICS": 221122,
    "Description": "Electric Power Distribution"
  },
  {
    "NAICS": 221210,
    "Description": "Natural Gas Distribution"
  },
  {
    "NAICS": 221310,
    "Description": "Water Supply and Irrigation Systems"
  },
  {
    "NAICS": 221320,
    "Description": "Sewage Treatment Facilities"
  },
  {
    "NAICS": 221330,
    "Description": "Steam and Air-Conditioning Supply"
  },
  {
    "NAICS": 236115,
    "Description": "New Single-Family Housing Construction (except For-Sale Builders)"
  },
  {
    "NAICS": 236116,
    "Description": "New Multifamily Housing Construction (except For-Sale Builders)"
  },
  {
    "NAICS": 236117,
    "Description": "New Housing For-Sale Builders"
  },
  {
    "NAICS": 236118,
    "Description": "Residential Remodelers"
  },
  {
    "NAICS": 236210,
    "Description": "Industrial Building Construction"
  },
  {
    "NAICS": 236220,
    "Description": "Commercial and Institutional Building Construction"
  },
  {
    "NAICS": 237110,
    "Description": "Water and Sewer Line and Related Structures Construction"
  },
  {
    "NAICS": 237120,
    "Description": "Oil and Gas Pipeline and Related Structures Construction"
  },
  {
    "NAICS": 237130,
    "Description": "Power and Communication Line and Related Structures Construction"
  },
  {
    "NAICS": 237210,
    "Description": "Land Subdivision"
  },
  {
    "NAICS": 237310,
    "Description": "Highway, Street, and Bridge Construction"
  },
  {
    "NAICS": 237990,
    "Description": "Other Heavy and Civil Engineering Construction"
  },
  {
    "NAICS": 238110,
    "Description": "Poured Concrete Foundation and Structure Contractors"
  },
  {
    "NAICS": 238120,
    "Description": "Structural Steel and Precast Concrete Contractors"
  },
  {
    "NAICS": 238130,
    "Description": "Framing Contractors"
  },
  {
    "NAICS": 238140,
    "Description": "Masonry Contractors"
  },
  {
    "NAICS": 238150,
    "Description": "Glass and Glazing Contractors"
  },
  {
    "NAICS": 238160,
    "Description": "Roofing Contractors"
  },
  {
    "NAICS": 238170,
    "Description": "Siding Contractors"
  },
  {
    "NAICS": 238190,
    "Description": "Other Foundation, Structure, and Building Exterior Contractors"
  },
  {
    "NAICS": 238210,
    "Description": "Electrical Contractors and Other Wiring Installation Contractors"
  },
  {
    "NAICS": 238220,
    "Description": "Plumbing, Heating, and Air-Conditioning Contractors"
  },
  {
    "NAICS": 238290,
    "Description": "Other Building Equipment Contractors"
  },
  {
    "NAICS": 238310,
    "Description": "Drywall and Insulation Contractors"
  },
  {
    "NAICS": 238320,
    "Description": "Painting and Wall Covering Contractors"
  },
  {
    "NAICS": 238330,
    "Description": "Flooring Contractors"
  },
  {
    "NAICS": 238340,
    "Description": "Tile and Terrazzo Contractors"
  },
  {
    "NAICS": 238350,
    "Description": "Finish Carpentry Contractors"
  },
  {
    "NAICS": 238390,
    "Description": "Other Building Finishing Contractors"
  },
  {
    "NAICS": 238910,
    "Description": "Site Preparation Contractors"
  },
  {
    "NAICS": 238990,
    "Description": "All Other Specialty Trade Contractors"
  },
  {
    "NAICS": 311111,
    "Description": "Dog and Cat Food Manufacturing"
  },
  {
    "NAICS": 311119,
    "Description": "Other Animal Food Manufacturing"
  },
  {
    "NAICS": 311211,
    "Description": "Flour Milling"
  },
  {
    "NAICS": 311212,
    "Description": "Rice Milling"
  },
  {
    "NAICS": 311213,
    "Description": "Malt Manufacturing"
  },
  {
    "NAICS": 311221,
    "Description": "Wet Corn Milling"
  },
  {
    "NAICS": 311224,
    "Description": "Soybean and Other Oilseed Processing"
  },
  {
    "NAICS": 311225,
    "Description": "Fats and Oils Refining and Blending"
  },
  {
    "NAICS": 311230,
    "Description": "Breakfast Cereal Manufacturing"
  },
  {
    "NAICS": 311313,
    "Description": "Beet Sugar Manufacturing"
  },
  {
    "NAICS": 311314,
    "Description": "Cane Sugar Manufacturing"
  },
  {
    "NAICS": 311340,
    "Description": "Nonchocolate Confectionery Manufacturing"
  },
  {
    "NAICS": 311351,
    "Description": "Chocolate and Confectionery Manufacturing from Cacao Beans"
  },
  {
    "NAICS": 311352,
    "Description": "Confectionery Manufacturing from Purchased Chocolate"
  },
  {
    "NAICS": 311411,
    "Description": "Frozen Fruit, Juice, and Vegetable Manufacturing"
  },
  {
    "NAICS": 311412,
    "Description": "Frozen Specialty Food Manufacturing"
  },
  {
    "NAICS": 311421,
    "Description": "Fruit and Vegetable Canning"
  },
  {
    "NAICS": 311422,
    "Description": "Specialty Canning"
  },
  {
    "NAICS": 311423,
    "Description": "Dried and Dehydrated Food Manufacturing"
  },
  {
    "NAICS": 311511,
    "Description": "Fluid Milk Manufacturing"
  },
  {
    "NAICS": 311512,
    "Description": "Creamery Butter Manufacturing"
  },
  {
    "NAICS": 311513,
    "Description": "Cheese Manufacturing"
  },
  {
    "NAICS": 311514,
    "Description": "Dry, Condensed, and Evaporated Dairy Product Manufacturing"
  },
  {
    "NAICS": 311520,
    "Description": "Ice Cream and Frozen Dessert Manufacturing"
  },
  {
    "NAICS": 311611,
    "Description": "Animal (except Poultry) Slaughtering"
  },
  {
    "NAICS": 311612,
    "Description": "Meat Processed from Carcasses"
  },
  {
    "NAICS": 311613,
    "Description": "Rendering and Meat Byproduct Processing"
  },
  {
    "NAICS": 311615,
    "Description": "Poultry Processing"
  },
  {
    "NAICS": 311710,
    "Description": "Seafood Product Preparation and Packaging"
  },
  {
    "NAICS": 311811,
    "Description": "Retail Bakeries"
  },
  {
    "NAICS": 311812,
    "Description": "Commercial Bakeries"
  },
  {
    "NAICS": 311813,
    "Description": "Frozen Cakes, Pies, and Other Pastries Manufacturing"
  },
  {
    "NAICS": 311821,
    "Description": "Cookie and Cracker Manufacturing"
  },
  {
    "NAICS": 311824,
    "Description": "Dry Pasta, Dough, and Flour Mixes Manufacturing from Purchased Flour"
  },
  {
    "NAICS": 311830,
    "Description": "Tortilla Manufacturing"
  },
  {
    "NAICS": 311911,
    "Description": "Roasted Nuts and Peanut Butter Manufacturing"
  },
  {
    "NAICS": 311919,
    "Description": "Other Snack Food Manufacturing"
  },
  {
    "NAICS": 311920,
    "Description": "Coffee and Tea Manufacturing"
  },
  {
    "NAICS": 311930,
    "Description": "Flavoring Syrup and Concentrate Manufacturing"
  },
  {
    "NAICS": 311941,
    "Description": "Mayonnaise, Dressing, and Other Prepared Sauce Manufacturing"
  },
  {
    "NAICS": 311942,
    "Description": "Spice and Extract Manufacturing"
  },
  {
    "NAICS": 311991,
    "Description": "Perishable Prepared Food Manufacturing"
  },
  {
    "NAICS": 311999,
    "Description": "All Other Miscellaneous Food Manufacturing"
  },
  {
    "NAICS": 312111,
    "Description": "Soft Drink Manufacturing"
  },
  {
    "NAICS": 312112,
    "Description": "Bottled Water Manufacturing"
  },
  {
    "NAICS": 312113,
    "Description": "Ice Manufacturing"
  },
  {
    "NAICS": 312120,
    "Description": "Breweries"
  },
  {
    "NAICS": 312130,
    "Description": "Wineries"
  },
  {
    "NAICS": 312140,
    "Description": "Distilleries"
  },
  {
    "NAICS": 312230,
    "Description": "Tobacco Manufacturing"
  },
  {
    "NAICS": 313110,
    "Description": "Fiber, Yarn, and Thread Mills"
  },
  {
    "NAICS": 313210,
    "Description": "Broadwoven Fabric Mills"
  },
  {
    "NAICS": 313220,
    "Description": "Narrow Fabric Mills and Schiffli Machine Embroidery"
  },
  {
    "NAICS": 313230,
    "Description": "Nonwoven Fabric Mills"
  },
  {
    "NAICS": 313240,
    "Description": "Knit Fabric Mills"
  },
  {
    "NAICS": 313310,
    "Description": "Textile and Fabric Finishing Mills"
  },
  {
    "NAICS": 313320,
    "Description": "Fabric Coating Mills"
  },
  {
    "NAICS": 314110,
    "Description": "Carpet and Rug Mills"
  },
  {
    "NAICS": 314120,
    "Description": "Curtain and Linen Mills"
  },
  {
    "NAICS": 314910,
    "Description": "Textile Bag and Canvas Mills"
  },
  {
    "NAICS": 314994,
    "Description": "Rope, Cordage, Twine, Tire Cord, and Tire Fabric Mills"
  },
  {
    "NAICS": 314999,
    "Description": "All Other Miscellaneous Textile Product Mills"
  },
  {
    "NAICS": 315110,
    "Description": "Hosiery and Sock Mills"
  },
  {
    "NAICS": 315190,
    "Description": "Other Apparel Knitting Mills"
  },
  {
    "NAICS": 315210,
    "Description": "Cut and Sew Apparel Contractors"
  },
  {
    "NAICS": 315220,
    "Description": "Men's and Boys' Cut and Sew Apparel Manufacturing"
  },
  {
    "NAICS": 315240,
    "Description": "Women's, Girls', and Infants' Cut and Sew Apparel Manufacturing"
  },
  {
    "NAICS": 315280,
    "Description": "Other Cut and Sew Apparel Manufacturing"
  },
  {
    "NAICS": 315990,
    "Description": "Apparel Accessories and Other Apparel Manufacturing"
  },
  {
    "NAICS": 316110,
    "Description": "Leather and Hide Tanning and Finishing"
  },
  {
    "NAICS": 316210,
    "Description": "Footwear Manufacturing"
  },
  {
    "NAICS": 316992,
    "Description": "Women's Handbag and Purse Manufacturing"
  },
  {
    "NAICS": 316998,
    "Description": "All Other Leather Good and Allied Product Manufacturing"
  },
  {
    "NAICS": 321113,
    "Description": "Sawmills"
  },
  {
    "NAICS": 321114,
    "Description": "Wood Preservation"
  },
  {
    "NAICS": 321211,
    "Description": "Hardwood Veneer and Plywood Manufacturing"
  },
  {
    "NAICS": 321212,
    "Description": "Softwood Veneer and Plywood Manufacturing"
  },
  {
    "NAICS": 321213,
    "Description": "Engineered Wood Member (except Truss) Manufacturing"
  },
  {
    "NAICS": 321214,
    "Description": "Truss Manufacturing"
  },
  {
    "NAICS": 321219,
    "Description": "Reconstituted Wood Product Manufacturing"
  },
  {
    "NAICS": 321911,
    "Description": "Wood Window and Door Manufacturing"
  },
  {
    "NAICS": 321912,
    "Description": "Cut Stock, Resawing Lumber, and Planing"
  },
  {
    "NAICS": 321918,
    "Description": "Other Millwork (including Flooring)"
  },
  {
    "NAICS": 321920,
    "Description": "Wood Container and Pallet Manufacturing"
  },
  {
    "NAICS": 321991,
    "Description": "Manufactured Home (Mobile Home) Manufacturing"
  },
  {
    "NAICS": 321992,
    "Description": "Prefabricated Wood Building Manufacturing"
  },
  {
    "NAICS": 321999,
    "Description": "All Other Miscellaneous Wood Product Manufacturing"
  },
  {
    "NAICS": 322110,
    "Description": "Pulp Mills"
  },
  {
    "NAICS": 322121,
    "Description": "Paper (except Newsprint) Mills"
  },
  {
    "NAICS": 322122,
    "Description": "Newsprint Mills"
  },
  {
    "NAICS": 322130,
    "Description": "Paperboard Mills"
  },
  {
    "NAICS": 322211,
    "Description": "Corrugated and Solid Fiber Box Manufacturing"
  },
  {
    "NAICS": 322212,
    "Description": "Folding Paperboard Box Manufacturing"
  },
  {
    "NAICS": 322219,
    "Description": "Other Paperboard Container Manufacturing"
  },
  {
    "NAICS": 322220,
    "Description": "Paper Bag and Coated and Treated Paper Manufacturing"
  },
  {
    "NAICS": 322230,
    "Description": "Stationery Product Manufacturing"
  },
  {
    "NAICS": 322291,
    "Description": "Sanitary Paper Product Manufacturing"
  },
  {
    "NAICS": 322299,
    "Description": "All Other Converted Paper Product Manufacturing"
  },
  {
    "NAICS": 323111,
    "Description": "Commercial Printing (except Screen and Books)"
  },
  {
    "NAICS": 323113,
    "Description": "Commercial Screen Printing"
  },
  {
    "NAICS": 323117,
    "Description": "Books Printing"
  },
  {
    "NAICS": 323120,
    "Description": "Support Activites for Printing"
  },
  {
    "NAICS": 324110,
    "Description": "Petroleum Refineries"
  },
  {
    "NAICS": 324121,
    "Description": "Asphalt Paving Mixture and Block Manufacturing"
  },
  {
    "NAICS": 324122,
    "Description": "Asphalt Shingle and Coating Materials Manufacturing"
  },
  {
    "NAICS": 324191,
    "Description": "Petroleum Lubricating Oil and Grease Manufacturing"
  },
  {
    "NAICS": 324199,
    "Description": "All Other Petroleum and Coal Products Manufacturing"
  },
  {
    "NAICS": 325110,
    "Description": "Petrochemical Manufacturing"
  },
  {
    "NAICS": 325120,
    "Description": "Industrial Gas Manufacturing"
  },
  {
    "NAICS": 325130,
    "Description": "Synthetic Dye and Pigment Manufacturing"
  },
  {
    "NAICS": 325180,
    "Description": "Other Basic Inorganic Chemical Manufacturing"
  },
  {
    "NAICS": 325193,
    "Description": "Ethyl Alcohol Manufacturing"
  },
  {
    "NAICS": 325194,
    "Description": "Cyclic Crude, Intermediate, and Gum and Wood Chemical Manufacturing"
  },
  {
    "NAICS": 325199,
    "Description": "All Other Basic Organic Chemical Manufacturing"
  },
  {
    "NAICS": 325211,
    "Description": "Plastics Material and Resin Manufacturing"
  },
  {
    "NAICS": 325212,
    "Description": "Synthetic Rubber Manufacturing"
  },
  {
    "NAICS": 325220,
    "Description": "Artificial and Synthetic Fibers and Filaments Manufacturing"
  },
  {
    "NAICS": 325311,
    "Description": "Nitrogenous Fertilizer Manufacturing"
  },
  {
    "NAICS": 325312,
    "Description": "Phosphatic Fertilizer Manufacturing"
  },
  {
    "NAICS": 325314,
    "Description": "Fertilizer (Mixing Only) Manufacturing"
  },
  {
    "NAICS": 325320,
    "Description": "Pesticide and Other Agricultural Chemical Manufacturing"
  },
  {
    "NAICS": 325411,
    "Description": "Medicinal and Botanical Manufacturing"
  },
  {
    "NAICS": 325412,
    "Description": "Pharmaceutical Preparation Manufacturing"
  },
  {
    "NAICS": 325413,
    "Description": "In-Vitro Diagnostic Substance Manufacturing"
  },
  {
    "NAICS": 325414,
    "Description": "Biological Product (except Diagnostic) Manufacturing"
  },
  {
    "NAICS": 325510,
    "Description": "Paint and Coating Manufacturing"
  },
  {
    "NAICS": 325520,
    "Description": "Adhesive Manufacturing"
  },
  {
    "NAICS": 325611,
    "Description": "Soap and Other Detergent Manufacturing"
  },
  {
    "NAICS": 325612,
    "Description": "Polish and Other Sanitation Good Manufacturing"
  },
  {
    "NAICS": 325613,
    "Description": "Surface Active Agent Manufacturing"
  },
  {
    "NAICS": 325620,
    "Description": "Toilet Preparation Manufacturing"
  },
  {
    "NAICS": 325910,
    "Description": "Printing Ink Manufacturing"
  },
  {
    "NAICS": 325920,
    "Description": "Explosives Manufacturing"
  },
  {
    "NAICS": 325991,
    "Description": "Custom Compounding of Purchased Resins"
  },
  {
    "NAICS": 325992,
    "Description": "Photographic Film, Paper, Plate, and Chemical Manufacturing"
  },
  {
    "NAICS": 325998,
    "Description": "All Other Miscellaneous Chemical Product and Preparation Manufacturing"
  },
  {
    "NAICS": 326111,
    "Description": "Plastics Bag and Pouch Manufacturing"
  },
  {
    "NAICS": 326112,
    "Description": "Plastics Packaging Film and Sheet (including Laminated) Manufacturing"
  },
  {
    "NAICS": 326113,
    "Description": "Unlaminated Plastics Film and Sheet (except Packaging) Manufacturing"
  },
  {
    "NAICS": 326121,
    "Description": "Unlaminated Plastics Profile Shape Manufacturing"
  },
  {
    "NAICS": 326122,
    "Description": "Plastics Pipe and Pipe Fitting Manufacturing"
  },
  {
    "NAICS": 326130,
    "Description": "Laminated Plastics Plate, Sheet (except Packaging), and Shape Manufacturing"
  },
  {
    "NAICS": 326140,
    "Description": "Polystyrene Foam Product Manufacturing"
  },
  {
    "NAICS": 326150,
    "Description": "Urethane and Other Foam Product (except Polystyrene) Manufacturing"
  },
  {
    "NAICS": 326160,
    "Description": "Plastics Bottle Manufacturing"
  },
  {
    "NAICS": 326191,
    "Description": "Plastics Plumbing Fixture Manufacturing"
  },
  {
    "NAICS": 326199,
    "Description": "All Other Plastics Product Manufacturing"
  },
  {
    "NAICS": 326211,
    "Description": "Tire Manufacturing (except Retreading)"
  },
  {
    "NAICS": 326212,
    "Description": "Tire Retreading"
  },
  {
    "NAICS": 326220,
    "Description": "Rubber and Plastics Hoses and Belting Manufacturing"
  },
  {
    "NAICS": 326291,
    "Description": "Rubber Product Manufacturing for Mechanical Use"
  },
  {
    "NAICS": 326299,
    "Description": "All Other Rubber Product Manufacturing"
  },
  {
    "NAICS": 327110,
    "Description": "Pottery, Ceramics, and Plumbing Fixture Manufacturing"
  },
  {
    "NAICS": 327120,
    "Description": "Clay Building Material and Refractories Manufacturing"
  },
  {
    "NAICS": 327211,
    "Description": "Flat Glass Manufacturing"
  },
  {
    "NAICS": 327212,
    "Description": "Other Pressed and Blown Glass and Glassware Manufacturing"
  },
  {
    "NAICS": 327213,
    "Description": "Glass Container Manufacturing"
  },
  {
    "NAICS": 327215,
    "Description": "Glass Product Manufacturing Made of Purchased Glass"
  },
  {
    "NAICS": 327310,
    "Description": "Cement Manufacturing"
  },
  {
    "NAICS": 327320,
    "Description": "Ready-Mix Concrete Manufacturing"
  },
  {
    "NAICS": 327331,
    "Description": "Concrete Block and Brick Manufacturing"
  },
  {
    "NAICS": 327332,
    "Description": "Concrete Pipe Manufacturing"
  },
  {
    "NAICS": 327390,
    "Description": "Other Concrete Product Manufacturing"
  },
  {
    "NAICS": 327410,
    "Description": "Lime Manufacturing"
  },
  {
    "NAICS": 327420,
    "Description": "Gypsum Product Manufacturing"
  },
  {
    "NAICS": 327910,
    "Description": "Abrasive Product Manufacturing"
  },
  {
    "NAICS": 327991,
    "Description": "Cut Stone and Stone Product Manufacturing"
  },
  {
    "NAICS": 327992,
    "Description": "Ground or Treated Mineral and Earth Manufacturing"
  },
  {
    "NAICS": 327993,
    "Description": "Mineral Wool Manufacturing"
  },
  {
    "NAICS": 327999,
    "Description": "All Other Miscellaneous Nonmetallic Mineral Product Manufacturing"
  },
  {
    "NAICS": 331110,
    "Description": "Iron and Steel Mills and Ferroalloy Manufacturing"
  },
  {
    "NAICS": 331210,
    "Description": "Iron and Steel Pipe and Tube Manufacturing from Purchased Steel"
  },
  {
    "NAICS": 331221,
    "Description": "Rolled Steel Shape Manufacturing"
  },
  {
    "NAICS": 331222,
    "Description": "Steel Wire Drawing"
  },
  {
    "NAICS": 331313,
    "Description": "Alumina Refining and Primary Aluminum Production"
  },
  {
    "NAICS": 331314,
    "Description": "Secondary Smelting and Alloying of Aluminum"
  },
  {
    "NAICS": 331315,
    "Description": "Aluminum Sheet, Plate, and Foil Manufacturing"
  },
  {
    "NAICS": 331318,
    "Description": "Other Aluminum Rolling, Drawing, and Extruding"
  },
  {
    "NAICS": 331410,
    "Description": "Nonferrous Metal (except Aluminum) Smelting and Refining"
  },
  {
    "NAICS": 331420,
    "Description": "Copper Rolling, Drawing, Extruding, and Alloying"
  },
  {
    "NAICS": 331491,
    "Description": "Nonferrous Metal (except Copper and Aluminum) Rolling, Drawing, and Extruding"
  },
  {
    "NAICS": 331492,
    "Description": "Secondary Smelting, Refining, and Alloying of Nonferrous Metal (except Copper and Aluminum)"
  },
  {
    "NAICS": 331511,
    "Description": "Iron Foundries"
  },
  {
    "NAICS": 331512,
    "Description": "Steel Investment Foundries"
  },
  {
    "NAICS": 331513,
    "Description": "Steel Foundries (except Investment)"
  },
  {
    "NAICS": 331523,
    "Description": "Nonferrous Metal Die-Casting Foundries"
  },
  {
    "NAICS": 331524,
    "Description": "Aluminum Foundries (except Die-Casting)"
  },
  {
    "NAICS": 331529,
    "Description": "Other Nonferrous Metal Foundries (except Die-Casting)"
  },
  {
    "NAICS": 332111,
    "Description": "Iron and Steel Forging"
  },
  {
    "NAICS": 332112,
    "Description": "Nonferrous Forging"
  },
  {
    "NAICS": 332114,
    "Description": "Custom Roll Forming"
  },
  {
    "NAICS": 332117,
    "Description": "Powder Metallurgy Part Manufacturing"
  },
  {
    "NAICS": 332119,
    "Description": "Metal Crown, Closure, and Other Metal Stamping (except Automotive)"
  },
  {
    "NAICS": 332215,
    "Description": "Metal Kitchen Cookware, Utensil, Cutlery, and Flatware (except Precious) Manufacturing"
  },
  {
    "NAICS": 332216,
    "Description": "Saw Blade and Handtool Manufacturing"
  },
  {
    "NAICS": 332311,
    "Description": "Prefabricated Metal Building and Component Manufacturing"
  },
  {
    "NAICS": 332312,
    "Description": "Fabricated Structural Metal Manufacturing"
  },
  {
    "NAICS": 332313,
    "Description": "Plate Work Manufacturing"
  },
  {
    "NAICS": 332321,
    "Description": "Metal Window and Door Manufacturing"
  },
  {
    "NAICS": 332322,
    "Description": "Sheet Metal Work Manufacturing"
  },
  {
    "NAICS": 332323,
    "Description": "Ornamental and Architectural Metal Work Manufacturing"
  },
  {
    "NAICS": 332410,
    "Description": "Power Boiler and Heat Exchanger Manufacturing"
  },
  {
    "NAICS": 332420,
    "Description": "Metal Tank (Heavy Gauge) Manufacturing"
  },
  {
    "NAICS": 332431,
    "Description": "Metal Can Manufacturing"
  },
  {
    "NAICS": 332439,
    "Description": "Other Metal Container Manufacturing"
  },
  {
    "NAICS": 332510,
    "Description": "Hardware Manufacturing"
  },
  {
    "NAICS": 332613,
    "Description": "Spring Manufacturing"
  },
  {
    "NAICS": 332618,
    "Description": "Other Fabricated Wire Product Manufacturing"
  },
  {
    "NAICS": 332710,
    "Description": "Machine Shops"
  },
  {
    "NAICS": 332721,
    "Description": "Precision Turned Product Manufacturing"
  },
  {
    "NAICS": 332722,
    "Description": "Bolt, Nut, Screw, Rivet, and Washer Manufacturing"
  },
  {
    "NAICS": 332811,
    "Description": "Metal Heat Treating"
  },
  {
    "NAICS": 332812,
    "Description": "Metal Coating, Engraving (except Jewelry and Silverware), and Allied Services to Manufacturers"
  },
  {
    "NAICS": 332813,
    "Description": "Electroplating, Plating, Polishing, Anodizing, and Coloring"
  },
  {
    "NAICS": 332911,
    "Description": "Industrial Valve Manufacturing"
  },
  {
    "NAICS": 332912,
    "Description": "Fluid Power Valve and Hose Fitting Manufacturing"
  },
  {
    "NAICS": 332913,
    "Description": "Plumbing Fixture Fitting and Trim Manufacturing"
  },
  {
    "NAICS": 332919,
    "Description": "Other Metal Valve and Pipe Fitting Manufacturing"
  },
  {
    "NAICS": 332991,
    "Description": "Ball and Roller Bearing Manufacturing"
  },
  {
    "NAICS": 332992,
    "Description": "Small Arms Ammunition Manufacturing"
  },
  {
    "NAICS": 332993,
    "Description": "Ammunition (except Small Arms) Manufacturing"
  },
  {
    "NAICS": 332994,
    "Description": "Small Arms, Ordnance, and Ordnance Accessories Manufacturing"
  },
  {
    "NAICS": 332996,
    "Description": "Fabricated Pipe and Pipe Fitting Manufacturing"
  },
  {
    "NAICS": 332999,
    "Description": "All Other Miscellaneous Fabricated Metal Product Manufacturing"
  },
  {
    "NAICS": 333111,
    "Description": "Farm Machinery and Equipment Manufacturing"
  },
  {
    "NAICS": 333112,
    "Description": "Lawn and Garden Tractor and Home Lawn and Garden Equipment Manufacturing"
  },
  {
    "NAICS": 333120,
    "Description": "Construction Machinery Manufacturing"
  },
  {
    "NAICS": 333131,
    "Description": "Mining Machinery and Equipment Manufacturing"
  },
  {
    "NAICS": 333132,
    "Description": "Oil and Gas Field Machinery and Equipment Manufacturing"
  },
  {
    "NAICS": 333241,
    "Description": "Food Product Machinery Manufacturing"
  },
  {
    "NAICS": 333242,
    "Description": "Semiconductor Machinery Manufacturing"
  },
  {
    "NAICS": 333243,
    "Description": "Sawmill, Woodworking, and Paper Machinery Manufacturing"
  },
  {
    "NAICS": 333244,
    "Description": "Printing Machinery and Equipment Manufacturing"
  },
  {
    "NAICS": 333249,
    "Description": "Other Industrial Machinery Manufacturing"
  },
  {
    "NAICS": 333314,
    "Description": "Optical Instrument and Lens Manufacturing"
  },
  {
    "NAICS": 333316,
    "Description": "Photographic and Photocopying Equipment Manufacturing"
  },
  {
    "NAICS": 333318,
    "Description": "Other Commercial and Service Industry Machinery Manufacturing"
  },
  {
    "NAICS": 333413,
    "Description": "Industrial and Commercial Fan and Blower and Air Purification Equipment Manufacturing"
  },
  {
    "NAICS": 333414,
    "Description": "Heating Equipment (except Warm Air Furnaces) Manufacturing"
  },
  {
    "NAICS": 333415,
    "Description": "Air-Conditioning and Warm Air Heating Equipment and Commercial and Industrial Refrigeration Equipment Manufacturing"
  },
  {
    "NAICS": 333511,
    "Description": "Industrial Mold Manufacturing"
  },
  {
    "NAICS": 333514,
    "Description": "Special Die and Tool, Die Set, Jig, and Fixture Manufacturing"
  },
  {
    "NAICS": 333515,
    "Description": "Cutting Tool and Machine Tool Accessory Manufacturing"
  },
  {
    "NAICS": 333517,
    "Description": "Machine Tool Manufacturing"
  },
  {
    "NAICS": 333519,
    "Description": "Rolling Mill and Other Metalworking Machinery Manufacturing"
  },
  {
    "NAICS": 333611,
    "Description": "Turbine and Turbine Generator Set Units Manufacturing"
  },
  {
    "NAICS": 333612,
    "Description": "Speed Changer, Industrial High-Speed Drive, and Gear Manufacturing"
  },
  {
    "NAICS": 333613,
    "Description": "Mechanical Power Transmission Equipment Manufacturing"
  },
  {
    "NAICS": 333618,
    "Description": "Other Engine Equipment Manufacturing"
  },
  {
    "NAICS": 333912,
    "Description": "Air and Gas Compressor Manufacturing"
  },
  {
    "NAICS": 333914,
    "Description": "Measuring, Dispensing, and Other Pumping Equipment Manufacturing"
  },
  {
    "NAICS": 333914,
    "Description": "Measuring, Dispensing, and Other Pumping Equipment Manufacturing"
  },
  {
    "NAICS": 333921,
    "Description": "Elevator and Moving Stairway Manufacturing"
  },
  {
    "NAICS": 333922,
    "Description": "Conveyor and Conveying Equipment Manufacturing"
  },
  {
    "NAICS": 333923,
    "Description": "Overhead Traveling Crane, Hoist, and Monorail System Manufacturing"
  },
  {
    "NAICS": 333924,
    "Description": "Industrial Truck, Tractor, Trailer, and Stacker Machinery Manufacturing"
  },
  {
    "NAICS": 333991,
    "Description": "Power-Driven Handtool Manufacturing"
  },
  {
    "NAICS": 333992,
    "Description": "Welding and Soldering Equipment Manufacturing"
  },
  {
    "NAICS": 333993,
    "Description": "Packaging Machinery Manufacturing"
  },
  {
    "NAICS": 333994,
    "Description": "Industrial Process Furnace and Oven Manufacturing"
  },
  {
    "NAICS": 333995,
    "Description": "Fluid Power Cylinder and Actuator Manufacturing"
  },
  {
    "NAICS": 333996,
    "Description": "Fluid Power Pump and Motor Manufacturing"
  },
  {
    "NAICS": 333997,
    "Description": "Scale and Balance Manufacturing"
  },
  {
    "NAICS": 333999,
    "Description": "All Other Miscellaneous General Purpose Machinery Manufacturing"
  },
  {
    "NAICS": 334111,
    "Description": "Electronic Computer Manufacturing"
  },
  {
    "NAICS": 334112,
    "Description": "Computer Storage Device Manufacturing"
  },
  {
    "NAICS": 334118,
    "Description": "Computer Terminal and Other Computer Peripheral Equipment Manufacturing"
  },
  {
    "NAICS": 334210,
    "Description": "Telephone Apparatus Manufacturing"
  },
  {
    "NAICS": 334220,
    "Description": "Radio and Television Broadcasting and Wireless Communications Equipment Manufacturing"
  },
  {
    "NAICS": 334290,
    "Description": "Other Communications Equipment Manufacturing"
  },
  {
    "NAICS": 334310,
    "Description": "Audio and Video Equipment Manufacturing"
  },
  {
    "NAICS": 334412,
    "Description": "Bare Printed Circuit Board Manufacturing"
  },
  {
    "NAICS": 334413,
    "Description": "Semiconductor and Related Device Manufacturing"
  },
  {
    "NAICS": 334416,
    "Description": "Capacitor, Resistor, Coil, Transformer, and Other Inductor Manufacturing"
  },
  {
    "NAICS": 334417,
    "Description": "Electronic Connector Manufacturing"
  },
  {
    "NAICS": 334418,
    "Description": "Printed Circuit Assembly (Electronic Assembly) Manufacturing"
  },
  {
    "NAICS": 334419,
    "Description": "Other Electronic Component Manufacturing"
  },
  {
    "NAICS": 334510,
    "Description": "Electromedical and Electrotherapeutic Apparatus Manufacturing"
  },
  {
    "NAICS": 334511,
    "Description": "Search, Detection, Navigation, Guidance, Aeronautical, and Nautical System and Instrument Manufacturing"
  },
  {
    "NAICS": 334512,
    "Description": "Automatic Environmental Control Manufacturing for Residential, Commercial, and Appliance Use"
  },
  {
    "NAICS": 334513,
    "Description": "Instruments and Related Products Manufacturing for Measuring, Displaying, and Controlling Industrial Process Variables"
  },
  {
    "NAICS": 334514,
    "Description": "Totalizing Fluid Meter and Counting Device Manufacturing"
  },
  {
    "NAICS": 334515,
    "Description": "Instrument Manufacturing for Measuring and Testing Electricity and Electrical Signals"
  },
  {
    "NAICS": 334516,
    "Description": "Analytical Laboratory Instrument Manufacturing"
  },
  {
    "NAICS": 334517,
    "Description": "Irradiation Apparatus Manufacturing"
  },
  {
    "NAICS": 334519,
    "Description": "Other Measuring and Controlling Device Manufacturing"
  },
  {
    "NAICS": 334613,
    "Description": "Blank Magnetic and Optical Recording Media Manufacturing"
  },
  {
    "NAICS": 334614,
    "Description": "Software and Other Prerecorded Compact Disc, Tape, and Record Reproducing"
  },
  {
    "NAICS": 335110,
    "Description": "Electric Lamp Bulb and Part Manufacturing"
  },
  {
    "NAICS": 335121,
    "Description": "Residential Electric Lighting Fixture Manufacturing"
  },
  {
    "NAICS": 335122,
    "Description": "Commercial, Industrial, and Institutional Electric Lighting Fixture Manufacturing"
  },
  {
    "NAICS": 335129,
    "Description": "Other Lighting Equipment Manufacturing"
  },
  {
    "NAICS": 335210,
    "Description": "Small Electrical Appliance Manufacturing"
  },
  {
    "NAICS": 335220,
    "Description": "Major Household Appliance Manufacturing"
  },
  {
    "NAICS": 335220,
    "Description": "Major Household Appliance Manufacturing"
  },
  {
    "NAICS": 335220,
    "Description": "Major Household Appliance Manufacturing"
  },
  {
    "NAICS": 335220,
    "Description": "Major Household Appliance Manufacturing"
  },
  {
    "NAICS": 335311,
    "Description": "Power, Distribution, and Specialty Transformer Manufacturing"
  },
  {
    "NAICS": 335312,
    "Description": "Motor and Generator Manufacturing"
  },
  {
    "NAICS": 335313,
    "Description": "Switchgear and Switchboard Apparatus Manufacturing"
  },
  {
    "NAICS": 335314,
    "Description": "Relay and Industrial Control Manufacturing"
  },
  {
    "NAICS": 335911,
    "Description": "Storage Battery Manufacturing"
  },
  {
    "NAICS": 335912,
    "Description": "Primary Battery Manufacturing"
  },
  {
    "NAICS": 335921,
    "Description": "Fiber Optic Cable Manufacturing"
  },
  {
    "NAICS": 335929,
    "Description": "Other Communication and Energy Wire Manufacturing"
  },
  {
    "NAICS": 335931,
    "Description": "Current-Carrying Wiring Device Manufacturing"
  },
  {
    "NAICS": 335932,
    "Description": "Noncurrent-Carrying Wiring Device Manufacturing"
  },
  {
    "NAICS": 335991,
    "Description": "Carbon and Graphite Product Manufacturing"
  },
  {
    "NAICS": 335999,
    "Description": "All Other Miscellaneous Electrical Equipment and Component Manufacturing"
  },
  {
    "NAICS": 336111,
    "Description": "Automobile Manufacturing"
  },
  {
    "NAICS": 336112,
    "Description": "Light Truck and Utility Vehicle Manufacturing"
  },
  {
    "NAICS": 336120,
    "Description": "Heavy Duty Truck Manufacturing"
  },
  {
    "NAICS": 336211,
    "Description": "Motor Vehicle Body Manufacturing"
  },
  {
    "NAICS": 336212,
    "Description": "Truck Trailer Manufacturing"
  },
  {
    "NAICS": 336213,
    "Description": "Motor Home Manufacturing"
  },
  {
    "NAICS": 336214,
    "Description": "Travel Trailer and Camper Manufacturing"
  },
  {
    "NAICS": 336310,
    "Description": "Motor Vehicle Gasoline Engine and Engine Parts Manufacturing"
  },
  {
    "NAICS": 336320,
    "Description": "Motor Vehicle Electrical and Electronic Equipment Manufacturing"
  },
  {
    "NAICS": 336330,
    "Description": "Motor Vehicle Steering and Suspension Components (except Spring) Manufacturing"
  },
  {
    "NAICS": 336340,
    "Description": "Motor Vehicle Brake System Manufacturing"
  },
  {
    "NAICS": 336350,
    "Description": "Motor Vehicle Transmission and Power Train Parts Manufacturing"
  },
  {
    "NAICS": 336360,
    "Description": "Motor Vehicle Seating and Interior Trim Manufacturing"
  },
  {
    "NAICS": 336370,
    "Description": "Motor Vehicle Metal Stamping"
  },
  {
    "NAICS": 336390,
    "Description": "Other Motor Vehicle Parts Manufacturing"
  },
  {
    "NAICS": 336411,
    "Description": "Aircraft Manufacturing"
  },
  {
    "NAICS": 336412,
    "Description": "Aircraft Engine and Engine Parts Manufacturing"
  },
  {
    "NAICS": 336413,
    "Description": "Other Aircraft Parts and Auxiliary Equipment Manufacturing"
  },
  {
    "NAICS": 336414,
    "Description": "Guided Missile and Space Vehicle Manufacturing"
  },
  {
    "NAICS": 336415,
    "Description": "Guided Missile and Space Vehicle Propulsion Unit and Propulsion Unit Parts Manufacturing"
  },
  {
    "NAICS": 336419,
    "Description": "Other Guided Missile and Space Vehicle Parts and Auxiliary Equipment Manufacturing"
  },
  {
    "NAICS": 336510,
    "Description": "Railroad Rolling Stock Manufacturing"
  },
  {
    "NAICS": 336611,
    "Description": "Ship Building and Repairing"
  },
  {
    "NAICS": 336612,
    "Description": "Boat Building"
  },
  {
    "NAICS": 336991,
    "Description": "Motorcycle, Bicycle, and Parts Manufacturing"
  },
  {
    "NAICS": 336992,
    "Description": "Military Armored Vehicle, Tank, and Tank Component Manufacturing"
  },
  {
    "NAICS": 336999,
    "Description": "All Other Transportation Equipment Manufacturing"
  },
  {
    "NAICS": 337110,
    "Description": "Wood Kitchen Cabinet and Countertop Manufacturing"
  },
  {
    "NAICS": 337121,
    "Description": "Upholstered Household Furniture Manufacturing"
  },
  {
    "NAICS": 337122,
    "Description": "Nonupholstered Wood Household Furniture Manufacturing"
  },
  {
    "NAICS": 337124,
    "Description": "Metal Household Furniture Manufacturing"
  },
  {
    "NAICS": 337125,
    "Description": "Household Furniture (except Wood and Metal) Manufacturing"
  },
  {
    "NAICS": 337127,
    "Description": "Institutional Furniture Manufacturing"
  },
  {
    "NAICS": 337211,
    "Description": "Wood Office Furniture Manufacturing"
  },
  {
    "NAICS": 337212,
    "Description": "Custom Architectural Woodwork and Millwork Manufacturing"
  },
  {
    "NAICS": 337214,
    "Description": "Office Furniture (except Wood) Manufacturing"
  },
  {
    "NAICS": 337215,
    "Description": "Showcase, Partition, Shelving, and Locker Manufacturing"
  },
  {
    "NAICS": 337910,
    "Description": "Mattress Manufacturing"
  },
  {
    "NAICS": 337920,
    "Description": "Blind and Shade Manufacturing"
  },
  {
    "NAICS": 339112,
    "Description": "Surgical and Medical Instrument Manufacturing"
  },
  {
    "NAICS": 339113,
    "Description": "Surgical Appliance and Supplies Manufacturing"
  },
  {
    "NAICS": 339114,
    "Description": "Dental Equipment and Supplies Manufacturing"
  },
  {
    "NAICS": 339115,
    "Description": "Ophthalmic Goods Manufacturing"
  },
  {
    "NAICS": 339116,
    "Description": "Dental Laboratories"
  },
  {
    "NAICS": 339910,
    "Description": "Jewelry and Silverware Manufacturing"
  },
  {
    "NAICS": 339920,
    "Description": "Sporting and Athletic Goods Manufacturing"
  },
  {
    "NAICS": 339930,
    "Description": "Doll, Toy, and Game Manufacturing"
  },
  {
    "NAICS": 339940,
    "Description": "Office Supplies (except Paper) Manufacturing"
  },
  {
    "NAICS": 339950,
    "Description": "Sign Manufacturing"
  },
  {
    "NAICS": 339991,
    "Description": "Gasket, Packing, and Sealing Device Manufacturing"
  },
  {
    "NAICS": 339992,
    "Description": "Musical Instrument Manufacturing"
  },
  {
    "NAICS": 339993,
    "Description": "Fastener, Button, Needle, and Pin Manufacturing"
  },
  {
    "NAICS": 339994,
    "Description": "Broom, Brush, and Mop Manufacturing"
  },
  {
    "NAICS": 339995,
    "Description": "Burial Casket Manufacturing"
  },
  {
    "NAICS": 339999,
    "Description": "All Other Miscellaneous Manufacturing"
  },
  {
    "NAICS": 423110,
    "Description": "Automobile and Other Motor Vehicle Merchant Wholesalers"
  },
  {
    "NAICS": 423120,
    "Description": "Motor Vehicle Supplies and New Parts Merchant Wholesalers"
  },
  {
    "NAICS": 423130,
    "Description": "Tire and Tube Merchant Wholesalers"
  },
  {
    "NAICS": 423140,
    "Description": "Motor Vehicle Parts (Used) Merchant Wholesalers"
  },
  {
    "NAICS": 423210,
    "Description": "Furniture Merchant Wholesalers"
  },
  {
    "NAICS": 423220,
    "Description": "Home Furnishing Merchant Wholesalers"
  },
  {
    "NAICS": 423310,
    "Description": "Lumber, Plywood, Millwork, and Wood Panel Merchant Wholesalers"
  },
  {
    "NAICS": 423320,
    "Description": "Brick, Stone, and Related Construction Material Merchant Wholesalers"
  },
  {
    "NAICS": 423330,
    "Description": "Roofing, Siding, and Insulation Material Merchant Wholesalers"
  },
  {
    "NAICS": 423390,
    "Description": "Other Construction Material Merchant Wholesalers"
  },
  {
    "NAICS": 423410,
    "Description": "Photographic Equipment and Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 423420,
    "Description": "Office Equipment Merchant Wholesalers"
  },
  {
    "NAICS": 423430,
    "Description": "Computer and Computer Peripheral Equipment and Software Merchant Wholesalers"
  },
  {
    "NAICS": 423440,
    "Description": "Other Commercial Equipment Merchant Wholesalers"
  },
  {
    "NAICS": 423450,
    "Description": "Medical, Dental, and Hospital Equipment and Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 423460,
    "Description": "Ophthalmic Goods Merchant Wholesalers"
  },
  {
    "NAICS": 423490,
    "Description": "Other Professional Equipment and Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 423510,
    "Description": "Metal Service Centers and Other Metal Merchant Wholesalers"
  },
  {
    "NAICS": 423520,
    "Description": "Coal and Other Mineral and Ore Merchant Wholesalers"
  },
  {
    "NAICS": 423610,
    "Description": "Electrical Apparatus and Equipment, Wiring Supplies, and Related Equipment Merchant Wholesalers"
  },
  {
    "NAICS": 423620,
    "Description": "Household Appliances, Electric Housewares, and Consumer Electronics Merchant Wholesalers"
  },
  {
    "NAICS": 423690,
    "Description": "Other Electronic Parts and Equipment Merchant Wholesalers"
  },
  {
    "NAICS": 423710,
    "Description": "Hardware Merchant Wholesalers"
  },
  {
    "NAICS": 423720,
    "Description": "Plumbing and Heating Equipment and Supplies (Hydronics) Merchant Wholesalers"
  },
  {
    "NAICS": 423730,
    "Description": "Warm Air Heating and Air-Conditioning Equipment and Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 423740,
    "Description": "Refrigeration Equipment and Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 423810,
    "Description": "Construction and Mining (except Oil Well) Machinery and Equipment Merchant Wholesalers"
  },
  {
    "NAICS": 423820,
    "Description": "Farm and Garden Machinery and Equipment Merchant Wholesalers"
  },
  {
    "NAICS": 423830,
    "Description": "Industrial Machinery and Equipment Merchant Wholesalers"
  },
  {
    "NAICS": 423840,
    "Description": "Industrial Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 423850,
    "Description": "Service Establishment Equipment and Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 423860,
    "Description": "Transportation Equipment and Supplies (except Motor Vehicle) Merchant Wholesalers"
  },
  {
    "NAICS": 423910,
    "Description": "Sporting and Recreational Goods and Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 423920,
    "Description": "Toy and Hobby Goods and Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 423930,
    "Description": "Recyclable Material Merchant Wholesalers"
  },
  {
    "NAICS": 423940,
    "Description": "Jewelry, Watch, Precious Stone, and Precious Metal Merchant Wholesalers"
  },
  {
    "NAICS": 423990,
    "Description": "Other Miscellaneous Durable Goods Merchant Wholesalers"
  },
  {
    "NAICS": 424110,
    "Description": "Printing and Writing Paper Merchant Wholesalers"
  },
  {
    "NAICS": 424120,
    "Description": "Stationery and Office Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 424130,
    "Description": "Industrial and Personal Service Paper Merchant Wholesalers"
  },
  {
    "NAICS": 424210,
    "Description": "Drugs and Druggists' Sundries Merchant Wholesalers"
  },
  {
    "NAICS": 424310,
    "Description": "Piece Goods, Notions, and Other Dry Goods Merchant Wholesalers"
  },
  {
    "NAICS": 424320,
    "Description": "Men's and Boys' Clothing and Furnishings Merchant Wholesalers"
  },
  {
    "NAICS": 424330,
    "Description": "Women's, Children's, and Infants' Clothing and Accessories Merchant Wholesalers"
  },
  {
    "NAICS": 424340,
    "Description": "Footwear Merchant Wholesalers"
  },
  {
    "NAICS": 424410,
    "Description": "General Line Grocery Merchant Wholesalers"
  },
  {
    "NAICS": 424420,
    "Description": "Packaged Frozen Food Merchant Wholesalers"
  },
  {
    "NAICS": 424430,
    "Description": "Dairy Product (except Dried or Canned) Merchant Wholesalers"
  },
  {
    "NAICS": 424440,
    "Description": "Poultry and Poultry Product Merchant Wholesalers"
  },
  {
    "NAICS": 424450,
    "Description": "Confectionery Merchant Wholesalers"
  },
  {
    "NAICS": 424460,
    "Description": "Fish and Seafood Merchant Wholesalers"
  },
  {
    "NAICS": 424470,
    "Description": "Meat and Meat Product Merchant Wholesalers"
  },
  {
    "NAICS": 424480,
    "Description": "Fresh Fruit and Vegetable Merchant Wholesalers"
  },
  {
    "NAICS": 424490,
    "Description": "Other Grocery and Related Products Merchant Wholesalers"
  },
  {
    "NAICS": 424510,
    "Description": "Grain and Field Bean Merchant Wholesalers"
  },
  {
    "NAICS": 424520,
    "Description": "Livestock Merchant Wholesalers"
  },
  {
    "NAICS": 424590,
    "Description": "Other Farm Product Raw Material Merchant Wholesalers"
  },
  {
    "NAICS": 424610,
    "Description": "Plastics Materials and Basic Forms and Shapes Merchant Wholesalers"
  },
  {
    "NAICS": 424690,
    "Description": "Other Chemical and Allied Products Merchant Wholesalers"
  },
  {
    "NAICS": 424710,
    "Description": "Petroleum Bulk Stations and Terminals"
  },
  {
    "NAICS": 424720,
    "Description": "Petroleum and Petroleum Products Merchant Wholesalers (except Bulk Stations and Terminals)"
  },
  {
    "NAICS": 424810,
    "Description": "Beer and Ale Merchant Wholesalers"
  },
  {
    "NAICS": 424820,
    "Description": "Wine and Distilled Alcoholic Beverage Merchant Wholesalers"
  },
  {
    "NAICS": 424910,
    "Description": "Farm Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 424920,
    "Description": "Book, Periodical, and Newspaper Merchant Wholesalers"
  },
  {
    "NAICS": 424930,
    "Description": "Flower, Nursery Stock, and Florists' Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 424940,
    "Description": "Tobacco and Tobacco Product Merchant Wholesalers"
  },
  {
    "NAICS": 424950,
    "Description": "Paint, Varnish, and Supplies Merchant Wholesalers"
  },
  {
    "NAICS": 424990,
    "Description": "Other Miscellaneous Nondurable Goods Merchant Wholesalers"
  },
  {
    "NAICS": 425110,
    "Description": "Business to Business Electronic Markets"
  },
  {
    "NAICS": 425120,
    "Description": "Wholesale Trade Agents and Brokers"
  },
  {
    "NAICS": 441110,
    "Description": "New Car Dealers"
  },
  {
    "NAICS": 441120,
    "Description": "Used Car Dealers"
  },
  {
    "NAICS": 441210,
    "Description": "Recreational Vehicle Dealers"
  },
  {
    "NAICS": 441222,
    "Description": "Boat Dealers"
  },
  {
    "NAICS": 441228,
    "Description": "Motorcycle, ATV, and All Other Motor Vehicle Dealers"
  },
  {
    "NAICS": 441310,
    "Description": "Automotive Parts and Accessories Stores"
  },
  {
    "NAICS": 441320,
    "Description": "Tire Dealers"
  },
  {
    "NAICS": 442110,
    "Description": "Furniture Stores"
  },
  {
    "NAICS": 442210,
    "Description": "Floor Covering Stores"
  },
  {
    "NAICS": 442291,
    "Description": "Window Treatment Stores"
  },
  {
    "NAICS": 442299,
    "Description": "All Other Home Furnishings Stores"
  },
  {
    "NAICS": 443141,
    "Description": "Household Appliance Stores"
  },
  {
    "NAICS": 443142,
    "Description": "Electronics Stores"
  },
  {
    "NAICS": 444110,
    "Description": "Home Centers"
  },
  {
    "NAICS": 444120,
    "Description": "Paint and Wallpaper Stores"
  },
  {
    "NAICS": 444130,
    "Description": "Hardware Stores"
  },
  {
    "NAICS": 444190,
    "Description": "Other Building Material Dealers"
  },
  {
    "NAICS": 444210,
    "Description": "Outdoor Power Equipment Stores"
  },
  {
    "NAICS": 444220,
    "Description": "Nursery, Garden Center, and Farm Supply Stores"
  },
  {
    "NAICS": 445110,
    "Description": "Supermarkets and Other Grocery (except Convenience) Stores"
  },
  {
    "NAICS": 445120,
    "Description": "Convenience Stores"
  },
  {
    "NAICS": 445210,
    "Description": "Meat Markets"
  },
  {
    "NAICS": 445220,
    "Description": "Fish and Seafood Markets"
  },
  {
    "NAICS": 445230,
    "Description": "Fruit and Vegetable Markets"
  },
  {
    "NAICS": 445291,
    "Description": "Baked Goods Stores"
  },
  {
    "NAICS": 445292,
    "Description": "Confectionery and Nut Stores"
  },
  {
    "NAICS": 445299,
    "Description": "All Other Specialty Food Stores"
  },
  {
    "NAICS": 445310,
    "Description": "Beer, Wine, and Liquor Stores"
  },
  {
    "NAICS": 446110,
    "Description": "Pharmacies and Drug Stores"
  },
  {
    "NAICS": 446120,
    "Description": "Cosmetics, Beauty Supplies, and Perfume Stores"
  },
  {
    "NAICS": 446130,
    "Description": "Optical Goods Stores"
  },
  {
    "NAICS": 446191,
    "Description": "Food (Health) Supplement Stores"
  },
  {
    "NAICS": 446199,
    "Description": "All Other Health and Personal Care Stores"
  },
  {
    "NAICS": 447110,
    "Description": "Gasoline Stations with Convenience Stores"
  },
  {
    "NAICS": 447190,
    "Description": "Other Gasoline Stations"
  },
  {
    "NAICS": 448110,
    "Description": "Men's Clothing Stores"
  },
  {
    "NAICS": 448120,
    "Description": "Women's Clothing Stores"
  },
  {
    "NAICS": 448130,
    "Description": "Children's and Infants' Clothing Stores"
  },
  {
    "NAICS": 448140,
    "Description": "Family Clothing Stores"
  },
  {
    "NAICS": 448150,
    "Description": "Clothing Accessories Stores"
  },
  {
    "NAICS": 448190,
    "Description": "Other Clothing Stores"
  },
  {
    "NAICS": 448210,
    "Description": "Shoe Stores"
  },
  {
    "NAICS": 448310,
    "Description": "Jewelry Stores"
  },
  {
    "NAICS": 448320,
    "Description": "Luggage and Leather Goods Stores"
  },
  {
    "NAICS": 451110,
    "Description": "Sporting Goods Stores"
  },
  {
    "NAICS": 451120,
    "Description": "Hobby, Toy, and Game Stores"
  },
  {
    "NAICS": 451130,
    "Description": "Sewing, Needlework, and Piece Goods Stores"
  },
  {
    "NAICS": 451140,
    "Description": "Musical Instrument and Supplies Stores"
  },
  {
    "NAICS": 451211,
    "Description": "Book Stores"
  },
  {
    "NAICS": 451212,
    "Description": "News Dealers and Newsstands"
  },
  {
    "NAICS": 452210,
    "Description": "Department Stores"
  },
  {
    "NAICS": 452210,
    "Description": "Department Stores"
  },
  {
    "NAICS": 452311,
    "Description": "Warehouse Clubs and Supercenters"
  },
  {
    "NAICS": 452311,
    "Description": "Warehouse Clubs and Supercenters"
  },
  {
    "NAICS": 452319,
    "Description": "All Other General Merchandise Stores"
  },
  {
    "NAICS": 453110,
    "Description": "Florists"
  },
  {
    "NAICS": 453210,
    "Description": "Office Supplies and Stationery Stores"
  },
  {
    "NAICS": 453220,
    "Description": "Gift, Novelty, and Souvenir Stores"
  },
  {
    "NAICS": 453310,
    "Description": "Used Merchandise Stores"
  },
  {
    "NAICS": 453910,
    "Description": "Pet and Pet Supplies Stores"
  },
  {
    "NAICS": 453920,
    "Description": "Art Dealers"
  },
  {
    "NAICS": 453930,
    "Description": "Manufactured (Mobile) Home Dealers"
  },
  {
    "NAICS": 453991,
    "Description": "Tobacco Stores"
  },
  {
    "NAICS": 453998,
    "Description": "All Other Miscellaneous Store Retailers (except Tobacco Stores)"
  },
  {
    "NAICS": 454110,
    "Description": "Electronic Shopping and Mail-Order Houses"
  },
  {
    "NAICS": 454110,
    "Description": "Electronic Shopping and Mail-Order Houses"
  },
  {
    "NAICS": 454110,
    "Description": "Electronic Shopping and Mail-Order Houses"
  },
  {
    "NAICS": 454210,
    "Description": "Vending Machine Operators"
  },
  {
    "NAICS": 454310,
    "Description": "Fuel Dealers"
  },
  {
    "NAICS": 454390,
    "Description": "Other Direct Selling Establishments"
  },
  {
    "NAICS": 481111,
    "Description": "Scheduled Passenger Air Transportation"
  },
  {
    "NAICS": 481112,
    "Description": "Scheduled Freight Air Transportation"
  },
  {
    "NAICS": 481211,
    "Description": "Nonscheduled Chartered Passenger Air Transportation"
  },
  {
    "NAICS": 481212,
    "Description": "Nonscheduled Chartered Freight Air Transportation"
  },
  {
    "NAICS": 481219,
    "Description": "Other Nonscheduled Air Transportation"
  },
  {
    "NAICS": 482111,
    "Description": "Line-Haul Railroads"
  },
  {
    "NAICS": 482112,
    "Description": "Short Line Railroads"
  },
  {
    "NAICS": 483111,
    "Description": "Deep Sea Freight Transportation"
  },
  {
    "NAICS": 483112,
    "Description": "Deep Sea Passenger Transportation"
  },
  {
    "NAICS": 483113,
    "Description": "Coastal and Great Lakes Freight Transportation"
  },
  {
    "NAICS": 483114,
    "Description": "Coastal and Great Lakes Passenger Transportation"
  },
  {
    "NAICS": 483211,
    "Description": "Inland Water Freight Transportation"
  },
  {
    "NAICS": 483212,
    "Description": "Inland Water Passenger Transportation"
  },
  {
    "NAICS": 484110,
    "Description": "General Freight Trucking, Local"
  },
  {
    "NAICS": 484121,
    "Description": "General Freight Trucking, Long-Distance, Truckload"
  },
  {
    "NAICS": 484122,
    "Description": "General Freight Trucking, Long-Distance, Less Than Truckload"
  },
  {
    "NAICS": 484210,
    "Description": "Used Household and Office Goods Moving"
  },
  {
    "NAICS": 484220,
    "Description": "Specialized Freight (except Used Goods) Trucking, Local"
  },
  {
    "NAICS": 484230,
    "Description": "Specialized Freight (except Used Goods) Trucking, Long-Distance"
  },
  {
    "NAICS": 485111,
    "Description": "Mixed Mode Transit Systems"
  },
  {
    "NAICS": 485112,
    "Description": "Commuter Rail Systems"
  },
  {
    "NAICS": 485113,
    "Description": "Bus and Other Motor Vehicle Transit Systems"
  },
  {
    "NAICS": 485119,
    "Description": "Other Urban Transit Systems"
  },
  {
    "NAICS": 485210,
    "Description": "Interurban and Rural Bus Transportation"
  },
  {
    "NAICS": 485310,
    "Description": "Taxi Service"
  },
  {
    "NAICS": 485320,
    "Description": "Limousine Service"
  },
  {
    "NAICS": 485410,
    "Description": "School and Employee Bus Transportation"
  },
  {
    "NAICS": 485510,
    "Description": "Charter Bus Industry"
  },
  {
    "NAICS": 485991,
    "Description": "Special Needs Transportation"
  },
  {
    "NAICS": 485999,
    "Description": "All Other Transit and Ground Passenger Transportation"
  },
  {
    "NAICS": 486110,
    "Description": "Pipeline Transportation of Crude Oil"
  },
  {
    "NAICS": 486210,
    "Description": "Pipeline Transportation of Natural Gas"
  },
  {
    "NAICS": 486910,
    "Description": "Pipeline Transportation of Refined Petroleum Products"
  },
  {
    "NAICS": 486990,
    "Description": "All Other Pipeline Transportation"
  },
  {
    "NAICS": 487110,
    "Description": "Scenic and Sightseeing Transportation, Land"
  },
  {
    "NAICS": 487210,
    "Description": "Scenic and Sightseeing Transportation, Water"
  },
  {
    "NAICS": 487990,
    "Description": "Scenic and Sightseeing Transportation, Other"
  },
  {
    "NAICS": 488111,
    "Description": "Air Traffic Control"
  },
  {
    "NAICS": 488119,
    "Description": "Other Airport Operations"
  },
  {
    "NAICS": 488190,
    "Description": "Other Support Activities for Air Transportation"
  },
  {
    "NAICS": 488210,
    "Description": "Support Activities for Rail Transportation"
  },
  {
    "NAICS": 488310,
    "Description": "Port and Harbor Operations"
  },
  {
    "NAICS": 488320,
    "Description": "Marine Cargo Handling"
  },
  {
    "NAICS": 488330,
    "Description": "Navigational Services to Shipping"
  },
  {
    "NAICS": 488390,
    "Description": "Other Support Activities for Water Transportation"
  },
  {
    "NAICS": 488410,
    "Description": "Motor Vehicle Towing"
  },
  {
    "NAICS": 488490,
    "Description": "Other Support Activities for Road Transportation"
  },
  {
    "NAICS": 488510,
    "Description": "Freight Transportation Arrangement"
  },
  {
    "NAICS": 488991,
    "Description": "Packing and Crating"
  },
  {
    "NAICS": 488999,
    "Description": "All Other Support Activities for Transportation"
  },
  {
    "NAICS": 491110,
    "Description": "Postal Service"
  },
  {
    "NAICS": 492110,
    "Description": "Couriers and Express Delivery Services"
  },
  {
    "NAICS": 492210,
    "Description": "Local Messengers and Local Delivery"
  },
  {
    "NAICS": 493110,
    "Description": "General Warehousing and Storage"
  },
  {
    "NAICS": 493120,
    "Description": "Refrigerated Warehousing and Storage"
  },
  {
    "NAICS": 493130,
    "Description": "Farm Product Warehousing and Storage"
  },
  {
    "NAICS": 493190,
    "Description": "Other Warehousing and Storage"
  },
  {
    "NAICS": 511110,
    "Description": "Newspaper Publishers"
  },
  {
    "NAICS": 511120,
    "Description": "Periodical Publishers"
  },
  {
    "NAICS": 511130,
    "Description": "Book Publishers"
  },
  {
    "NAICS": 511140,
    "Description": "Directory and Mailing List Publishers"
  },
  {
    "NAICS": 511191,
    "Description": "Greeting Card Publishers"
  },
  {
    "NAICS": 511199,
    "Description": "All Other Publishers"
  },
  {
    "NAICS": 511210,
    "Description": "Software Publishers"
  },
  {
    "NAICS": 512110,
    "Description": "Motion Picture and Video Production"
  },
  {
    "NAICS": 512120,
    "Description": "Motion Picture and Video Distribution"
  },
  {
    "NAICS": 512131,
    "Description": "Motion Picture Theaters (except Drive-Ins)"
  },
  {
    "NAICS": 512132,
    "Description": "Drive-In Motion Picture Theaters"
  },
  {
    "NAICS": 512191,
    "Description": "Teleproduction and Other Postproduction Services"
  },
  {
    "NAICS": 512199,
    "Description": "Other Motion Picture and Video Industries"
  },
  {
    "NAICS": 512230,
    "Description": "Music Publishers"
  },
  {
    "NAICS": 512240,
    "Description": "Sound Recording Studios"
  },
  {
    "NAICS": 512250,
    "Description": "Record Production and Distribution"
  },
  {
    "NAICS": 512250,
    "Description": "Record Production and Distribution"
  },
  {
    "NAICS": 512290,
    "Description": "Other Sound Recording Industries"
  },
  {
    "NAICS": 515111,
    "Description": "Radio Networks"
  },
  {
    "NAICS": 515112,
    "Description": "Radio Stations"
  },
  {
    "NAICS": 515120,
    "Description": "Television Broadcasting"
  },
  {
    "NAICS": 515210,
    "Description": "Cable and Other Subscription Programming"
  },
  {
    "NAICS": 517311,
    "Description": "Wired Telecommunications Carriers"
  },
  {
    "NAICS": 517312,
    "Description": "Wireless Telecommunications Carriers (except Satellite)"
  },
  {
    "NAICS": 517410,
    "Description": "Satellite Telecommunications"
  },
  {
    "NAICS": 517911,
    "Description": "Telecommunications Resellers"
  },
  {
    "NAICS": 517919,
    "Description": "All Other Telecommunications"
  },
  {
    "NAICS": 518210,
    "Description": "Data Processing, Hosting, and Related Services"
  },
  {
    "NAICS": 519110,
    "Description": "News Syndicates"
  },
  {
    "NAICS": 519120,
    "Description": "Libraries and Archives"
  },
  {
    "NAICS": 519130,
    "Description": "Internet Publishing and Broadcasting and Web Search Portals"
  },
  {
    "NAICS": 519190,
    "Description": "All Other Information Services"
  },
  {
    "NAICS": 521110,
    "Description": "Monetary Authorities-Central Bank"
  },
  {
    "NAICS": 522110,
    "Description": "Commercial Banking"
  },
  {
    "NAICS": 522120,
    "Description": "Savings Institutions"
  },
  {
    "NAICS": 522130,
    "Description": "Credit Unions"
  },
  {
    "NAICS": 522190,
    "Description": "Other Depository Credit Intermediation"
  },
  {
    "NAICS": 522210,
    "Description": "Credit Card Issuing"
  },
  {
    "NAICS": 522220,
    "Description": "Sales Financing"
  },
  {
    "NAICS": 522291,
    "Description": "Consumer Lending"
  },
  {
    "NAICS": 522292,
    "Description": "Real Estate Credit"
  },
  {
    "NAICS": 522293,
    "Description": "International Trade Financing"
  },
  {
    "NAICS": 522294,
    "Description": "Secondary Market Financing"
  },
  {
    "NAICS": 522298,
    "Description": "All Other Nondepository Credit Intermediation"
  },
  {
    "NAICS": 522310,
    "Description": "Mortgage and Nonmortgage Loan Brokers"
  },
  {
    "NAICS": 522320,
    "Description": "Financial Transactions Processing, Reserve, and Clearinghouse Activities"
  },
  {
    "NAICS": 522390,
    "Description": "Other Activities Related to Credit Intermediation"
  },
  {
    "NAICS": 523110,
    "Description": "Investment Banking and Securities Dealing"
  },
  {
    "NAICS": 523120,
    "Description": "Securities Brokerage"
  },
  {
    "NAICS": 523130,
    "Description": "Commodity Contracts Dealing"
  },
  {
    "NAICS": 523140,
    "Description": "Commodity Contracts Brokerage"
  },
  {
    "NAICS": 523210,
    "Description": "Securities and Commodity Exchanges"
  },
  {
    "NAICS": 523910,
    "Description": "Miscellaneous Intermediation"
  },
  {
    "NAICS": 523920,
    "Description": "Portfolio Management"
  },
  {
    "NAICS": 523930,
    "Description": "Investment Advice"
  },
  {
    "NAICS": 523991,
    "Description": "Trust, Fiduciary, and Custody Activities"
  },
  {
    "NAICS": 523999,
    "Description": "Miscellaneous Financial Investment Activities"
  },
  {
    "NAICS": 524113,
    "Description": "Direct Life Insurance Carriers"
  },
  {
    "NAICS": 524114,
    "Description": "Direct Health and Medical Insurance Carriers"
  },
  {
    "NAICS": 524126,
    "Description": "Direct Property and Casualty Insurance Carriers"
  },
  {
    "NAICS": 524127,
    "Description": "Direct Title Insurance Carriers"
  },
  {
    "NAICS": 524128,
    "Description": "Other Direct Insurance (except Life, Health, and Medical) Carriers"
  },
  {
    "NAICS": 524130,
    "Description": "Reinsurance Carriers"
  },
  {
    "NAICS": 524210,
    "Description": "Insurance Agencies and Brokerages"
  },
  {
    "NAICS": 524291,
    "Description": "Claims Adjusting"
  },
  {
    "NAICS": 524292,
    "Description": "Third Party Administration of Insurance and Pension Funds"
  },
  {
    "NAICS": 524298,
    "Description": "All Other Insurance Related Activities"
  },
  {
    "NAICS": 525110,
    "Description": "Pension Funds"
  },
  {
    "NAICS": 525120,
    "Description": "Health and Welfare Funds"
  },
  {
    "NAICS": 525190,
    "Description": "Other Insurance Funds"
  },
  {
    "NAICS": 525910,
    "Description": "Open-End Investment Funds"
  },
  {
    "NAICS": 525920,
    "Description": "Trusts, Estates, and Agency Accounts"
  },
  {
    "NAICS": 525990,
    "Description": "Other Financial Vehicles"
  },
  {
    "NAICS": 531110,
    "Description": "Lessors of Residential Buildings and Dwellings"
  },
  {
    "NAICS": 531120,
    "Description": "Lessors of Nonresidential Buildings (except Miniwarehouses)"
  },
  {
    "NAICS": 531130,
    "Description": "Lessors of Miniwarehouses and Self-Storage Units"
  },
  {
    "NAICS": 531190,
    "Description": "Lessors of Other Real Estate Property"
  },
  {
    "NAICS": 531210,
    "Description": "Offices of Real Estate Agents and Brokers"
  },
  {
    "NAICS": 531311,
    "Description": "Residential Property Managers"
  },
  {
    "NAICS": 531312,
    "Description": "Nonresidential Property Managers"
  },
  {
    "NAICS": 531320,
    "Description": "Offices of Real Estate Appraisers"
  },
  {
    "NAICS": 531390,
    "Description": "Other Activities Related to Real Estate"
  },
  {
    "NAICS": 532111,
    "Description": "Passenger Car Rental"
  },
  {
    "NAICS": 532112,
    "Description": "Passenger Car Leasing"
  },
  {
    "NAICS": 532120,
    "Description": "Truck, Utility Trailer, and RV (Recreational Vehicle) Rental and Leasing"
  },
  {
    "NAICS": 532210,
    "Description": "Consumer Electronics and Appliances Rental"
  },
  {
    "NAICS": 532281,
    "Description": "Formal Wear and Costume Rental"
  },
  {
    "NAICS": 532282,
    "Description": "Video Tape and Disc Rental"
  },
  {
    "NAICS": 532283,
    "Description": "Home Health Equipment Rental"
  },
  {
    "NAICS": 532284,
    "Description": "Recreational Goods Rental"
  },
  {
    "NAICS": 532289,
    "Description": "All Other Consumer Goods Rental"
  },
  {
    "NAICS": 532310,
    "Description": "General Rental Centers"
  },
  {
    "NAICS": 532411,
    "Description": "Commercial Air, Rail, and Water Transportation Equipment Rental and Leasing"
  },
  {
    "NAICS": 532412,
    "Description": "Construction, Mining, and Forestry Machinery and Equipment Rental and Leasing"
  },
  {
    "NAICS": 532420,
    "Description": "Office Machinery and Equipment Rental and Leasing"
  },
  {
    "NAICS": 532490,
    "Description": "Other Commercial and Industrial Machinery and Equipment Rental and Leasing"
  },
  {
    "NAICS": 533110,
    "Description": "Lessors of Nonfinancial Intangible Assets (except Copyrighted Works)"
  },
  {
    "NAICS": 541110,
    "Description": "Offices of Lawyers"
  },
  {
    "NAICS": 541120,
    "Description": "Offices of Notaries"
  },
  {
    "NAICS": 541191,
    "Description": "Title Abstract and Settlement Offices"
  },
  {
    "NAICS": 541199,
    "Description": "All Other Legal Services"
  },
  {
    "NAICS": 541211,
    "Description": "Offices of Certified Public Accountants"
  },
  {
    "NAICS": 541213,
    "Description": "Tax Preparation Services"
  },
  {
    "NAICS": 541214,
    "Description": "Payroll Services"
  },
  {
    "NAICS": 541219,
    "Description": "Other Accounting Services"
  },
  {
    "NAICS": 541310,
    "Description": "Architectural Services"
  },
  {
    "NAICS": 541320,
    "Description": "Landscape Architectural Services"
  },
  {
    "NAICS": 541330,
    "Description": "Engineering Services"
  },
  {
    "NAICS": 541340,
    "Description": "Drafting Services"
  },
  {
    "NAICS": 541350,
    "Description": "Building Inspection Services"
  },
  {
    "NAICS": 541360,
    "Description": "Geophysical Surveying and Mapping Services"
  },
  {
    "NAICS": 541370,
    "Description": "Surveying and Mapping (except Geophysical) Services"
  },
  {
    "NAICS": 541380,
    "Description": "Testing Laboratories"
  },
  {
    "NAICS": 541410,
    "Description": "Interior Design Services"
  },
  {
    "NAICS": 541420,
    "Description": "Industrial Design Services"
  },
  {
    "NAICS": 541430,
    "Description": "Graphic Design Services"
  },
  {
    "NAICS": 541490,
    "Description": "Other Specialized Design Services"
  },
  {
    "NAICS": 541511,
    "Description": "Custom Computer Programming Services"
  },
  {
    "NAICS": 541512,
    "Description": "Computer Systems Design Services"
  },
  {
    "NAICS": 541513,
    "Description": "Computer Facilities Management Services"
  },
  {
    "NAICS": 541519,
    "Description": "Other Computer Related Services"
  },
  {
    "NAICS": 541611,
    "Description": "Administrative Management and General Management Consulting Services"
  },
  {
    "NAICS": 541612,
    "Description": "Human Resources Consulting Services"
  },
  {
    "NAICS": 541613,
    "Description": "Marketing Consulting Services"
  },
  {
    "NAICS": 541614,
    "Description": "Process, Physical Distribution, and Logistics Consulting Services"
  },
  {
    "NAICS": 541618,
    "Description": "Other Management Consulting Services"
  },
  {
    "NAICS": 541620,
    "Description": "Environmental Consulting Services"
  },
  {
    "NAICS": 541690,
    "Description": "Other Scientific and Technical Consulting Services"
  },
  {
    "NAICS": 541713,
    "Description": "Research and Development in Nanotechnology"
  },
  {
    "NAICS": 541713,
    "Description": "Research and Development in Nanotechnology"
  },
  {
    "NAICS": 541714,
    "Description": "Research and Development in Biotechnology (except Nanobiotechnology)"
  },
  {
    "NAICS": 541715,
    "Description": "Research and Development in the Physical, Engineering, and Life Sciences (except Nanotechnology and Biotechnology)"
  },
  {
    "NAICS": 541720,
    "Description": "Research and Development in the Social Sciences and Humanities"
  },
  {
    "NAICS": 541810,
    "Description": "Advertising Agencies"
  },
  {
    "NAICS": 541820,
    "Description": "Public Relations Agencies"
  },
  {
    "NAICS": 541830,
    "Description": "Media Buying Agencies"
  },
  {
    "NAICS": 541840,
    "Description": "Media Representatives"
  },
  {
    "NAICS": 541850,
    "Description": "Outdoor Advertising"
  },
  {
    "NAICS": 541860,
    "Description": "Direct Mail Advertising"
  },
  {
    "NAICS": 541870,
    "Description": "Advertising Material Distribution Services"
  },
  {
    "NAICS": 541890,
    "Description": "Other Services Related to Advertising"
  },
  {
    "NAICS": 541910,
    "Description": "Marketing Research and Public Opinion Polling"
  },
  {
    "NAICS": 541921,
    "Description": "Photography Studios, Portrait"
  },
  {
    "NAICS": 541922,
    "Description": "Commercial Photography"
  },
  {
    "NAICS": 541930,
    "Description": "Translation and Interpretation Services"
  },
  {
    "NAICS": 541940,
    "Description": "Veterinary Services"
  },
  {
    "NAICS": 541990,
    "Description": "All Other Professional, Scientific, and Technical Services"
  },
  {
    "NAICS": 551111,
    "Description": "Offices of Bank Holding Companies"
  },
  {
    "NAICS": 551112,
    "Description": "Offices of Other Holding Companies"
  },
  {
    "NAICS": 551114,
    "Description": "Corporate, Subsidiary, and Regional Managing Offices"
  },
  {
    "NAICS": 561110,
    "Description": "Office Administrative Services"
  },
  {
    "NAICS": 561210,
    "Description": "Facilities Support Services"
  },
  {
    "NAICS": 561311,
    "Description": "Employment Placement Agencies"
  },
  {
    "NAICS": 561312,
    "Description": "Executive Search Services"
  },
  {
    "NAICS": 561320,
    "Description": "Temporary Help Services"
  },
  {
    "NAICS": 561330,
    "Description": "Professional Employer Organizations"
  },
  {
    "NAICS": 561410,
    "Description": "Document Preparation Services"
  },
  {
    "NAICS": 561421,
    "Description": "Telephone Answering Services"
  },
  {
    "NAICS": 561422,
    "Description": "Telemarketing Bureaus and Other Contact Centers"
  },
  {
    "NAICS": 561431,
    "Description": "Private Mail Centers"
  },
  {
    "NAICS": 561439,
    "Description": "Other Business Service Centers (including Copy Shops)"
  },
  {
    "NAICS": 561440,
    "Description": "Collection Agencies"
  },
  {
    "NAICS": 561450,
    "Description": "Credit Bureaus"
  },
  {
    "NAICS": 561491,
    "Description": "Repossession Services"
  },
  {
    "NAICS": 561492,
    "Description": "Court Reporting and Stenotype Services"
  },
  {
    "NAICS": 561499,
    "Description": "All Other Business Support Services"
  },
  {
    "NAICS": 561510,
    "Description": "Travel Agencies"
  },
  {
    "NAICS": 561520,
    "Description": "Tour Operators"
  },
  {
    "NAICS": 561591,
    "Description": "Convention and Visitors Bureaus"
  },
  {
    "NAICS": 561599,
    "Description": "All Other Travel Arrangement and Reservation Services"
  },
  {
    "NAICS": 561611,
    "Description": "Investigation Services"
  },
  {
    "NAICS": 561612,
    "Description": "Security Guards and Patrol Services"
  },
  {
    "NAICS": 561613,
    "Description": "Armored Car Services"
  },
  {
    "NAICS": 561621,
    "Description": "Security Systems Services (except Locksmiths)"
  },
  {
    "NAICS": 561622,
    "Description": "Locksmiths"
  },
  {
    "NAICS": 561710,
    "Description": "Exterminating and Pest Control Services"
  },
  {
    "NAICS": 561720,
    "Description": "Janitorial Services"
  },
  {
    "NAICS": 561730,
    "Description": "Landscaping Services"
  },
  {
    "NAICS": 561740,
    "Description": "Carpet and Upholstery Cleaning Services"
  },
  {
    "NAICS": 561790,
    "Description": "Other Services to Buildings and Dwellings"
  },
  {
    "NAICS": 561910,
    "Description": "Packaging and Labeling Services"
  },
  {
    "NAICS": 561920,
    "Description": "Convention and Trade Show Organizers"
  },
  {
    "NAICS": 561990,
    "Description": "All Other Support Services"
  },
  {
    "NAICS": 562111,
    "Description": "Solid Waste Collection"
  },
  {
    "NAICS": 562112,
    "Description": "Hazardous Waste Collection"
  },
  {
    "NAICS": 562119,
    "Description": "Other Waste Collection"
  },
  {
    "NAICS": 562211,
    "Description": "Hazardous Waste Treatment and Disposal"
  },
  {
    "NAICS": 562212,
    "Description": "Solid Waste Landfill"
  },
  {
    "NAICS": 562213,
    "Description": "Solid Waste Combustors and Incinerators"
  },
  {
    "NAICS": 562219,
    "Description": "Other Nonhazardous Waste Treatment and Disposal"
  },
  {
    "NAICS": 562910,
    "Description": "Remediation Services"
  },
  {
    "NAICS": 562920,
    "Description": "Materials Recovery Facilities"
  },
  {
    "NAICS": 562991,
    "Description": "Septic Tank and Related Services"
  },
  {
    "NAICS": 562998,
    "Description": "All Other Miscellaneous Waste Management Services"
  },
  {
    "NAICS": 611110,
    "Description": "Elementary and Secondary Schools"
  },
  {
    "NAICS": 611210,
    "Description": "Junior Colleges"
  },
  {
    "NAICS": 611310,
    "Description": "Colleges, Universities, and Professional Schools"
  },
  {
    "NAICS": 611410,
    "Description": "Business and Secretarial Schools"
  },
  {
    "NAICS": 611420,
    "Description": "Computer Training"
  },
  {
    "NAICS": 611430,
    "Description": "Professional and Management Development Training"
  },
  {
    "NAICS": 611511,
    "Description": "Cosmetology and Barber Schools"
  },
  {
    "NAICS": 611512,
    "Description": "Flight Training"
  },
  {
    "NAICS": 611513,
    "Description": "Apprenticeship Training"
  },
  {
    "NAICS": 611519,
    "Description": "Other Technical and Trade Schools"
  },
  {
    "NAICS": 611610,
    "Description": "Fine Arts Schools"
  },
  {
    "NAICS": 611620,
    "Description": "Sports and Recreation Instruction"
  },
  {
    "NAICS": 611630,
    "Description": "Language Schools"
  },
  {
    "NAICS": 611691,
    "Description": "Exam Preparation and Tutoring"
  },
  {
    "NAICS": 611692,
    "Description": "Automobile Driving Schools"
  },
  {
    "NAICS": 611699,
    "Description": "All Other Miscellaneous Schools and Instruction"
  },
  {
    "NAICS": 611710,
    "Description": "Educational Support Services"
  },
  {
    "NAICS": 621111,
    "Description": "Offices of Physicians (except Mental Health Specialists)"
  },
  {
    "NAICS": 621112,
    "Description": "Offices of Physicians, Mental Health Specialists"
  },
  {
    "NAICS": 621210,
    "Description": "Offices of Dentists"
  },
  {
    "NAICS": 621310,
    "Description": "Offices of Chiropractors"
  },
  {
    "NAICS": 621320,
    "Description": "Offices of Optometrists"
  },
  {
    "NAICS": 621330,
    "Description": "Offices of Mental Health Practitioners (except Physicians)"
  },
  {
    "NAICS": 621340,
    "Description": "Offices of Physical, Occupational and Speech Therapists, and Audiologists"
  },
  {
    "NAICS": 621391,
    "Description": "Offices of Podiatrists"
  },
  {
    "NAICS": 621399,
    "Description": "Offices of All Other Miscellaneous Health Practitioners"
  },
  {
    "NAICS": 621410,
    "Description": "Family Planning Centers"
  },
  {
    "NAICS": 621420,
    "Description": "Outpatient Mental Health and Substance Abuse Centers"
  },
  {
    "NAICS": 621491,
    "Description": "HMO Medical Centers"
  },
  {
    "NAICS": 621492,
    "Description": "Kidney Dialysis Centers"
  },
  {
    "NAICS": 621493,
    "Description": "Freestanding Ambulatory Surgical and Emergency Centers"
  },
  {
    "NAICS": 621498,
    "Description": "All Other Outpatient Care Centers"
  },
  {
    "NAICS": 621511,
    "Description": "Medical Laboratories"
  },
  {
    "NAICS": 621512,
    "Description": "Diagnostic Imaging Centers"
  },
  {
    "NAICS": 621610,
    "Description": "Home Health Care Services"
  },
  {
    "NAICS": 621910,
    "Description": "Ambulance Services"
  },
  {
    "NAICS": 621991,
    "Description": "Blood and Organ Banks"
  },
  {
    "NAICS": 621999,
    "Description": "All Other Miscellaneous Ambulatory Health Care Services"
  },
  {
    "NAICS": 622110,
    "Description": "General Medical and Surgical Hospitals"
  },
  {
    "NAICS": 622210,
    "Description": "Psychiatric and Substance Abuse Hospitals"
  },
  {
    "NAICS": 622310,
    "Description": "Specialty (except Psychiatric and Substance Abuse) Hospitals"
  },
  {
    "NAICS": 623110,
    "Description": "Nursing Care Facilities (Skilled Nursing Facilities)"
  },
  {
    "NAICS": 623210,
    "Description": "Residential Intellectual and Developmental Disability Facilities"
  },
  {
    "NAICS": 623220,
    "Description": "Residential Mental Health and Substance Abuse Facilities"
  },
  {
    "NAICS": 623311,
    "Description": "Continuing Care Retirement Communities"
  },
  {
    "NAICS": 623312,
    "Description": "Assisted Living Facilities for the Elderly"
  },
  {
    "NAICS": 623990,
    "Description": "Other Residential Care Facilities"
  },
  {
    "NAICS": 624110,
    "Description": "Child and Youth Services"
  },
  {
    "NAICS": 624120,
    "Description": "Services for the Elderly and Persons with Disabilities"
  },
  {
    "NAICS": 624190,
    "Description": "Other Individual and Family Services"
  },
  {
    "NAICS": 624210,
    "Description": "Community Food Services"
  },
  {
    "NAICS": 624221,
    "Description": "Temporary Shelters"
  },
  {
    "NAICS": 624229,
    "Description": "Other Community Housing Services"
  },
  {
    "NAICS": 624230,
    "Description": "Emergency and Other Relief Services"
  },
  {
    "NAICS": 624310,
    "Description": "Vocational Rehabilitation Services"
  },
  {
    "NAICS": 624410,
    "Description": "Child Day Care Services"
  },
  {
    "NAICS": 711110,
    "Description": "Theater Companies and Dinner Theaters"
  },
  {
    "NAICS": 711120,
    "Description": "Dance Companies"
  },
  {
    "NAICS": 711130,
    "Description": "Musical Groups and Artists"
  },
  {
    "NAICS": 711190,
    "Description": "Other Performing Arts Companies"
  },
  {
    "NAICS": 711211,
    "Description": "Sports Teams and Clubs"
  },
  {
    "NAICS": 711212,
    "Description": "Racetracks"
  },
  {
    "NAICS": 711219,
    "Description": "Other Spectator Sports"
  },
  {
    "NAICS": 711310,
    "Description": "Promoters of Performing Arts, Sports, and Similar Events with Facilities"
  },
  {
    "NAICS": 711320,
    "Description": "Promoters of Performing Arts, Sports, and Similar Events without Facilities"
  },
  {
    "NAICS": 711410,
    "Description": "Agents and Managers for Artists, Athletes, Entertainers, and Other Public Figures"
  },
  {
    "NAICS": 711510,
    "Description": "Independent Artists, Writers, and Performers"
  },
  {
    "NAICS": 712110,
    "Description": "Museums"
  },
  {
    "NAICS": 712120,
    "Description": "Historical Sites"
  },
  {
    "NAICS": 712130,
    "Description": "Zoos and Botanical Gardens"
  },
  {
    "NAICS": 712190,
    "Description": "Nature Parks and Other Similar Institutions"
  },
  {
    "NAICS": 713110,
    "Description": "Amusement and Theme Parks"
  },
  {
    "NAICS": 713120,
    "Description": "Amusement Arcades"
  },
  {
    "NAICS": 713210,
    "Description": "Casinos (except Casino Hotels)"
  },
  {
    "NAICS": 713290,
    "Description": "Other Gambling Industries"
  },
  {
    "NAICS": 713910,
    "Description": "Golf Courses and Country Clubs"
  },
  {
    "NAICS": 713920,
    "Description": "Skiing Facilities"
  },
  {
    "NAICS": 713930,
    "Description": "Marinas"
  },
  {
    "NAICS": 713940,
    "Description": "Fitness and Recreational Sports Centers"
  },
  {
    "NAICS": 713950,
    "Description": "Bowling Centers"
  },
  {
    "NAICS": 713990,
    "Description": "All Other Amusement and Recreation Industries"
  },
  {
    "NAICS": 721110,
    "Description": "Hotels (except Casino Hotels) and Motels"
  },
  {
    "NAICS": 721120,
    "Description": "Casino Hotels"
  },
  {
    "NAICS": 721191,
    "Description": "Bed-and-Breakfast Inns"
  },
  {
    "NAICS": 721199,
    "Description": "All Other Traveler Accommodation"
  },
  {
    "NAICS": 721211,
    "Description": "RV (Recreational Vehicle) Parks and Campgrounds"
  },
  {
    "NAICS": 721214,
    "Description": "Recreational and Vacation Camps (except Campgrounds)"
  },
  {
    "NAICS": 721310,
    "Description": "Rooming and Boarding Houses, Dormitories, and Workers' Camps"
  },
  {
    "NAICS": 722310,
    "Description": "Food Service Contractors"
  },
  {
    "NAICS": 722320,
    "Description": "Caterers"
  },
  {
    "NAICS": 722330,
    "Description": "Mobile Food Services"
  },
  {
    "NAICS": 722410,
    "Description": "Drinking Places (Alcoholic Beverages)"
  },
  {
    "NAICS": 722511,
    "Description": "Full-Service Restaurants"
  },
  {
    "NAICS": 722513,
    "Description": "Limited-Service Restaurants"
  },
  {
    "NAICS": 722514,
    "Description": "Cafeterias, Grill Buffets, and Buffets"
  },
  {
    "NAICS": 722515,
    "Description": "Snack and Nonalcoholic Beverage Bars"
  },
  {
    "NAICS": 811111,
    "Description": "General Automotive Repair"
  },
  {
    "NAICS": 811112,
    "Description": "Automotive Exhaust System Repair"
  },
  {
    "NAICS": 811113,
    "Description": "Automotive Transmission Repair"
  },
  {
    "NAICS": 811118,
    "Description": "Other Automotive Mechanical and Electrical Repair and Maintenance"
  },
  {
    "NAICS": 811121,
    "Description": "Automotive Body, Paint, and Interior Repair and Maintenance"
  },
  {
    "NAICS": 811122,
    "Description": "Automotive Glass Replacement Shops"
  },
  {
    "NAICS": 811191,
    "Description": "Automotive Oil Change and Lubrication Shops"
  },
  {
    "NAICS": 811192,
    "Description": "Car Washes"
  },
  {
    "NAICS": 811198,
    "Description": "All Other Automotive Repair and Maintenance"
  },
  {
    "NAICS": 811211,
    "Description": "Consumer Electronics Repair and Maintenance"
  },
  {
    "NAICS": 811212,
    "Description": "Computer and Office Machine Repair and Maintenance"
  },
  {
    "NAICS": 811213,
    "Description": "Communication Equipment Repair and Maintenance"
  },
  {
    "NAICS": 811219,
    "Description": "Other Electronic and Precision Equipment Repair and Maintenance"
  },
  {
    "NAICS": 811310,
    "Description": "Commercial and Industrial Machinery and Equipment (except Automotive and Electronic) Repair and Maintenance"
  },
  {
    "NAICS": 811411,
    "Description": "Home and Garden Equipment Repair and Maintenance"
  },
  {
    "NAICS": 811412,
    "Description": "Appliance Repair and Maintenance"
  },
  {
    "NAICS": 811420,
    "Description": "Reupholstery and Furniture Repair"
  },
  {
    "NAICS": 811430,
    "Description": "Footwear and Leather Goods Repair"
  },
  {
    "NAICS": 811490,
    "Description": "Other Personal and Household Goods Repair and Maintenance"
  },
  {
    "NAICS": 812111,
    "Description": "Barber Shops"
  },
  {
    "NAICS": 812112,
    "Description": "Beauty Salons"
  },
  {
    "NAICS": 812113,
    "Description": "Nail Salons"
  },
  {
    "NAICS": 812191,
    "Description": "Diet and Weight Reducing Centers"
  },
  {
    "NAICS": 812199,
    "Description": "Other Personal Care Services"
  },
  {
    "NAICS": 812210,
    "Description": "Funeral Homes and Funeral Services"
  },
  {
    "NAICS": 812220,
    "Description": "Cemeteries and Crematories"
  },
  {
    "NAICS": 812310,
    "Description": "Coin-Operated Laundries and Drycleaners"
  },
  {
    "NAICS": 812320,
    "Description": "Drycleaning and Laundry Services (except Coin-Operated)"
  },
  {
    "NAICS": 812331,
    "Description": "Linen Supply"
  },
  {
    "NAICS": 812332,
    "Description": "Industrial Launderers"
  },
  {
    "NAICS": 812910,
    "Description": "Pet Care (except Veterinary) Services"
  },
  {
    "NAICS": 812921,
    "Description": "Photofinishing Laboratories (except One-Hour)"
  },
  {
    "NAICS": 812922,
    "Description": "One-Hour Photofinishing"
  },
  {
    "NAICS": 812930,
    "Description": "Parking Lots and Garages"
  },
  {
    "NAICS": 812990,
    "Description": "All Other Personal Services"
  },
  {
    "NAICS": 813110,
    "Description": "Religious Organizations"
  },
  {
    "NAICS": 813211,
    "Description": "Grantmaking Foundations"
  },
  {
    "NAICS": 813212,
    "Description": "Voluntary Health Organizations"
  },
  {
    "NAICS": 813219,
    "Description": "Other Grantmaking and Giving Services"
  },
  {
    "NAICS": 813311,
    "Description": "Human Rights Organizations"
  },
  {
    "NAICS": 813312,
    "Description": "Environment, Conservation and Wildlife Organizations"
  },
  {
    "NAICS": 813319,
    "Description": "Other Social Advocacy Organizations"
  },
  {
    "NAICS": 813410,
    "Description": "Civic and Social Organizations"
  },
  {
    "NAICS": 813910,
    "Description": "Business Associations"
  },
  {
    "NAICS": 813920,
    "Description": "Professional Organizations"
  },
  {
    "NAICS": 813930,
    "Description": "Labor Unions and Similar Labor Organizations"
  },
  {
    "NAICS": 813940,
    "Description": "Political Organizations"
  },
  {
    "NAICS": 813990,
    "Description": "Other Similar Organizations (except Business, Professional, Labor, and Political Organizations)"
  },
  {
    "NAICS": 814110,
    "Description": "Private Households"
  },
  {
    "NAICS": 921110,
    "Description": "Executive Offices"
  },
  {
    "NAICS": 921120,
    "Description": "Legislative Bodies"
  },
  {
    "NAICS": 921130,
    "Description": "Public Finance Activities"
  },
  {
    "NAICS": 921140,
    "Description": "Executive and Legislative Offices, Combined"
  },
  {
    "NAICS": 921150,
    "Description": "American Indian and Alaska Native Tribal Governments"
  },
  {
    "NAICS": 921190,
    "Description": "Other General Government Support"
  },
  {
    "NAICS": 922110,
    "Description": "Courts"
  },
  {
    "NAICS": 922120,
    "Description": "Police Protection"
  },
  {
    "NAICS": 922130,
    "Description": "Legal Counsel and Prosecution"
  },
  {
    "NAICS": 922140,
    "Description": "Correctional Institutions"
  },
  {
    "NAICS": 922150,
    "Description": "Parole Offices and Probation Offices"
  },
  {
    "NAICS": 922160,
    "Description": "Fire Protection"
  },
  {
    "NAICS": 922190,
    "Description": "Other Justice, Public Order, and Safety Activities"
  },
  {
    "NAICS": 923110,
    "Description": "Administration of Education Programs"
  },
  {
    "NAICS": 923120,
    "Description": "Administration of Public Health Programs"
  },
  {
    "NAICS": 923130,
    "Description": "Administration of Human Resource Programs (except Education, Public Health, and Veterans' Affairs Programs)"
  },
  {
    "NAICS": 923140,
    "Description": "Administration of Veterans' Affairs"
  },
  {
    "NAICS": 924110,
    "Description": "Administration of Air and Water Resource and Solid Waste Management Programs"
  },
  {
    "NAICS": 924120,
    "Description": "Administration of Conservation Programs"
  },
  {
    "NAICS": 925110,
    "Description": "Administration of Housing Programs"
  },
  {
    "NAICS": 925120,
    "Description": "Administration of Urban Planning and Community and Rural Development"
  },
  {
    "NAICS": 926110,
    "Description": "Administration of General Economic Programs"
  },
  {
    "NAICS": 926120,
    "Description": "Regulation and Administration of Transportation Programs"
  },
  {
    "NAICS": 926130,
    "Description": "Regulation and Administration of Communications, Electric, Gas, and Other Utilities"
  },
  {
    "NAICS": 926140,
    "Description": "Regulation of Agricultural Marketing and Commodities"
  },
  {
    "NAICS": 926150,
    "Description": "Regulation, Licensing, and Inspection of Miscellaneous Commercial Sectors"
  },
  {
    "NAICS": 927110,
    "Description": "Space Research and Technology"
  },
  {
    "NAICS": 928110,
    "Description": "National Security"
  },
  {
    "NAICS": 928120,
    "Description": "International Affairs"
  }
];
let zipcodeValid= true;

$("#industryForm").submit(function(event) {
  event.stopPropagation();
  event.preventDefault();
  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.getElementsByClassName("needs-validation");
  // Loop over them and prevent submission
  var validation = Array.prototype.filter.call(forms, function(form) {
    if(form.checkValidity() === false) {
      event.stopPropagation();
    } else {
      // })
      // $("#industrySubmit").click(function () {
      $("#main-form").append(`<section id="zipcode " class="zipcode-section form-section col">
                        <div class="col-xs-12 col-form-group d-md-flex d-lg-flex d-xl-flex input-box">
                        <form id="zipcodeForm" class="needs-validation" novalidate>
                            <div class=" " role="form">
                                <label id="zipcodeLabel" for="zipcodeInput">Your client's ZIP Code</label>
                                <input type="text" class="form-control" id="zipcodeInput" placeholder="start typing" minlength="5" maxlength="5" required>
                            </div>
                             <button class="next-button btn btn-circle ml-4" role="button" id="zipcodeSubmit">
                                >
                                </button>
                            </form>
                             <p class="zipCodeValidation d-none"> Please enter valid Zip code </p>
                               <p class="zipCodeBlankValidation d-none">zip code cannot be blank</p>
                        </div>
        </section>`);
      $("#industrySubmit").toggleClass("d-none");
      $("#industryLabel").text("you client's industry");
    }
    form.classList.add("was-validated");

  });
});

$(document).on("click", "#zipcodeSubmit", function(event) {
  event.stopPropagation();
  event.preventDefault();
  zipcodeValid = emptyValidation("zipcodeInput");
  if(zipcodeValid) {
    $("#main-form").append(`
      <section id="email" class="email-section form-section col">
          <div class="col-xs-12 col-form-group d-md-flex d-lg-flex d-xl-flex input-box">
              <div class=" " role="form">
                  <label id="industryLabel" for="industry">Your email address</label>
                  <input type="text" class="form-control" id="emailInput" placeholder="start typing">
                  <p>Don't worry we wont spam you</p>
              </div>
          </div>
      </section>`);
    $("#zipcodeSubmit").toggleClass("d-none");
    $("#formSubmit").removeClass("d-none");
    $("#zipcodeInput").addClass("is-valid")
      .removeClass("is-invalid");
    $(".zipCodeBlankValidation").addClass("d-none");
      }else {
    $("#zipcodeInput").removeClass("is-valid")
      .addClass("is-invalid");
    $(".zipCodeBlankValidation").removeClass("d-none");
  }
});


//filtering data on type ahead
$("#industryInput").keydown(function(e) {
  clearTimeout(timer);
  timer = setTimeout(doneTyping, 500);
});

function doneTyping() {
  let i;
  let arr = [];
  let inputValue = $("#industryInput").val();
  console.log(inputValue);
  $("option").remove();
  for(i = 0; i < industry.length; i++) {
    if(typeof inputValue !== "number") {
      if(industry[ i ].Description.toLowerCase().indexOf(inputValue.toLowerCase()) > -1) {
        arr.push(industry[ i ]);
      }
    }
    if(industry[ i ].NAICS.toString().indexOf(inputValue) > -1) {
      arr.push(industry[ i ]);
    }
  }
  for(i = 0; i < arr.length; i++) {
    let option = document.createElement("option");
    option.value = " " + arr[ i ].Description + "    " + arr[ i ].NAICS;
    $("#industries").append(option);
  }

}
// $("#industryInput").focusout(function(){
//   industryValid  = emptyValidation("industryInput")
//   if(industryValid){
//     $("#industryInput").addClass("is-valid")
//       .removeClass("is-invalid");
//   }else{
//     $("#industryInput").removeClass("is-valid")
//       .addClass("is-invalid");
//   }
// });

// $(document).on('blur', '#zipcodeInput', function () {
//   zipcodeValid = emptyValidation("zipcodeInput");
//   if(zipcodeValid){
//     $("#zipcodeInput").addClass("is-valid")
//       .removeClass("is-invalid");
//     $(".zipCodeBlankValidation").removeClass("d-none");
//   }else{
//     $("#zipcodeInput").removeClass("is-valid")
//       .addClass("is-invalid");
//     $(".zipCodeBlankValidation").addClass("d-none");
//   }
// });

// $(document).on('blur', '#emailInput', function () {
//   emailValid = emptyValidation("emailInput");
//   if(emailValid){
//     $("#emailInput").addClass("is-valid")
//       .removeClass("is-invalid");
//   }else{
//     $("#emailInput").removeClass("is-valid")
//       .addClass("is-invalid");
//   }
// });

function emptyValidation(input) {
  let data = $(`#${input}`).val();
  return data ? true : false;
}

//Product search Form Submit
$("#formSubmit").click(function(event) {
  event.preventDefault();
  let industry= $("#industryInput").val();
  let zipcode= $("#zipcodeInput").val();
  let email= $("#emailInput").val();
  if(industry && zipcode && email)
    window.location.href = "/product-offerings.html";
});



//

let notFound = function () {
  // put whatever
  return '<div class="">Industry not found</div>'
}

let dataSource;
dataSource = new Bloodhound({
  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('industry_name_NAICS_code'),
  queryTokenizer: Bloodhound.tokenizers.whitespace,
  prefetch:{ url : 'http://localhost:5000/industries/' },
  remote:{ url : 'http://localhost:5000/industries/' }

});

dataSource.initialize();

function searchWithDefaults(q, sync) {
  if (q === '') {
    sync(dataSource.index.all());
  } else {
    dataSource.search(q, sync);
  }
}

$('.typeahead').typeahead({
  hint: true,
  highlight: true,
  minLength: 0
}, {
  name: 'states',
  displayKey: function(item){
  //alert(item.country);
  return item.industry_name_NAICS_code},
  limit: 1000,
  source: searchWithDefaults,
  templates:{
    // footer: function(query) { return "<b>Searched for '" + query.query + "'</b>" },
    notFound: notFound()
  }
})
.bind('typeahead:select',function(event, suggestion){
  console.log(suggestion)
})
  .bind('typeahead:autocomplete',function(event, suggestion){
    console.log(suggestion)
  });
