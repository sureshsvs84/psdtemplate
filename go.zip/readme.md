# Go Victor

The site is built using bootstrap only for the grid and JS components, compiled using node, webpack, sass and a little bit of babel.

Currently it is configured to use Yarn but NPM will work fine as well.

Make sure you have the latest node.js installed.

## Installation

`yarn install`

or 

`npm install`

## Build

`yarn build`

or 

`npm run build`

This will bundle everything together into the */dist* folder.

## Running the webpack development server locally

`yarn start`

or

`npm start`

This will run a development server on localhost:3000.