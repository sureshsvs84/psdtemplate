﻿function CreateTatvamTabs(controlId, lstTabs, ReportFilter) {
    var bindTab = $("#" + controlId);
    var ul = document.createElement('ul');
    for (var i = 0; i < lstTabs.length; i += 1) {
        var liTab = document.createElement('li');
        liTab.id = "list";

        var aTabTitle = document.createElement('a');
        aTabTitle.href = "#" + lstTabs[i].TabId;
        aTabTitle.innerHTML = lstTabs[i].TabName;
        liTab.appendChild(aTabTitle);
        ul.appendChild(liTab);
    }

    bindTab.append(ul);

    for (var j = 0; j < lstTabs.length; j += 1) {
        var divTab = document.createElement('div');
        divTab.id = lstTabs[j].TabId;
        divTab.setAttribute("style", "overflow: hidden !important;");
        bindTab.append(divTab);
    }


    bindTab.tabs({
        beforeActivate: function (event, ui) {          
            var activeTab = ui.newPanel.attr("id");
            var tabDetails = getTabDetails(lstTabs, activeTab);
            loadTabView("#" + activeTab, tabDetails.TabId, tabDetails.ReportType, tabDetails.ChartType,ReportFilter);
        }
    });
   
    loadTabView("#" + lstTabs[0].TabId, lstTabs[0].TabId, lstTabs[0].ReportType, lstTabs[0].ChartType, ReportFilter);
    $('#tabDivId').scrollTop();
}

function getTabDetails(lstTabs, reportId) {
    for (var i = 0; i < lstTabs.length; i += 1) {
        if (lstTabs[i].TabId === reportId) {
            return lstTabs[i];
        }
    }
}

function loadTabView(controlId, reportId, reportType, chartType, ReportFilter) {  
    $.ajax({
        type: "POST",
        async: false,
        url: "../" + reportType + "/" + chartType,
        data: { reportId: reportId, TatvamReportFilterTo: ReportFilter },
        success: function (result) {
            $(controlId).append(result);
            $(reportId).scrollTop(-1, 0);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}
