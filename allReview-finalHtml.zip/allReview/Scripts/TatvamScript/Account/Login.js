﻿function onLoginClick() {
    showLoadingCursor();
    $("#msg_Error").empty();
    var email = $("#LoginEmail").val();
    var password = $("#LoginPassword").val();
    if (email == "") {
        hideLoadingCursor();
        $("#msg_Error").append("Please Enter Email ID.");
        return false;
    }

    if (password == "") {
        hideLoadingCursor();
        $("#msg_Error").append("Please enter password.");
        return false;
    }

    if (!ValidateEmail(email)) {
        hideLoadingCursor();
        $("#msg_Error").append("You have entered an invalid email address!");
        return false;
    }


    var data = {
        EmailId: email,
        Password: password
    };

    $.ajax({
        type: "POST",
        url: LOGIN_URL,
        data: data,
        success: function (result) {
            hideLoadingCursor();
            if (result == "Success") {
                location.href = HOME_URL;
            } else if (result == "ResetPassword") {
                location.href = "./Password/Reset";
            } else {
                $("#msg_Error").append(result);                
            }
        },
        error: function (xhr, status, p3, p4) {
            hideLoadingCursor();
            if (xhr.status === 401) {
                $("#msg_Error").append("Access is denied due to invalid credentials.");
            } else {
                var error = JSON.parse(xhr.responseText)
                $("#msg_Error").append(error.ErrorMessage);
            }
        }
    });
}

function ValidateEmail(mail) {
    var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
    return pattern.test(mail);
}

