﻿function GetGridData(reportId) {
    $.getJSON("../Data/GetGridData", { reportId: reportId, isExecutiveSummary: false }, function (data) {
        $("#Grid_" + reportId).css('display', 'block');
        if (data.Result.length === 0) {
            $("#Grid_" + reportId).empty();
            $("#Grid_" + reportId).append("<div class=\'nodata\'>No Data Available.</div>");
        }
        else {
            if (data.Result._GridData.length === 0) {
                $("#Grid_" + reportId).spreadsheetWidget(data.Result._Properties);
            }

            if (data.Result._Properties.columnDefs !== undefined && data.Result._Properties.columnDefs !== null) {
                // This will convert the column definition function string to function for execution
                data.Result._Properties.columnDefs.forEach(function (value, index) {
                    if (value.cellRenderer != null) {
                        var cellRenderer = value.cellRenderer;
                        data.Result._Properties.columnDefs[index].cellRenderer = eval(cellRenderer);
                    }
                    if (value.cellStyle != null) {
                        var cellStyle = value.cellStyle;
                        data.Result._Properties.columnDefs[index].cellStyle = eval(cellStyle);
                    }
                });
            } else {
                data.Result._Properties.columnDefs = data.Result._GridColumns;
            }

            $("#Grid_" + reportId).spreadsheetWidget(data.Result._Properties);
            $("#Grid_" + reportId).spreadsheetWidget('setRowData', data.Result._GridData);

            var gridster = $('.gridster ul#widgets').gridster().data('gridster');
            var widgetObj = gridster.$widgets.closest("#widget_" + reportId);
            var sizex = widgetObj.attr("data-sizex");

            if (sizex !== undefined) {
                var reviewListContainerHeight = $("#Grid_" + reportId + " .ag-body-container").height();
                console.log(reviewListContainerHeight);
                var sizey = Math.ceil(reviewListContainerHeight / 128);
                gridster.resize_widget(widgetObj, sizex, sizey +1, function (obj1, obj2) { });
            }

            $("#report_" + reportId).css({ 'overflow': 'hidden' });
            $("#report_" + reportId).parent().css({ 'height': '94%' });

        }
        $("#chartloader_" + reportId).css('display', 'none');
    }).fail(function () { $('#smile').css('display', 'block'); $("#smile").empty(); $("#smile").append("Something went wrong."); }).always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}