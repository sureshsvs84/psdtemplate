﻿var StackedBarChartCallURL = "../Chart/TatvamRatingStackedBarChart";

function CreateTatvamRatingStackedBarchartWidget(data) {
    $("#StackedBarChartSelected").empty();
    var displayValue = $('#selectedValue #wordCloudWithClickSelectedVal').text();
    $("#StackedBarChartSelected").append(displayValue);
    $("#ReviewListSelectedSub").empty();

    var reportData, reportDetails, chartData, reportCategory;
    reportDetails = data.Report;
    reportCategory = reportDetails.ReportCategory;
    var divname = "plotly_chart_" + reportDetails.ReportCategoryId;
    if (data.Result === null) {
        $('#chartloader_' + reportDetails.ReportCategoryId).css('display', 'none');
        $('#' + divname).append("<div class=\'nodata\'>No Data Available.</div>");
        return;
    }

    if (data.Result.length === 0) {
        $('#chartloader_' + reportDetails.ReportCategoryId).css('display', 'none');
        $('#' + divname).append("<div class=\'nodata\'>No Data Available.</div>");
        return;
    }

    var layout = jQuery.parseJSON(data.Report.ReportDefinition.layout); //reportDetails.layout;   

    var height = $('#report_' + reportDetails.ReportCategoryId).height() - 10;
    var width = $('#report_' + reportDetails.ReportCategoryId).width();

    layout.height = height;
    layout.width = width;

    var chartData = [];
    for (var i in data.Result) {
        var color = "";
        if (data.Result[i].name === "5") { color = "#196004"; }
        if (data.Result[i].name === "4") { color = "#6ccc07"; }
        if (data.Result[i].name === "3") { color = "#dbb006"; }
        if (data.Result[i].name === "2") { color = "#de5804"; }
        if (data.Result[i].name === "1") { color = "#ce2029"; }
        data.Result[i].marker.color = color;
        data.Result[i].marker.line.color = color;
        data.Result[i].marker.colors = color;
        data.Result[i].line.color = color;
        data.Result[i].line.colors = color;
        data.Result[i].line.width = 0;
    }
    layout.annotations = [];
    var xValues = data.Result[0].x;
    for (var i = 0; i < xValues.length; i++) {
        var count = 0;
        var avg = 0;
        var k = 0;
        var Rating5Count = 0;
        var Rating4Count = 0;
        var Rating3Count = 0;
        var Rating2Count = 0;
        var Rating1Count = 0;

        for (var j = 0; j < data.Result.length; j++) {
            if (data.Result[j].yaxis === "y1") {
                if (data.Result[j].y[i] > 0) {
                    k++;
                    if (data.Result[j].name == "1") {
                        Rating1Count = data.Result[j].y[i] * 1;
                    } else if (data.Result[j].name == "2") {
                        Rating2Count = data.Result[j].y[i] * 2;
                    } else if (data.Result[j].name == "3") {
                        Rating3Count = data.Result[j].y[i] * 3;
                    } else if (data.Result[j].name == "4") {
                        Rating4Count = data.Result[j].y[i] * 4;
                    } else if (data.Result[j].name == "5") {
                        Rating5Count = data.Result[j].y[i] * 5;
                    }
                    count = count + data.Result[j].y[i];
                }
            }         
        }

        var sum = Rating1Count + Rating2Count + Rating3Count + Rating4Count + Rating5Count;
        
        var oneannotation = {
            text: (sum /count).toFixed(2),
            align: 'center',
            showarrow: false,
            bgcolor: "#2c77ba",
            xanchor: 'center',
            x: xValues[i],
            y: count,
            visible: true,
            yanchor: "bottom",
            font: {
                "color": "#fff"
            }
        };

        layout.annotations.push(oneannotation);
    }

    var finalData = [];
    for (var i = 0; i < data.Result.length; i++) {
        if (data.Result[i].yaxis == "y1") {
            //var y = [];
            //var x = [];
            //for (var k = 0; k < data.Result[i].y.length; k++) {
            //    if (data.Result[i].y[k] !== 0) {
            //        y.push(data.Result[i].y[k]);
            //        x.push(data.Result[i].x[k]);
            //    }
            //}
            //data.Result[i].x = x;
            //data.Result[i].y = y;
            finalData.push(data.Result[i]);
        }
     
    }

    var tickvals = [];
    var ticktext = [];
    /*Check tickvals exist in array*/
    data.Result[0].x.forEach(function (XAxisValues) {
        if (tickvals.indexOf(XAxisValues) === -1) {
            tickvals.push(XAxisValues);
            if (XAxisValues.length > 12)
                ticktext.push(XAxisValues.substr(0, 12) + '...');
            else
                ticktext.push(XAxisValues);
        }
    });

    layout.xaxis.tickvals = tickvals;
    layout.xaxis.ticktext = ticktext;

    Plotly.newPlot(divname, finalData, layout, {
        modeBarButtons: [[
            {
                name: "Download as PNG",
                icon: Plotly.Icons.camera,
                click: function (gd) {
                    Plotly.downloadImage(gd, {
                        filename: reportCategory,
                        format: 'png',
                        width: gd._fullLayout.width,
                        height: gd._fullLayout.height
                    })
                }
            },  //-- for export or image downloading. Download plot as a png
            'hoverClosestCartesian',//show the respective values for the selected category on hovering on the point.
            'hoverCompareCartesian'//compare the values of all the categories on hovering on the point.
        ]], displaylogo: false, displayModeBar: false
    });

    var myplot = document.getElementById(divname);

    myplot.on('plotly_click', function (data) {
        $("#StackedBarChartSelectedSubClassifier").empty();
        $("#StackedBarChartSelectedSubClassifier").append('> ' + data.points[0].x);
        $("#ReviewListSelectedSub").empty();
        $("#ReviewListSelectedSub").append(data.points[0].x);
        var selectedval = data.points[0].x;
        var selectedText = [];
        var selectedValue = [];
        selectedText.push(selectedval);
        selectedValue.push(selectedval);
        CallReviewListonWordCloudClick(reportDetails.ReportCategoryId, selectedText, selectedValue, 'Classifier', ' TARGET_ENTITY_VALUE in (@Classifier) ');
    });


    return true;
}

function GetTatvamRatingStackedBarChartData(chartData, annotations) {
    var dataset = [];
    var tickvals = [];
    var ticktext = [];
    var maxValue = 0;
    var stakedchartdatacolors = ['#f34443', '#e66e0b', '#f3b81a', '#2dac07', '#196004']; // The order of the color is in reverse Order i.e,(1,2,3,4,5).    
    for (var i = 0; i < chartData.length; i++) {
        var x = [];
        var y = [];

        for (var j = 0; j < chartData[i].DataValues.length; j++) {
            if (maxValue < chartData[i].DataValues[j].YAxisValues)
                maxValue = chartData[i].DataValues[j].YAxisValues;
            var XAxisValues = chartData[i].DataValues[j].XAxisValues;
            x.push(XAxisValues);

            y.push(parseFloat(chartData[i].DataValues[j].YAxisValues));
            /*Check tickvals exist in array*/
            if (tickvals.indexOf(XAxisValues) === -1) {
                tickvals.push(XAxisValues);
                if (XAxisValues.length > 12)
                    ticktext.push(XAxisValues.substr(0, 12) + '...');
                else
                    ticktext.push(XAxisValues);
            }
        }

        dataset.push({
            x: x,
            y: y,
            name: chartData[i].DataSeries,
            type: 'bar',
            marker: {
                color: stakedchartdatacolors[chartData[i].DataSeries - 1]
            }
        });
        annotations.push(oneannotation);
    }
    dataset = dataset.sort(function (a, b) {
        a = a.name;
        b = b.name;
        return b - a;
    });
    return [{ dataset: dataset, maxValue: maxValue, tickvals: tickvals, ticktext: ticktext, annotations: annotations }];
}

function CallStackedBarChart(reportId, selectedText, selectedValue, searchbyText, searchbyValue) {
    var array = [];
    if (reportId == "") {
    }

    $('.searchpanel:not(#UniversalFilterPanel .searchpanel)').each(function () {
        var searchbyText = $(this).find("#ddl_searchby option:selected").text();
        var searchbyValue = $(this).find("#ddl_searchby option:selected").val();

        var operatorName = $(this).find("#ddl_operator option:selected").text();
        var operatorValue = $(this).find("#ddl_operator option:selected").val();

        var valueId, selectedText = "", selectedValue = "";
        valueId = $(this).find("[id^='ddl_value']").attr("id");

        var SelectedText = [];
        var SelectedValue = [];

        $(this).find("#" + valueId + " option:selected").each(function () {
            SelectedText.push({ Name: this.text });
            SelectedValue.push({ Name: this.value });
        });

        if (SelectedText.length === 0) {
            var val = $(this).find("#" + valueId).val();
            if (val !== "") {
                SelectedValue = [];
                SelectedText.push({ Name: '%' + val + '%' });
                SelectedValue.push({ Name: '%' + val + '%' });
            }
        }

        var conditionName = $(this).find("#ddl_whereclause option:selected").text();
        var conditionValue = $(this).find("#ddl_whereclause option:selected").val();
        if (SelectedValue.length > 0) {
            array.push({
                "SearchbyText": searchbyText,
                "SearchbyValue": searchbyValue,
                "OperatorName": operatorName,
                "OperatorValue": operatorValue,
                "SelectedText": SelectedText,
                "SelectedValue": SelectedValue,
                "ConditionName": "or",
                "ConditionValue": "or"
            });
        }
    });

    array.push({ "Condition" : "AND", "ParentType": "CLASSIFIER", "KeyType": "CLASSIFIER", KeyWordValues: selectedText });

    $.ajax({
        type: 'POST',
        async: true,
        //dataType: 'json',
        url: StackedBarChartCallURL,
        data: { reportId: reportId, tatvamReportFilterTo: JSON.stringify(array) },
        success: function (result) {
            var reportCategoryIdIndex = result.indexOf("data-id");
            if (reportCategoryIdIndex !== -1) {
                var reportCategoryId = result.substr(reportCategoryIdIndex + 9).split('"')[0]
                $("#report_" + reportCategoryId).empty();
                $("#report_" + reportCategoryId).html(result);
            }
            //  $("#15").html(result);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText);
            TatvamAlert(error, "Error");
        }
    });
}


function GetTatvamRatingStackedBarData(reportId)
{
    var tatvamReportFilterTo =[];
    var selectedText = $("#wordCloudWithClickSelectedVal").text();
    tatvamReportFilterTo.push({ "Condition" : "AND", "ParentType": "CLASSIFIER", "KeyType": "CLASSIFIER", KeyWordValues: [selectedText] });
    $.getJSON("../Data/GetChartData", { reportId: reportId, tatvamReportFilterTo: JSON.stringify(tatvamReportFilterTo), isExecutiveSummary: false }, function (data) {
        CreateTatvamRatingStackedBarchartWidget(data);
    })
        .fail(function () { $("#plotly_chart_" + reportId).append("Something went wrong."); })
        .always(function () { $("#chartloader_" + reportId).css('display', 'none'); });
}