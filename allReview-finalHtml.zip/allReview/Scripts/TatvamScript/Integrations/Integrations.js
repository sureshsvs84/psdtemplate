﻿$(".universal_filters").hide();

// Get Facebook APP details
var appDetails = TatvamAjaxCallWithReturn("GET", "../Integrations/GetFacebookAppDetails", null);

getFbPageList();
window.fbAsyncInit = function () {
    // FB JavaScript SDK configuration and setup
    FB.init({
        appId: appDetails.responseJSON.client_id, // FB App ID
        cookie: false,  // enable cookies to allow the server to access the session
        xfbml: true,  // parse social plugins on this page        
        version: 'v4.0' // use graph api version 2.8
    });
};

// Load the JavaScript SDK asynchronously
(function (d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

// Facebook login with JavaScript SDK
function fbLogin() {

    showLoadingCursor();
    $(".loadcontent").html("<div style='width: 300px;margin-top: 45px; color: #fff; margin-left: -115px;'>Facebook Integration is in progress</div>");
    FB.login(function (response) {
        if (response.status === "connected") {
            // Save the user details and their page permissions
            saveUserData(response);
            hideLoadingCursor();
        }
        else if (response.status === "not_authorized") {
            // Closed the facebook window.
            hideLoadingCursor();
            //TatvamAlert("The operation has been aborted.", "Message");
        }
        else if (response.status === "unknown") {
            hideLoadingCursor();
            //User cancelled login or did not fully authorize. 
            //TatvamAlert("The operation has been aborted.", "Message");
        }
    }, { scope: appDetails.responseJSON.scope, response_type: appDetails.responseJSON.response_type, auth_type: appDetails.responseJSON.auth_type });
}

function saveUserData(userData) {
    var data = {
        type: "Facebook",
        accessToken: userData.authResponse.accessToken
    };
    var appDetails = TatvamAjaxCallWithReturn("GET", "../Integrations/SaveFBPageDetails", data);
    if (!appDetails.responseJSON) {
        TatvamAlert("Error while integrating with facebook. Please contact your administrator.", "Error");
    } else {
        getFbPageList();
    }
}


function getFbPageList() {
    showLoadingCursor();
    $.ajax({
        url: "../Integrations/FBPageList",
        success: function (data) {
            $("#pageList").empty();
            $("#pageList").html(data);
            hideLoadingCursor();
        },
        error: function (xhr, status, p3, p4) {
            hideLoadingCursor();
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });
}