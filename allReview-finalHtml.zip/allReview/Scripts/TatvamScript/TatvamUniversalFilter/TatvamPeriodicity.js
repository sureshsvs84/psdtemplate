﻿/*Function to Select All values  - Start*/
function periodicityValueDeselect(e) {
    $(e.target).parent().find('option').prop('selected', false).parent().trigger('chosen:updated');
    var control = GetControlByPeriodicitySelected();
    if (control) {
        control.find('option').prop('selected', false).trigger('chosen:updated');
    }
}

/*Function to Select All values  - Start*/
function periodicityValueSelect(e, isYear, isSelectAllYears) {
    //$(e.target).parent().find('option').prop('selected', true).parent().trigger('chosen:updated');
    var selectYears = yearcontrol.chosen().val();
    if (selectYears.length === 0 && isSelectAllYears == false) {
        bootbox.alert({
            title: "Alert Box",
            message: "Please Select Year.",
            buttons: {
                ok: {
                    label: 'Ok',
                    className: 'btn-primary'
                }
            }
        });
        return false;
    }

    $(e.target).parent().find('option').prop('selected', true).parent().trigger('chosen:updated');
    if (isYear && selectYears.length > 0) {
        onYearChange(true);
    }
}

var dataFormat = "dd/M/yy";

//Select Complete Parent Div
var ddlyear = $('.year');
var ddlquarteryear = $(".quarteryear");
var ddlmonthYear = $(".monthYear");
var ddlweekYear = $(".weekYear");
var ddldaily = $('.daily');

//Select ControlerIDs
var yearcontrol = $('#ddlyear');
var Quartercontrol = $('#ddlQuarter');
var Weeklycontrol = $('#ddlWeekly');
var Monthlycontrol = $('#ddlMonthly');

var UpdatePeriodicityByYearCallURL = "../TatvamUniversalFilter/UpdatePeriodicityByYear/";
var periodicityChangeCallURL = "../TatvamUniversalFilter/PeriodicityRangeFilter/";
var periodicityCallURL = "../TatvamUniversalFilter/Periodicity";

//Function to show and hide the controls based on the selected frequency
function EnablePeriodicityrangeFilter(frequency) {
    hideAllFrequencyControl();

    if (frequency === "1" || frequency === "Daily") {
        ddldaily.show();
        $("#startdatepicker").prop("disabled", false);
        $("#enddatepicker").prop("disabled", false);
    } else if (frequency === "2" || frequency === "Weekly") {
        ddlyear.show();
        ddlweekYear.show();
    } else if (frequency === "3" || frequency === "Monthly") {
        ddlyear.show();
        ddlmonthYear.show();
    } else if (frequency === "4" || frequency === "Quarterly") {
        ddlyear.show();
        ddlquarteryear.show();
    } else if (frequency === "5" || frequency === "Yearly") {
        ddlyear.show();
    }
}

// hide all the frequency value controls
function hideAllFrequencyControl() {
    ddlyear.hide();
    ddlweekYear.hide();
    ddlmonthYear.hide();
    ddlquarteryear.hide();
    ddldaily.hide();
    $("#startdatepicker").prop("disabled", true);
    $("#enddatepicker").prop("disabled", true);
}

function onCustomPeriodicityLoad(data) {    
    //Convert start and end data control as date picker
    convertDataPicker("#startdatepicker");
    convertDataPicker("#enddatepicker");

    //Hide all the frequency controls so that based on the currently selected periodicity we can enable the respective control
    hideAllFrequencyControl();

    var Periodicitycontrol = $('#ddlPeriodicity');
    BuildSingleSelectControl(Periodicitycontrol, data.FrequencyList);

    // Register periodicity control on change event
    Periodicitycontrol.chosen({}).change(onPeriodicityChange);

    // Bind the periodicity dropdown with the currently selected values
    BuildMultiSelectControl(yearcontrol, data.YearlyList.reverse(), false);


    // Register year control on change event
    yearcontrol.chosen().change(onYearChange);

    //onYearChange(false);

    BuildMultiSelectControl(Quartercontrol, data.QuartelyList, false);

    BuildMultiSelectControl(Weeklycontrol, data.WeeklyList, false);

    BuildMultiSelectControl(Monthlycontrol, data.MonthlyList, false);

    EnablePeriodicityrangeFilter(data.CurrentlySelectedFrequency);

    SetPeriodicityFilters();
    filteredperiodicity();
}

function convertDataPicker(selector) {
    $(selector).datepicker({ dateFormat: dataFormat });
}

function onYearChange(refresh) {
    var selectddlyear = [];
    //get the selected years
    selectddlyear = yearcontrol.chosen().val();
    if (selectddlyear.length !== 0) {
        var data = {
            years: selectddlyear.toString()
        };
        var rtnVal = TatvamAjaxCallWithReturn("POST", UpdatePeriodicityByYearCallURL, data);
        bindCustomPeriodicityControl(rtnVal.responseJSON, refresh);
    } else {
        ClearChosen();
    }
}

function ClearChosen() {
    var control = GetControlByPeriodicitySelected();
    if (control) {
        control.find('option').prop('selected', false).trigger('chosen:updated');
    }
}

function GetControlByPeriodicitySelected() {
    var frequency = $('#ddlPeriodicity option:selected').val();
    var control;
    //Weekly
    if (frequency === "2") {
        control = Weeklycontrol;
    }//Monthly
    else if (frequency === "3") {
        control = Monthlycontrol;
    }//Quarterly
    else if (frequency === "4") {
        control = Quartercontrol;
    }
    else if (frequency === "5") {
        control = yearcontrol;
    }

    return control;
}

function onPeriodicityChange(obj, result) {
    EnablePeriodicityrangeFilter(result.selected);
}

function bindCustomPeriodicityControl(data, refresh) {
    if (refresh == undefined) {
        refresh = true;
    }
    BuildMultiSelectControl(Quartercontrol, data.QuartelyList.reverse(), refresh);
    BuildMultiSelectControl(Monthlycontrol, data.MonthlyList.reverse(), refresh);
    BuildMultiSelectControl(Weeklycontrol, data.WeeklyList.reverse(), refresh);
    $('#startdatepicker').val(data.StartDate);
    $('#enddatepicker').val(data.EndDate);
}

function BuildMultiSelectControl(control, data, refresh) {
    control.empty();
    for (var i = 0; i < data.length; i++) {
        if (data[i].Selected === true)
            control.append('<option value="' +
                data[i].Value +
                '" selected="selected">' +
                data[i].Text +
                '</option>');
        else
            control.append('<option value="' + data[i].Value + '">' + data[i].Text + '</option>');
    }
    if (refresh) {
        control.trigger("chosen:updated");
    } else {
        control.chosen();
    }
}

/**
 * Create the dynamic single-select chosen control
 * @param {data}
 *    pass the data which bind to the control
 * @param {control}
 *    DOM control to bind the data
 */
function BuildSingleSelectControl(control, data) {
    for (var i = 0; i < data.length; i++) {
        if (data[i].Selected === true)
            control.append('<option value="' +
                data[i].Value +
                '" selected="selected">' +
                data[i].Text +
                '</option>');
        else
            control.append('<option value="' + data[i].Value + '">' + data[i].Text + '</option>');
    }
}

$("#btn_periodicityrangecancel")
    .click(function () {
        $.ajax({
            type: "POST",
            url: periodicityCallURL,
            success: function (result) {
                $("#PeriodicityFilter").empty();
                $("#PeriodicityFilter").html(result);
                return false;
            },
            error: function (xhr, status, p3, p4) {
                var error = JSON.parse(xhr.responseText);
                TatvamAlert(error.ErrorMessage, "Error");
            }
        });
        $("#customFilter").modal('hide');
        $("#customFilter").remove();
        $('.modal-backdrop.fade.in').remove();
        $('body').removeClass('modal-open');
    });

/*On Periodicity Button save Starts*/
$("#btn_periodicityrangesave").click(function () {
    //showLoadingCursor();
    Periodicity = $("#ddlPeriodicity option:selected").text();
    var monthly, quarter, week, startDate, endDate;
    if (Periodicity === "Yearly") {
        if (yearcontrol.val().length == 0) {
            $('.year-calendar :input').prop('disabled', true);
            bootbox.alert({
                title: "Alert Box",
                message: "Please Select Year.",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                    $('.year-calendar :input').prop('disabled', false);
                    $("#startdatepicker").prop("disabled", true);
                    $("#enddatepicker").prop("disabled", true);
                }
            });

            //hideLoadingCursor();
            return false;
        }
        year = yearcontrol.val().toString();
    } else if (Periodicity === "Quarterly") {
        if (yearcontrol.val().length === 0) {
            $('.year-calendar :input').prop('disabled', true);
            bootbox.alert({
                title: "Alert Box",
                message: "Please Select Year.",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                    $('.year-calendar :input').prop('disabled', false);
                    $("#startdatepicker").prop("disabled", true);
                    $("#enddatepicker").prop("disabled", true);
                }

            });
            return false;
        }
        if (Quartercontrol.val().length === 0) {
            $('.year-calendar :input').prop('disabled', true);
            bootbox.alert({
                title: "Alert Box",
                message: "Please Select Quarter.",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                    $('.year-calendar :input').prop('disabled', false);
                    $("#startdatepicker").prop("disabled", true);
                    $("#enddatepicker").prop("disabled", true);
                }
            });
            return false;
        }

        year = yearcontrol.val().toString();
        quarter = Quartercontrol.val().toString();
    } else if (Periodicity === "Monthly") {
        if (yearcontrol.val().length === 0) {
            $('.year-calendar :input').prop('disabled', true);
            bootbox.alert({
                title: "Alert Box",
                message: "Please Select Year.",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                    $('.year-calendar :input').prop('disabled', false);
                    $("#startdatepicker").prop("disabled", true);
                    $("#enddatepicker").prop("disabled", true);
                }
            });

            return false;
        }
        if (Monthlycontrol.val().length === 0) {
            $('.year-calendar :input').prop('disabled', true);
            bootbox.alert({
                title: "Alert Box",
                message: "Please Select Months.",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                    $('.year-calendar :input').prop('disabled', false);
                    $("#startdatepicker").prop("disabled", true);
                    $("#enddatepicker").prop("disabled", true);
                }
            });
            return false;
        }

        year = yearcontrol.val().toString();
        monthly = Monthlycontrol.val().toString();
    } else if (Periodicity === "Weekly") {
        if (yearcontrol.val().length === 0) {
            $('.year-calendar :input').prop('disabled', true);
            bootbox.alert({
                title: "Alert Box",
                message: "Please Select Year.",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                    $('.year-calendar :input').prop('disabled', false);
                    $("#startdatepicker").prop("disabled", true);
                    $("#enddatepicker").prop("disabled", true);
                }
            });

            return false;
        }
        if (Weeklycontrol.val().length === 0) {
            $('.year-calendar :input').prop('disabled', true);
            bootbox.alert({
                title: "Alert Box",
                message: "Please Select Weeks.",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                    $('.year-calendar :input').prop('disabled', false);
                    $("#startdatepicker").prop("disabled", true);
                    $("#enddatepicker").prop("disabled", true);
                }
            });

            return false;
        }

        year = yearcontrol.val().toString();
        week = Weeklycontrol.val().toString();
    } else if (Periodicity === "Daily") {
        startDate = $("#startdatepicker").val();
        endDate = $("#enddatepicker").val();
        stDate = new Date($("#startdatepicker").val());
        edDate = new Date($("#enddatepicker").val());

        if (stDate > edDate) {
            $('.year-calendar :input').prop('disabled', true);
            bootbox.alert({
                title: "Alert Box",
                message: "Start Date Should not be greater than End Date",
                buttons: {
                    ok: {
                        label: 'Ok',
                        className: 'btn-primary'
                    }
                },
                callback: function () {
                    $(this).modal('hide');
                    $('.year-calendar :input').prop('disabled', false);
                }
            });

            return false;
        }
        if (stDate.getFullYear() === edDate.getFullYear()) {
            year = stDate.getFullYear();
        } else {
            year = stDate.getFullYear() + " to " + edDate.getFullYear();
        }
    }
    $('#Year').empty();
    $('#Year').append("&nbsp; " + year + "  ");
    $.ajax({
        type: "POST",
        async: true,
        url: periodicityChangeCallURL,
        data: {
            inpFrequency: Periodicity,
            Year: year,
            Quarter: quarter,
            Month: monthly,
            Week: week,
            StartDate: startDate,
            EndDate: endDate
        },
        success: function () {
            $('.calendar-menu').toggle('slide', {
                duration: 700,
                direction: 'up'
            });
            var reportid = $('#hdn_reportid_page').val();
            var reportName = sessionStorage.getItem('reportName');
            OnMenuClick(reportid, reportName);
        },
        error: function (xhr, status, p3, p4) {
            var error = JSON.parse(xhr.responseText)
            TatvamAlert(error.ErrorMessage, "Error");
        }
    });

    filteredperiodicity();
    $("#customFilter").modal('hide');
    window.sessionStorage.setItem('QuickFiltersSelected', "custom");
    $("#Item").empty();
    $(".filterResetBtn").show();
    $("#ddltopHeaderFilter").val("custom");
});
/*On Periodicity Button save Ends*/

// this method sets selected periodicity filters
function SetPeriodicityFilters() {
    if ($('.plus').css('display') === 'none') {
        Periodicity = $("#ddlPeriodicity option:selected").text();
        year = yearcontrol.val();
        if (Periodicity === "Daily") {
            if (stDate.getFullYear() === edDate.getFullYear()) {
                year = stDate.getFullYear();
            } else {
                year = stDate.getFullYear() + "," + edDate.getFullYear();
            }
        }
        $('.calendar-menu').hide();
        $(".universalfilter-selected-items").empty();
        $(".universalfilter-selected-items").append(GetFilterData());
        $('.universalfilter-selected-items').slideToggle('500');
    }
}

function GetFilterData() {    
    var selectedFrequency = $("#Item")[0].outerText;
    //var splitedFilters = selectedFrequency[1].split(' ');
    Periodicity = $("#ddltopHeaderFilter option:selected").text();

    if (Periodicity === "Custom") {
        var frequency = $("#ddlPeriodicity option:selected").text();
        if (frequency === "Daily") {
            var stDate = new Date($("#startdatepicker").val());
            edDate = new Date($("#enddatepicker").val());
            selectedFrequency = " From " + stDate + " to " + edDate;
        } else if (frequency === "Weekly") {
            var selMulti = $.map($("#ddlWeekly option:selected"), function (el, i) {
                return $(el).text();
            });
            selectedFrequency = selMulti.join(", ");
        } else if (frequency === "Monthly") {
            var selMulti = $.map($("#ddlMonthly option:selected"), function (el, i) {
                return $(el).text();
            });            
            selectedFrequency = selMulti.join(", ");
        } else if (frequency === "Quarterly") {
            var selMulti = $.map($("#ddlQuarter option:selected"), function (el, i) {
                return $(el).text();
            });
            selectedFrequency = selMulti.join(", ");
        } else if (frequency === "Yearly") {            
            var selMulti = $.map($("#ddlyear option:selected"), function (el, i) {
                return $(el).text();
            });
            selectedFrequency = selMulti.join(", ");
        }
    }


    var filterPanel = "<div class='bottom-view'> <h1> Selected Filters </h1> <ul>";
    filterPanel = filterPanel + "<li class='clr'></li>";
    filterPanel = filterPanel + "<li class='caption'>Periodicity </li>  <li class='details'>" + Periodicity + "</span> </li>";
    filterPanel = filterPanel + "<li class='clr'></li>";
    filterPanel = filterPanel + "<li class='caption'>Selected Filters </li>  <li class='details'>" + selectedFrequency + "</span> </li>";
    filterPanel = filterPanel + "<li class='clr'></li>";
    if ($("#ucdAppliedFilterCount").text() != "") {
        for (i = 0; i < $('#ucdForm').find('.universalFilterRepeatSection').length; i++) {
            var searchBy = $("#ddlUCDSearchBy_" + i + " :selected").text();

            var selectedValues = [];
            $($("#ddlUCDValue_" + i + "_chosen").find(".search-choice")).each(function (i, selected) {
                selectedValues[i] = selected.innerText;
            });

            filterPanel = filterPanel + "<li class='caption'>" + searchBy + " </li>  <li class='details' style='min-width:300px; max-width:100%;'> " + selectedValues + " </span> </li>";
            filterPanel = filterPanel + "<li class='clr'></li>";
        }
    }

    filterPanel = filterPanel + "</ul> </div>";
    return filterPanel;

}

function filteredperiodicity() {
    var Periodicity = $("#ddlPeriodicity option:selected").text();
    var customFilter = window.sessionStorage.getItem('QuickFiltersSelected');    
    if (customFilter == null) {
        customFilter = "Last6months";
        window.sessionStorage.setItem('QuickFiltersSelected', "Last6months");
    }

    $("#ddltopHeaderFilter").val(customFilter);
    
    $("#Item").empty();
    var selectedQuarter = [];
    $('#ddlQuarter :selected').each(function (i, selected) {        
        selectedQuarter[i] = {
            "id": selected.value,
            "value": selected.text
        };
    });

    var selectedMonth = [];
    $('#ddlMonthly :selected').each(function (i, selected) {
        selectedMonth[i] = {
            "id": selected.value,
            "value": selected.text
        };
    });
    var selectedWeekes = [];
    $('#ddlWeekly :selected').each(function (i, selected) {        
        selectedWeekes[i] = {
            "id": selected.value,
            "value": selected.text
        };
    });
    var selectedyears = [];
    $('#ddlyear :selected').each(function (i, selected) {        
        selectedyears[i] = {
            "id": selected.value,
            "value": selected.text
        };
    });

    $('#Item').empty();    
    if (customFilter === "Last13months" || customFilter === "Last3months" || customFilter === "Last6months") {
        (function () {
            selectedMonth.sort(function (a, b) {
                // a and b will here be two objects from the array
                // thus a[1] and b[1] will equal the names

                // if they are equal, return 0 (no sorting)
                if (a.id == b.id) { return 0; }
                if (a.id > b.id) {
                    // if a should come after b, return 1
                    return 1;
                }
                else {
                    // if b should come after a, return -1
                    return -1;
                }
            });
        })();
        $("#Item").append(selectedMonth[0].value + " - " + selectedMonth[selectedMonth.length - 1].value);
    }
    else if (customFilter === "CurrentMonth") {
        (function () {
            selectedWeekes.sort(function (a, b) {
                // a and b will here be two objects from the array
                // thus a[1] and b[1] will equal the names

                // if they are equal, return 0 (no sorting)
                if (a.id == b.id) { return 0; }
                if (a.id > b.id) {
                    // if a should come after b, return 1
                    return 1;
                }
                else {
                    // if b should come after a, return -1
                    return -1;
                }
            });
        })();
        $("#Item").append(selectedWeekes[0].value + " - " + selectedWeekes[selectedWeekes.length - 1].value);
    } else if (customFilter === "custom") {
        $("#Item").empty();
        $(".filterResetBtn").show();
    }
}