﻿var Tatvam = Tatvam || {};

function SetBootboxTitle(title) {
    if (!title) {
        title = "Tatvam";
    } else {
        title = title;
    }
    return title;
}

Tatvam.messages = Tatvam.messages || (function() {
    var showMessage = {
        'Info': function(message, callback) {
            bootbox.dialog({
                title: "Tatvam",
                message: message,
                show: true,
                animate: false,
                closeButton: false,
                keyboard: true,
                backdrop: "static",
                buttons: {
                    main: {
                        label: 'Ok',
                        className: 'k-button pull-right',
                        callback: function(result) {
                            if (result) {
                                if (callback) {
                                    callback(true);
                                }
                            } else {
                                if (callback) {
                                    callback(false);
                                }
                            }
                        }
                    }
                }
            });
        },
        'Dialog': function(message, callback, title, ctrlName, okButtonName, cancalButtonName) {
            bootbox.confirm({
                title: SetBootboxTitle(title),
                message: message,
                show: true,
                animate: false,
                closeButton: false,
                keyboard: true,
                backdrop: "static",
                buttons: {
                    'cancel': {
                        label: ((cancalButtonName !== undefined && cancalButtonName !== "" && cancalButtonName !== null) ? cancalButtonName : 'Cancel'),
                        className: 'k-button pull-right'
                    },
                    'confirm': {
                        label: ((okButtonName !== undefined && okButtonName !== "" && okButtonName !== null) ? okButtonName : 'Ok'),
                        className: 'k-button btn-yes'
                    }
                },
                callback: function(result) {
                    if (result) {
                        if (callback) {
                            callback(true);
                        }
                    } else {
                        if (callback) {
                            callback(false);
                        }
                    }
                    if (ctrlName !== undefined && ctrlName !== "" && ctrlName !== null) {
                        $(ctrlName).focus();
                    }
                }
            });
        },
        'DialogWithoutCancel': function(message, callback, title, ctrlName) {
            bootbox.confirm({
                title: SetBootboxTitle(title),
                message: message,
                show: true,
                animate: false,
                closeButton: false,
                keyboard: true,
                backdrop: "static",
                buttons: {
                    'cancel': {
                        label: 'Cancel',
                        className: 'HideDialogCancelButton'
                    },
                    'confirm': {
                        label: 'Ok',
                        className: 'button ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only pull-right'
                    }
                },
                callback: function(result) {
                    if (result) {
                        if (callback) {
                            callback(true);
                        }
                    } else {
                        if (callback) {
                            callback(false);
                        }
                    }
                    if (ctrlName !== undefined && ctrlName !== "" && ctrlName !== null) {
                        $(ctrlName).focus();
                    }
                }
            });
        },
        'Error': function(screenTitle, message, ctrlName) {
            bootbox.alert({
                title: screenTitle,
                message: message,
                show: true,
                animate: false,
                closeButton: false,
                keyboard: true,
                backdrop: "static",
                callback: function() {
                    if (ctrlName !== undefined && ctrlName !== "" && ctrlName !== null) {
                        $(ctrlName).focus();
                    }
                }
            });
        }
    };

    return {
        showInfo: showMessage['Info'],
        showConfirm: showMessage['Dialog'],
        showError: showMessage['Error'],
        showConfirmWithoutCancel: showMessage['DialogWithoutCancel']
    };
}(this));
